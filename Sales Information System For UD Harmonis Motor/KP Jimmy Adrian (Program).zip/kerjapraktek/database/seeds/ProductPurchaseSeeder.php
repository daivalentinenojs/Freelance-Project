<?php
use Illuminate\Database\Seeder;
use App\Product;
use App\Purchase;

class ProductPurchaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $prod = Product::first();
        $pur = Purchase::first();
        $prod->purchases()->attach($pur, ['kuantiti' => 1, 'hargabeli' => 10000, 'subtotal' => 10000, 'status' => 0]);
    }
}
