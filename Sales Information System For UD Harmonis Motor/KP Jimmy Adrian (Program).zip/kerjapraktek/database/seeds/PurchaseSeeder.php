<?php
use Illuminate\Database\Seeder;

class PurchaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('id_ID');
        $emp = DB::table('employees')->first();
        $sup = DB::table('suppliers')->first();
        $stat = ['pesan', 'dikirim', 'lunas'];

        DB::table('purchases')->insert([
            'employee_id' => $emp->id,
            'supplier_id' => $sup->id,
            'tanggalbuat' => $faker->date($format = 'Y-m-d', $max = 'now'),
            'jatuhtempo' => $faker->date($format = 'Y-m-d', $max = 'now'),
            'total' => 100000,
            'statusbeli' => $stat[array_rand($stat)]
        ]);
    }
}
