<?php
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $prods = ['Aki', 'Busi', 'Lampu Depan', 'Lampu Rem', 'Spion', 'Kap', 'Wiper'];
        $cats = DB::table('categories')->get();
        $year = ['2011', '2012', '2013', '2014', '2015', '2016', '2017'];

        foreach ($cats as $cat) {
            foreach ($prods as $prod) {
                DB::table('products')->insert([
                    'category_id' => $cat->id,
                    'nama' => $prod,
                    'tahun' => $year[array_rand($year)],
                    'stok' => 5,
                    'hargajual' => 0
                ]);
            }
        }
    }
}
