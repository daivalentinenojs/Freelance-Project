<?php
use Illuminate\Database\Seeder;
use App\Product;
use App\Sale;

class ProductSaleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $prod = Product::first();
        $sal = Sale::first();
        $prod->sales()->attach($sal, ['kuantiti' => 1, 'hargajual' => 10000, 'subtotal' => 10000]);
    }
}
