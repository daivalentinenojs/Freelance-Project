<?php
use Illuminate\Database\Seeder;

class EmployeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('id_ID');
        $users = DB::table('users')->get();
        foreach ($users as $user) {
            DB::table('employees')->insert([
                'user_id' => $user->id,
                'nama' => $user->name,
                'alamat' => $faker->streetAddress,
                'notelepon' => $faker->phoneNumber
            ]);
        }
    }
}
