<?php
use Illuminate\Database\Seeder;

class SaleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('id_ID');
        $emp = DB::table('employees')->first();
        $cus = DB::table('customers')->first();
        $stat = ['sudah lunas', 'belum lunas', 'lewat jatuh tempo'];

        DB::table('sales')->insert([
            'employee_id' => $emp->id,
            'customer_id' => $cus->id,
            'tanggalbuat' => $faker->date($format = 'Y-m-d', $max = 'now'),
            'tanggalbayar' => $faker->date($format = 'Y-m-d', $max = 'now'),
            'total' => 100000,
            'statusjual' => $stat[array_rand($stat)]
        ]);
    }
}
