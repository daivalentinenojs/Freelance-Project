<?php
use Illuminate\Database\Seeder;

class CustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('id_ID');
        $bank = ['BCA', 'BRI', 'BNI', 'Mandiri'];
        for ($i = 0; $i < 10; $i++) {
            DB::table('customers')->insert([
                'nama' => $faker->name,
                'notelepon' => $faker->phoneNumber,
                'kota' => $faker->city,
                'bank' => $bank[array_rand($bank)],
                'statuslangganan' => rand(0, 1),
                'statusjual' => rand(0, 1),
                'statusterdaftar' => 1
            ]);
        }
    }
}
