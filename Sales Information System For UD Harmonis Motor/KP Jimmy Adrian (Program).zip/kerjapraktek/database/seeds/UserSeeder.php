<?php
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('id_ID');
        DB::table('users')->insert([
            'name' => 'admin',
            'email' => 'admin@gg',
            'password' => bcrypt('123'),
            'admin' => 1,
            'status' => 1
        ]);
        DB::table('users')->insert([
            'name' => 'budi',
            'email' => 'budi@gn',
            'password' => bcrypt('123'),
            'admin' => 0,
            'status' => 1
        ]);

        for ($i = 0; $i < 10; $i++) {
            DB::table('users')->insert([
                'name' => $faker->name,
                'email' => $faker->email,
                'password' => bcrypt('123'),
                'admin' => 0,
                'status' => 1
            ]);
        }
    }
}
