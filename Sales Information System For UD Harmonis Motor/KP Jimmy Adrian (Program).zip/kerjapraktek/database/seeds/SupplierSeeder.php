<?php
use Illuminate\Database\Seeder;

class SupplierSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create('id_ID');
        $bank = ['BCA', 'BNI', 'BRI', 'Mandiri'];
        for ($i = 0; $i < 10; $i++) {
            DB::table('suppliers')->insert([
                'norekening' => $faker->bankAccountNumber,
                'namarekening' => $faker->company,
                'bank' => $bank[array_rand($bank)],
                'alamat' => $faker->address,
                'notelepon' => $faker->phoneNumber,
                'statusbeli' => rand(0, 1),
                'statusterdaftar' => 1
            ]);
        }
    }
}
