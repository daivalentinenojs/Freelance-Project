<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSalesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedinteger('employee_id');
            $table->unsignedinteger('customer_id');
            $table->date('tanggalbuat');
            $table->date('tanggalbayar');
            $table->integer('total');
            $table->enum('statusjual', ['belum lunas', 'sudah lunas', 'lewat jatuh tempo']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sales');
    }
}
