 <?php $__env->startSection('title', 'Login - Harmonis Motor'); ?> <?php $__env->startSection('content'); ?>

<body class="bg-dark login">
	<div class="container">
		<div class="card card-login mx-auto mt-5">
			<div class="card-header text-center">Login</div>
			<div class="text-center">
				<img src="<?php echo e(asset('img/logo.png')); ?>" class="img-circle" alt="">
			</div>
			<div class="card-body text-center">
				<form action="<?php echo e(route('login')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
						<label for="exampleInputEmail1">Email</label>
						<input class="form-control centre" name="email" id="email" type="email" aria-describedby="emailHelp" placeholder="Masukkan email"
						 value="<?php echo e(old('email')); ?>" required autofocus> <?php if($errors->has('email')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('email')); ?></strong>
						</span>
						<?php endif; ?>
					</div>

					<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
						<label for="exampleInputPassword1">Kata Sandi</label>
						<input class="form-control centre" name="password" id="password" type="password" placeholder="Masukkan Kata Sandi" required> <?php if($errors->has('password')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('password')); ?></strong>
						</span>
						<?php endif; ?>
					</div>

					<div class="form-group">
						<div class="form-check">
							<label class="form-check-label"></label>
						</div>
					</div>
					<button type="submit" class="btn btn-primary btn-block">Login</button>
				</form>

			</div>
		</div>
	</div>
	<?php echo $__env->make('layouts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>