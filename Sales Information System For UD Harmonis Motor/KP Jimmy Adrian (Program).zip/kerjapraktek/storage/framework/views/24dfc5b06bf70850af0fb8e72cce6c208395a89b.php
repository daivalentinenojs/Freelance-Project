 <?php $__env->startSection('title', 'Data Kategori'); ?> <?php $__env->startSection('content'); ?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
	<!-- Navigation-->
	<?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Data Kategori</div>
				<div class="card-body">

					<?php echo $__env->make('layouts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<div class="pull-right" style="padding-bottom:20px">
						<button class="btn btn-success" data-toggle="modal" data-target="#modalAddKategori">
							<i class="fa fa-plus"></i> Tambah Kategori
						</button>
					</div>

					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Merek</th>
									<th>Status Produksi</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>Merk</th>
									<th>Status Produksi</th>
								</tr>
							</tfoot>
							<tbody>
								<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr id="<?php echo e($data->id); ?>">
									<td><?php echo e($data->nama); ?></td>
									<td><?php echo e($data->statusterdaftar == 1 ? 'Tersedia' : 'Diskontinu'); ?></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>

			</div>
		</div>

		<div class="modal fade" id="modalAddKategori">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Tambah Data Kategori</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="" method="post">
							<?php echo e(csrf_field()); ?>

							<p>
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" name="nama" placeholder="Masukkan Nama Kategori" required>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnAdd" class="btn btn-primary">
									<i class="fa fa-check"></i> Tambah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalEditKategori">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Ubah Data Kategori</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="<?php echo e(url('master/kategori/update')); ?>" method="post">
							<?php echo e(csrf_field()); ?>

							<p>
								<input type="hidden" id="id" name="id" value="">
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" id="nama" name="nama" placeholder="Masukkan Nama Kategori" required>
							</p>
							<p>
								<label class="col-lg-6">Status Produksi: </label>
								<select name="status" id="status" class="col-lg-4">
									<option value="0">Diskontinu</option>
									<option value="1">Tersedia</option>
								</select>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnEdit" class="btn btn-primary">
									<i class="fa fa-check"></i> Ubah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<!--Footer -->
		<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>

		<!--Script-->
		<?php echo $__env->make('layouts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<script>
			$(document).ready(function () {
				$('#dataTable').on('click', 'tbody tr', function () { //open modal when click Category
					var id = $(this).closest('tr').attr('id'); //get id of clicked row

					$.post("<?php echo e(url('master/kategori/edit')); ?>", {
							'id': id,
							'_token': "<?php echo e(csrf_token()); ?>"
						},
						function (data) {
							$('#id').val(data.id);
							$('#nama').val(data.nama);
							$('#status').val(data.status);
							$('#modalEditKategori').modal('show');
						});
				});
			});
		</script>
	</div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>