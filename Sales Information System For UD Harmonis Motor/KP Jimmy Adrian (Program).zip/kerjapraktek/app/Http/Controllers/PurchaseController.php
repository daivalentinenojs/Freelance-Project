<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PDF;
use App\Purchase;
use App\Supplier;
use App\Product;
use Illuminate\Support\Facades\Auth;
use App\Employee;
use Illuminate\Support\Facades\Session;

class PurchaseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $pur = Purchase::all();
        return view('nota.notabeli', compact('pur'));
    }

    public function create()
    {
        $emp = Auth::user()->name;
        $sup = Supplier::all();
        $pro = Product::all();
        return view('nota.buatnotabeli', compact('sup', 'pro', 'emp'));
    }

    public function processInput(Request $request)
    {
        $id = Auth::user()->id;
        $emp = Employee::where('user_id', $id)->first();
        $data = $request->objData;
        $tanggalbuat = $request->tanggalbuat;
        $jatuhtempo = $request->jatuhtempo;
        $pemasok = $request->pemasok;
        $total = $request->total;

        $pur = Purchase::create([
            'employee_id' => $emp->id,
            'supplier_id' => $pemasok,
            'tanggalbuat' => $tanggalbuat,
            'jatuhtempo' => $jatuhtempo,
            'total' => $total,
            'statusbeli' => 'pesan'
        ]);

        foreach ($data as $d) {
            $pur->products()->attach($d['kode'], ['kuantiti' => $d['kuantiti'], 'hargabeli' => $d['harga'], 'subtotal' => $d['subtotal'], 'status' => 0]);
        }

        $sup = Supplier::find($pemasok);
        $sup->statusbeli = 0;
        $sup->save();

        Session::flash('flash_msg', 'Data Nota Beli Berhasil Disimpan');
        return 'success';
    }

    public function show(Request $request)
    {
        $admin = Auth::user()->admin;
        $id = $request->id;
        $pur = Purchase::find($id);
        $data = ([
            'admin' => $admin,
            'nota' => $pur->id,
            'pemasok' => $pur->supplier->namarekening,
            'karyawan' => $pur->employee->nama,
            'tanggalbuat' => $pur->tanggalbuat,
            'jatuhtempo' => $pur->jatuhtempo,
            'total' => $pur->total,
            'statusbeli' => $pur->statusbeli
        ]);
        return $data;
    }

    public function update(Request $request)
    {
        $id = $request->id;
        $statusbeli = $request->statusbeli;
        $pur = Purchase::find($id);
        switch ($statusbeli) {
            case "0":
                $pur->statusbeli = 'pesan';
                break;
            case "1":
                $pur->statusbeli = 'dikirim';
                break;
            case "2":
                $pur->statusbeli = 'lunas';
                break;
        }

        $pur->save();
        Session::flash('flash_msg', 'Data Nota Beli Berhasil Diubah');
        return redirect('nota/beli');
    }

    public function showProduct(Request $request)
    {
        $id = $request->id;
        $pur = Purchase::find($id);
        $table = '';
        $status = '';
        foreach ($pur->products as $p) {
            if ($p->pivot->status == 0) {
                $status = "Dipesan";
            } else {
                $status = "Diterima";
            }
            $table .=
                '<tr="' . $p->id . '">' .
                '<td>' . $p->id . '</td>' .
                '<td>' . $p->nama . ' - ' . $p->category->nama . '</td>' .
                '<td>' . $p->pivot->kuantiti . '</td>' .
                '<td>Rp. ' . $p->pivot->hargabeli . '</td>' .
                '<td>Rp. ' . $p->pivot->subtotal . '</td>' .
                '<td>' . $status . '</td>' .
                '</tr>';
        }
        return $table;
    }

    public function changeProductStatus(Request $request)
    {
        $id = $request->id;
        $nota = $request->nota;
        $kuantiti = $request->kuantiti;
        $status = $request->status;
        $pur = Purchase::find($nota);
        $pur->products()->updateExistingPivot($id, ['status' => $status, 'kuantiti' => $kuantiti]);
        if ($status == 1) {
            $pro = Product::find($id);
            $pro->stok += $kuantiti;
            $pro->save();
        }

        Session::flash('flash_msg', 'Status Barang Berhasil Diubah');
        return redirect('nota/beli');
    }

    public function print(Request $request)
    {
        $id = $request->id;
        $pur = Purchase::find($id);
        $pro = $pur->products;
        $pdf = PDF::loadView('nota.pdfnotabeli', compact('pur', 'pro'));
        return $pdf->download('notabeli.pdf');
    }
}
