<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use Illuminate\Support\Facades\Session;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $cat = Category::orderBy('id', 'desc')->get();
        return view('master.kategori', compact('cat'));
    }

    public function store(Request $request)
    {
        $nama = $request->nama;
        $cat = Category::firstOrCreate(
            [
                'nama' => $nama
            ],
            [
                'statusterdaftar' => 1
            ]
        );

        if ($cat->wasRecentlyCreated) {
            Session::flash('flash_msg', 'Data Kategori Berhasil Disimpan');
        } else {
            Session::flash('error_msg', 'Data Kategori Sudah Ada');
        }

        return redirect('master/kategori');
    }

    public function edit(Request $request)
    {
        $id = $request->id;
        $cat = Category::find($id);

        $data = ([
            'id' => $cat->id,
            'nama' => $cat->nama,
            'status' => $cat->statusterdaftar
        ]);

        return $data;
    }

    public function update(Request $request)
    {
        $id = $request->id;
        $cat = Category::find($id);

        $cat->nama = $request->nama;
        $cat->statusterdaftar = $request->status;

        try {
            $cat->save();
            Session::flash('flash_msg', 'Data Kategori Berhasil Diubah');
        } catch (\Exception $e) {
            Session::flash('error_msg', 'Data Kategori Sudah Ada');
        }

        return redirect('master/kategori');
    }
}
