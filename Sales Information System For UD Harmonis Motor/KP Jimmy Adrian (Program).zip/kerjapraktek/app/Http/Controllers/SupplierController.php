<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Supplier;
use Illuminate\Support\Facades\Session;

class SupplierController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }

    public function index()
    {
        $sup = Supplier::orderBy('id', 'desc')->get();
        return view('master.pemasok', compact('sup'));
    }

    public function store(Request $request)
    {
        $nama = $request->nama;
        $norekening = $request->norekening;
        $notelepon = $request->notelepon;
        $alamat = $request->alamat;
        $bank = $request->bank;

        Supplier::create([
            'namarekening' => $nama,
            'notelepon' => $notelepon,
            'alamat' => $alamat,
            'norekening' => $norekening,
            'bank' => $bank,
            'statusbeli' => 1,
            'statusterdaftar' => 1
        ]);

        Session::flash('flash_msg', 'Data Pemasok Berhasil Disimpan');
        return redirect('master/pemasok');
    }

    public function edit(Request $request)
    {
        $id = $request->id;

        $sup = Supplier::find($id);

        $data = ([
            'id' => $sup->id,
            'nama' => $sup->namarekening,
            'alamat' => $sup->alamat,
            'bank' => $sup->bank,
            'notelepon' => $sup->notelepon,
            'norekening' => $sup->norekening,
            'statusterdaftar' => $sup->statusterdaftar,
            'statusbeli' => $sup->statusbeli
        ]);

        return $data;
    }

    public function update(Request $request)
    {
        $id = $request->id;
        $nama = $request->nama;
        $bank = $request->bank;
        $alamat = $request->alamat;
        $notelepon = $request->notelepon;
        $norekening = $request->norekening;
        $statusbeli = $request->statusbeli;
        $statusterdaftar = $request->statusterdaftar;

        $sup = Supplier::find($id);

        $sup->namarekening = $nama;
        $sup->bank = $bank;
        $sup->alamat = $alamat;
        $sup->notelepon = $notelepon;
        $sup->norekening = $norekening;
        $sup->statusbeli = $statusbeli;
        $sup->statusterdaftar = $statusterdaftar;

        $sup->save();

        Session::flash('flash_msg', 'Data Pemasok Berhasil Diubah');
        return redirect('master/pemasok');
    }
}
