<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
use App\User;
use Illuminate\Support\Facades\Session;
use PHPUnit\Framework\Exception;

class EmployeeController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }

    public function index()
    {
        $emp = Employee::orderBy('id', 'desc')->get();
        return view('master.karyawan', compact('emp'));
    }

    public function store(Request $request)
    {
        $nama = $request->nama;
        $alamat = $request->alamat;
        $email = $request->email;
        $notelepon = $request->notelepon;
        $password = $request->password;

        $user = User::firstOrNew(
            [
                'email' => $email
            ],
            [
                'name' => $nama,
                'password' => bcrypt($password),
                'admin' => 0,
                'status' => 1
            ]
        );

        if (! ($user->exists)) {
            $user->save();
            $emp = new Employee([
                'nama' => $nama,
                'alamat' => $alamat,
                'notelepon' => $notelepon
            ]);
            $user->employees()->save($emp);
            Session::flash('flash_msg', 'Data Karyawan Berhasil Disimpan');
        } else {
            Session::flash('error_msg', 'Data Karyawan Sudah Ada');
        }

        return redirect('master/karyawan');

    }

    public function edit(Request $request)
    {
        $id = $request->id;

        $emp = Employee::find($id);

        $data = ([
            'id' => $emp->id,
            'nama' => $emp->nama,
            'alamat' => $emp->alamat,
            'email' => $emp->user->email,
            'notelepon' => $emp->notelepon,
            'admin' => $emp->user->admin,
            'status' => $emp->user->status
        ]);

        return $data;
    }

    public function update(Request $request)
    {
        $id = $request->id;
        $nama = $request->nama;
        $email = $request->email;
        $password = $request->password;
        $alamat = $request->alamat;
        $notelepon = $request->notelepon;
        $admin = $request->admin;
        $status = $request->status;

        $emp = Employee::find($id);

        try {
            User::where('id', $emp->user_id)->update([
                'name' => $nama,
                'email' => $email,
                'password' => bcrypt($password),
                'admin' => $admin,
                'status' => $status
            ]);
            $emp->nama = $nama;
            $emp->alamat = $alamat;
            $emp->notelepon = $notelepon;
            $emp->save();
            Session::flash('flash_msg', 'Data Karyawan Berhasil Diubah');
        } catch (\Exception $e) {
            Session::flash('error_msg', 'Email Karyawan Tidak Boleh Sama');
        }

        return redirect('master/karyawan');
    }
}
