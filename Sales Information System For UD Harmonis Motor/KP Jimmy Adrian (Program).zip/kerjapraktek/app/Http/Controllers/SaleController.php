<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PDF;
use App\Sale;
use App\Customer;
use App\Product;
use Illuminate\Support\Facades\Auth;
use App\Employee;
use Illuminate\Support\Facades\Session;

class SaleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $checkSale = Sale::where('tanggalbayar', '<', date('Y-m-d'))->get();
        foreach ($checkSale as $check) {
            $check->statusjual = 'lewat jatuh tempo';
            $check->save();
        }
        $sal = Sale::all();
        return view('nota.notajual', compact('sal'));
    }

    public function create()
    {
        $emp = Auth::user()->name;
        $cus = Customer::all();
        $pro = Product::where('stok', '>', 0)->get();
        return view('nota.buatnotajual', compact('cus', 'pro', 'emp'));
    }

    public function processInput(Request $request)
    {
        $id = Auth::user()->id;
        $emp = Employee::where('user_id', $id)->first();
        $data = $request->objData;
        $tanggalbuat = $request->tanggalbuat;
        $tanggalbayar = $request->tanggalbayar;
        $pembeli = $request->pembeli;
        $total = $request->total;

        $sal = Sale::create([
            'employee_id' => $emp->id,
            'customer_id' => $pembeli,
            'tanggalbuat' => $tanggalbuat,
            'tanggalbayar' => $tanggalbayar,
            'total' => $total,
            'statusjual' => 'belum lunas'
        ]);

        foreach ($data as $d) {
            $sal->products()->attach($d['kode'], ['kuantiti' => $d['kuantiti'], 'hargajual' => $d['harga'], 'subtotal' => $d['subtotal']]);
            $pro = Product::find($d['kode']);
            $pro->stok--;
            $pro->save();
        }

        $cus = Customer::find($pembeli);
        $cus->statusjual = 0;
        $cus->save();

        Session::flash('flash_msg', 'Data Nota Jual Berhasil Disimpan');
        return 'success';
    }

    public function show(Request $request)
    {
        $admin = Auth::user()->admin;
        $id = $request->id;
        $sal = Sale::find($id);
        $data = ([
            'admin' => $admin,
            'nota' => $sal->id,
            'pembeli' => $sal->customer->nama,
            'karyawan' => $sal->employee->nama,
            'tanggalbuat' => $sal->tanggalbuat,
            'tanggalbayar' => $sal->tanggalbayar,
            'total' => $sal->total,
            'statusjual' => $sal->statusjual
        ]);
        return $data;
    }

    public function update(Request $request)
    {
        $id = $request->id;
        $statusjual = $request->statusjual;
        $sal = Sale::find($id);
        switch ($statusjual) {
            case "0":
                $sal->statusjual = 'belum lunas';
                break;
            case "1":
                $sal->statusjual = 'sudah lunas';
                $sal->customer->statusjual = 1;
                $sal->customer->save();
                break;
            case "2":
                $sal->statusjual = 'lewat jatuh tempo';
                break;
        }

        $sal->save();
        Session::flash('flash_msg', 'Data Nota Jual Berhasil Diubah');
        return redirect('nota/jual');
    }

    public function showProduct(Request $request)
    {
        $id = $request->id;
        $sal = Sale::find($id);
        $table = '';
        $status = '';
        foreach ($sal->products as $p) {
            $table .=
                '<tr="' . $p->id . '">' .
                '<td>' . $p->id . '</td>' .
                '<td>' . $p->nama . ' - ' . $p->category->nama . '</td>' .
                '<td>' . $p->pivot->kuantiti . '</td>' .
                '<td>Rp. ' . $p->pivot->hargajual . '</td>' .
                '<td>Rp. ' . $p->pivot->subtotal . '</td>' .
                '</tr>';
        }
        return $table;
    }

    public function checkStock(Request $request)
    {
        $id = $request->id;
        $pro = Product::find($id);
        return $pro;
    }

    public function print(Request $request)
    {
        $id = $request->id;
        $sal = Sale::find($id);
        $pro = $sal->products;
        $pdf = PDF::loadView('nota.pdfnotajual', compact('sal', 'pro'));
        return $pdf->download('notajual.pdf');
    }
}
