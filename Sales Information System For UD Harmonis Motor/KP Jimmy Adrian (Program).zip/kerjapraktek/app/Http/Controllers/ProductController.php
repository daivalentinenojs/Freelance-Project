<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Category;
use Illuminate\Support\Facades\Session;

class ProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $pro = Product::orderBy('id', 'desc')->get();
        $cat = Category::where('statusterdaftar', 1)->get();
        return view('master.barang', compact('pro', 'cat'));
    }

    public function store(Request $request)
    {
        $nama = $request->nama;
        $merek = $request->merek;
        $tahun = $request->tahun;
        $harga = $request->harga;

        $cat = Category::find($merek);

        $pro = new Product([
            'nama' => $nama,
            'tahun' => $tahun,
            'hargajual' => $harga,
            'stok' => 0
        ]);

        $cat->products()->save($pro);

        Session::flash('flash_msg', 'Data Barang Berhasil Disimpan');
        return redirect('master/barang');
    }

    public function edit(Request $request)
    {
        $id = $request->id;

        $pro = Product::find($id);

        $data = ([
            'id' => $pro->id,
            'nama' => $pro->nama,
            'merek' => $pro->category->id,
            'tahun' => $pro->tahun,
            'stok' => $pro->stok,
            'harga' => $pro->hargajual
        ]);

        return $data;
    }

    public function update(Request $request)
    {
        $id = $request->id;
        $nama = $request->nama;
        $merek = $request->merek;
        $tahun = $request->tahun;
        $harga = $request->harga;

        $cat = Category::find($merek);
        $pro = Product::find($id);

        $pro->nama = $nama;
        $pro->tahun = $tahun;
        $pro->hargajual = $harga;
        $pro->category()->associate($cat);
        $pro->save();

        Session::flash('flash_msg', 'Data Barang Berhasil Diubah');
        return redirect('master/barang');
    }
}
