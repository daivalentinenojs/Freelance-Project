<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use Illuminate\Support\Facades\Session;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }

    public function index()
    {
        $cus = Customer::orderBy('id', 'desc')->get();
        return view('master.pembeli', compact('cus'));
    }

    public function store(Request $request)
    {
        $nama = $request->nama;
        $notelepon = $request->notelepon;
        $kota = $request->kota;
        $bank = $request->bank;

        Customer::create([
            'nama' => $nama,
            'notelepon' => $notelepon,
            'kota' => $kota,
            'bank' => $bank,
            'statuslangganan' => 1,
            'statusjual' => 1,
            'statusterdaftar' => 1
        ]);

        Session::flash('flash_msg', 'Data Pembeli Berhasil Disimpan');
        return redirect('master/pembeli');
    }

    public function edit(Request $request)
    {
        $id = $request->id;

        $cus = Customer::find($id);

        $data = ([
            'id' => $cus->id,
            'nama' => $cus->nama,
            'kota' => $cus->kota,
            'bank' => $cus->bank,
            'notelepon' => $cus->notelepon,
            'statusterdaftar' => $cus->statusterdaftar,
            'statusjual' => $cus->statusjual,
            'statuslangganan' => $cus->statuslangganan
        ]);

        return $data;
    }

    public function update(Request $request)
    {
        $id = $request->id;
        $nama = $request->nama;
        $bank = $request->bank;
        $kota = $request->kota;
        $notelepon = $request->notelepon;
        $statuslangganan = $request->statuslangganan;
        $statusjual = $request->statusjual;
        $statusterdaftar = $request->statusterdaftar;

        $cus = Customer::find($id);

        $cus->nama = $nama;
        $cus->bank = $bank;
        $cus->kota = $kota;
        $cus->notelepon = $notelepon;
        $cus->statuslangganan = $statuslangganan;
        $cus->statusjual = $statusjual;
        $cus->statusterdaftar = $statusterdaftar;

        $cus->save();

        Session::flash('flash_msg', 'Data Pembeli Berhasil Diubah');
        return redirect('master/pembeli');
    }
}
