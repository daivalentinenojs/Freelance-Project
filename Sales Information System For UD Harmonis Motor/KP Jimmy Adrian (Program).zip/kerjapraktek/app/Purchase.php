<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    public $timestamps = false;
    protected $fillable = ['employee_id', 'supplier_id', 'tanggalbuat', 'jatuhtempo', 'total', 'statusbeli'];

    public function products()
    {
        return $this->belongsToMany(Product::class)->withPivot('kuantiti', 'hargabeli', 'subtotal', 'status');
    }

    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function getTanggalbuatAttribute($value)
    {
        return date('d-m-Y', strtotime($value));
    }

    public function getJatuhtempoAttribute($value)
    {
        return date('d-m-Y', strtotime($value));
    }
}
