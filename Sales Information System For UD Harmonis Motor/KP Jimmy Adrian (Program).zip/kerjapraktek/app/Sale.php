<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    public $timestamps = false;
    protected $fillable = ['employee_id', 'customer_id', 'tanggalbuat', 'tanggalbayar', 'total', 'statusjual'];

    public function products()
    {
        return $this->belongsToMany(Product::class)->withPivot('kuantiti', 'hargajual', 'subtotal');
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function getTanggalbuatAttribute($value)
    {
        return date('d-m-Y', strtotime($value));
    }
    public function getTanggalbayarAttribute($value)
    {
        return date('d-m-Y', strtotime($value));
    }

}
