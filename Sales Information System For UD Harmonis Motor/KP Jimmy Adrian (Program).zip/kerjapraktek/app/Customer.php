<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    public $timestamps = false;
    protected $fillable = ['nama', 'notelepon', 'kota', 'bank', 'statuslangganan', 'statusjual', 'statusterdaftar'];

    public function sales()
    {
        return $this->hasMany(Sale::class);
    }
}
