<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public $timestamps = false;
    protected $fillable = ['category_id', 'nama', 'tahun', 'stok', 'hargajual'];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function sales()
    {
        return $this->belongsToMany(Sale::class)->withPivot('kuantiti', 'hargajual', 'subtotal');
    }

    public function purchases()
    {
        return $this->belongsToMany(Purchase::class)->withPivot('kuantiti', 'hargabeli', 'subtotal', 'status');
    }
}
