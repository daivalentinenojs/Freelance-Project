<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    public $timestamps = false;
    protected $fillable = ['norekening', 'namarekening', 'bank', 'alamat', 'notelepon', 'statusbeli', 'statusterdaftar'];

    public function purchases()
    {
        return $this->hasMany(Purchase::class);
    }
}
