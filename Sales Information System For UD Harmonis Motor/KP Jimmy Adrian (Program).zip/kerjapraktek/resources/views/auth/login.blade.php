@extends('layouts.master') @section('title', 'Login - Harmonis Motor') @section('content')

<body class="bg-dark login">
	<div class="container">
		<div class="card card-login mx-auto mt-5">
			<div class="card-header text-center">Login</div>
			<div class="text-center">
				<img src="{{asset('img/logo.png')}}" class="img-circle" alt="">
			</div>
			<div class="card-body text-center">
				<form action="{{route('login')}}" method="POST">
					{{ csrf_field() }}
					<div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
						<label for="exampleInputEmail1">Email</label>
						<input class="form-control centre" name="email" id="email" type="email" aria-describedby="emailHelp" placeholder="Masukkan email"
						 value="{{ old('email') }}" required autofocus> @if ($errors->has('email'))
						<span class="help-block">
							<strong>{{ $errors->first('email') }}</strong>
						</span>
						@endif
					</div>

					<div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
						<label for="exampleInputPassword1">Kata Sandi</label>
						<input class="form-control centre" name="password" id="password" type="password" placeholder="Masukkan Kata Sandi" required> @if ($errors->has('password'))
						<span class="help-block">
							<strong>{{ $errors->first('password') }}</strong>
						</span>
						@endif
					</div>

					<div class="form-group">
						<div class="form-check">
							<label class="form-check-label"></label>
						</div>
					</div>
					<button type="submit" class="btn btn-primary btn-block">Login</button>
				</form>

			</div>
		</div>
	</div>
	@include('layouts.script')
</body>
@endsection