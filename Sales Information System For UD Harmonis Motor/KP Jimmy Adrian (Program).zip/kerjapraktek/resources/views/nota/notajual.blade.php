@extends('layouts.master') @section('title', 'Nota Jual') @section('content')

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
	<!-- Navigation-->
	@include('layouts.sidebar')
	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Nota Jual</div>
				<div class="card-body">

					@include('layouts.flash')

					<div class="pull-right" style="padding-bottom:20px">
						<a href="{{url('nota/jual/buat')}}" class="btn btn-success">
							<i class="fa fa-plus"></i> Buat Nota Jual
						</a>
					</div>

					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Nomor Nota</th>
									<th>Nama Pembeli</th>
									<th>Nama Karyawan</th>
									<th>Tanggal Buat</th>
									<th>Tanggal Bayar</th>
									<th>Total</th>
									<th>Status Jual</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>Nomor Nota</th>
									<th>Nama Pembeli</th>
									<th>Nama Karyawan</th>
									<th>Tanggal Buat</th>
									<th>Tanggal Bayar</th>
									<th>Total</th>
									<th>Status Jual</th>
								</tr>
							</tfoot>
							<tbody>
								@foreach($sal as $data)
								<tr id="{{$data->id}}">
									<td>{{$data->id}}</td>
									<td>{{$data->customer->nama}}</td>
									<td>{{$data->employee->nama}}</td>
									<td>{{$data->tanggalbuat}}</td>
									<td>{{$data->tanggalbayar}}</td>
									<td>Rp. {{number_format( $data->total, 0 , '' , '.' )}}</td>
									<td>{{ucfirst($data->statusjual)}}</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalShowNota">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Detail Nota Jual</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="{{url('nota/jual/ubah')}}" method="post" id="formUpdateNota">
							{{csrf_field()}}
							<p>
								<input type="hidden" id="id" name="id">
								<label class="col-lg-4">No Nota: </label>
								<input type="text" class="col-lg-6" id="nota" disabled>
							</p>
							<p>
								<label class="col-lg-4">Tanggal Buat: </label>
								<input type="text" class="col-lg-6" id="tanggalbuat" disabled>
							</p>
							<p>
								<label class="col-lg-4">Tanggal Bayar: </label>
								<input type="text" class="col-lg-6" id="tanggalbayar" disabled>
							</p>
							<p>
								<label class="col-lg-4">Total: </label>
								<input type="text" class="col-lg-6" id="total" disabled>
							</p>
							<p>
								<label class="col-lg-4">Nama Pembeli: </label>
								<input type="text" class="col-lg-6" id="pembeli" disabled>
							</p>
							<p>
								<label class="col-lg-4">Nama Karyawan: </label>
								<input type="text" class="col-lg-6" id="karyawan" disabled>
							</p>
							<p>
								<label class="col-lg-4">Status Jual: </label>
								<select class="col-lg-4" name="statusjual" id="statusjual">
									<option value="0">Belum Lunas</option>
									<option value="1">Sudah Lunas</option>
									<option value="2">Lewat Jatuh Tempo</option>
								</select>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnUbah" class="btn btn-primary">
									<i class="fa fa-check"></i> Ubah</button>
								<button class="btn btn-success" style="text-align:center" id="btnCetak" class="btn btn-primary">
									<i class="fa fa-print"></i> Cetak</button>
							</p>
						</form>
						<br>
						<div class="table-responsive">
							<table id="tabelBarang" class="table table-striped table-bordered table-hover nowrap">
								<thead>
									<tr>
										<th>Kode Barang</th>
										<th>Nama Barang</th>
										<th>Kuantiti</th>
										<th>Harga Jual</th>
										<th>Subtotal</th>
									</tr>
								</thead>
								<tbody id="dataNota">
								</tbody>
							</table>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>


		<!--Footer -->
		@include('layouts.footer')

		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>

		<!--Script-->
		@include('layouts.script')
		<script>
			$(document).ready(function () {
				var nota = 0;
				$('#dataTable').on('click', 'tbody tr', function (e) { //delete product
					e.preventDefault();
					var status = 0;
					var id = $(this).closest('tr').attr('id');
					nota = id;
					$('#id').val(id);
					$.post("{{url('nota/jual/show')}}", {
							'id': id,
							'_token': "{{csrf_token()}}"
						},
						function (data) {
							var admin = data.admin;
							$('#nota').val(data.nota);
							$('#pembeli').val(data.pembeli);
							$('#karyawan').val(data.karyawan);
							$('#tanggalbuat').val(data.tanggalbuat);
							$('#tanggalbayar').val(data.tanggalbayar);
							$('#total').val('Rp. ' + data.total);

							switch (data.statusjual) {
								case "belum lunas":
									status = 0;
									break;
								case "sudah lunas":
									status = 1;
									if(admin == 0){
										$('#statusjual').attr('disabled', true);
									}
									break;
								case "lewat jatuh tempo":
									status = 2;
									if(admin == 0){
										$('#statusjual').attr('disabled', true);
									}
									break;
							}

							$('#statusjual').val(status);

							$.post("{{url('nota/jual/show/barang')}}", {
									'id': id,
									'_token': "{{csrf_token()}}"
								},
								function (data) {
									$('#dataNota').html('');
									$('#dataNota').html(data);
								});
						});
					$('#modalShowNota').modal('show');
				});

				$('#btnCetak').on('click', function (e) {
					e.preventDefault();
					var id = $('#id').val();
					$.post("{{url('nota/jual/cetak')}}", {
							'id': id,
							'_token': "{{csrf_token()}}"
						},
						function (data) {
							//redirect to print page
						});
				});

				$('#formUpdateNota').on('submit',function(e){
					e.preventDefault();
					$('#statusjual').attr('disabled', false);
					$('#formUpdateNota')[0].submit();
				});
			});
		</script>
	</div>
</body>
@endsection