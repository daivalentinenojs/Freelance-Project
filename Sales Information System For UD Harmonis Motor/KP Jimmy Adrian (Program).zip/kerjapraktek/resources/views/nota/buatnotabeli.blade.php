@extends('layouts.master') @section('title', 'Buat Nota Beli') @section('content')

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
	<!-- Navigation-->
	@include('layouts.sidebar')
	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Buat Nota Beli</div>

				<div class="card-body col-lg-12">
					<div class="col-lg-6 pull-right">
						<label for="tanggalbuat" class="col-lg-4">Tanggal Buat</label>
						<input type="date" id="tanggalbuat" name="tanggalbuat" class="col-lg-6" min="{{date('Y-m-d')}}" value="{{date('Y-m-d')}}"
						 data-date-format="dd-mm-yyyy" data-date-viewmode="years" required disabled>
						<span class="fa fa-calendar"></span>
						<label for="jatuhtempo" class="col-lg-4">Jatuh Tempo</label>
						<input type="date" id="jatuhtempo" name="jatuhtempo" class="col-lg-6" min="{{date('Y-m-d')}}" value="{{date('Y-m-d')}}" data-date-format="dd-mm-yyyy"
						 data-date-viewmode="years" required>
						<span class="fa fa-calendar"></span>

						<div class="pull-right" style="margin-top: 80px">
							<label for="total">Total</label>
							<input class="text-right" type="text" disabled id="total" value="Rp. 0">
						</div>
					</div>

					<div class="col-lg-6 pull-left">
						<form action="" id="formInputBarang">
							<label class="col-lg-4" for="pemasok">Nama Pemasok</label>
							<select class="col-lg-4" name="pemasok" id="pemasok">
								@foreach($sup as $data)
								<option value="{{$data->id}}">{{$data->namarekening}}</option>
								@endforeach
							</select>
							<button class="btn btn-primary" id="btnPemasok">Set</button>
							<button style="display:none" id="btnGanti" class="btn btn-outline-danger">Ganti</button>
							<br>
							<br>
							<br>
							<label class="col-lg-4" for="barang">Nama Barang</label>
							<select class="col-lg-4" name="barang" id="barang">
								@foreach($pro as $data)
								<option value="{{$data->id}}">{{$data->category->nama}} - {{$data->nama}}</option>
								@endforeach
							</select>
							<label class="col-lg-4" for="kuantiti">Kuantiti</label>
							<input class="col-lg-4" type="number" id="kuantiti" name="kuantiti" value="1" min=1 required>
							<label class="col-lg-4" for="hargabeli">Harga Beli</label>
							<input class="col-lg-4" type="number" id="harga" name="harga" value="1000" min=0 step=500 required>
							<div class="text-center">
								<button style="display:none" type="submit" class="btn btn-success" id="btnAddBarang">Tambah</button>
							</div>
						</form>
					</div>
				</div>
				<br>
				<br>

				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
						<thead>
							<tr>
								<th>Kode Barang</th>
								<th>Nama Barang</th>
								<th>Harga Beli</th>
								<th>Kuantiti</th>
								<th>Sub Total</th>
							</tr>
						</thead>
						<tfoot>
							<tr>
								<th>Kode Barang</th>
								<th>Nama Barang</th>
								<th>Harga Beli</th>
								<th>Kuantiti</th>
								<th>Sub Total</th>
							</tr>
						</tfoot>
						<tbody>

						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="col-lg-12 text-center">
			<button style="display:none" class="btn btn-success" id="btnSimpan">Simpan Nota</button>
		</div>
		<br>
		<br>
	</div>

	<!--Footer -->
	@include('layouts.footer')

	<!-- Scroll to Top Button-->
	<a class="scroll-to-top rounded" href="#page-top">
		<i class="fa fa-angle-up"></i>
	</a>

	<!--Script-->
	@include('layouts.script')
	<script>
		$(document).ready(function () {
			var total = 0;
			var duplicate = 0;
			var rowIndex = 0;

			$('#jatuhtempo').on('change', function (e) { //prevent end date less than start date
				var tanggalbuat = $('#tanggalbuat').val();
				var jatuhtempo = $('#jatuhtempo').val();

				if (jatuhtempo < tanggalbuat) {
					$('#jatuhtempo').val(tanggalbuat);
				}
			});

			$('#dataTable').on('click', 'tbody tr', function (e) { //delete product
				e.preventDefault();
				var row = $(this).closest('tr');
				var id = $(this).closest('tr').attr('id');
				var subTotal = row.find('td:eq(4)').text();
				total -= parseInt(subTotal.replace('Rp. ', ''));
				tbl.row('tr#' + id).remove().draw(false);
				$('#total').val('Rp. ' + total);
			});

			$('#formInputBarang').on('submit', function (e) { //add Product to purchase invoice table
				e.preventDefault();
				total = 0;
				var kode = $('#barang').val();
				var barang = $('#barang option:selected').text();;
				var harga = parseInt($('#harga').val());
				var kuantiti = parseInt($('#kuantiti').val());
				var subTotal = harga * kuantiti;

				$('tbody tr').each(function () {
					var id = $(this).closest('tr').attr('id');
					if (id == kode) {
						rowIndex = $(this).index();
						duplicate++;
					}
				});

				if (duplicate == 0) { //check if there's same product already in table
					tbl.row.add([kode, barang, 'Rp. ' + harga, kuantiti, 'Rp. ' + subTotal]).node().id = kode;
					tbl.draw(false);
				} else {
					duplicate = 0;
					kuantiti += parseInt(tbl.cell(rowIndex, 3).data());
					subTotal += parseInt(tbl.cell(rowIndex, 4).data().replace('Rp. ', ''));
					tbl.cell(rowIndex, 2).data('Rp. ' + harga);
					tbl.cell(rowIndex, 3).data(kuantiti);
					tbl.cell(rowIndex, 4).data('Rp. ' + subTotal);
					tbl.draw(false);
				}

				$('tbody tr').each(function () {
					var row = $(this).closest('tr');
					var subTotal = row.find('td:eq(4)').text();
					total += parseInt(subTotal.replace('Rp. ', ''));
				});

				$('#total').val('Rp. ' + total);
			});

			$('#btnPemasok').on('click', function (e) { //lock Supplier
				e.preventDefault();
				swal({
						title: 'Pilih Pemasok?',
						text: 'Anda akan memilih ' + $('#pemasok option:selected').text(),
						icon: 'info',
						buttons: ['Batal', 'Yakin']
					})
					.then((confirm) => {
						if (confirm) {
							$('#pemasok').attr('disabled', true);
							$('#btnAddBarang').show();
							$('#btnGanti').show();
							$('#btnSimpan').show();
						}
					});
			});

			$('#btnGanti').on('click', function (e) { //change Supplier and reload
				e.preventDefault();
				swal({
						title: 'Ganti Pemasok?',
						text: 'Anda akan kehilangan data nota yang belum tersimpan',
						icon: 'warning',
						buttons: ['Batal', 'Yakin'],
						dangerMode: true,
					})
					.then((confirm) => {
						if (confirm) {
							location.reload();
						}
					});
			});

			$('#btnSimpan').on('click', function (e) { //save Purchase invoice
				e.preventDefault();
				var objData = [];
				var idx = 0;
				var tanggalbuat = $('#tanggalbuat').val();
				var jatuhtempo = $('#jatuhtempo').val();
				var pemasok = $('#pemasok').val();
				var total = $('#total').val().replace('Rp. ', '');
				var kode = 0;
				var harga = 0;
				var kuantiti = 0;
				var subtotal = 0;

				$('tbody tr').each(function () {
					var row = $(this).closest('tr');
					var kode = $(this).closest('tr').attr('id');
					var harga = row.find('td:eq(2)').text().replace('Rp. ', '');;
					var kuantiti = row.find('td:eq(3)').text();
					var subtotal = row.find('td:eq(4)').text().replace('Rp. ', '');;
					objData[idx] = {
						'kode': kode,
						'harga': harga,
						'kuantiti': kuantiti,
						'subtotal': subtotal
					};
					idx++;
				});

				$.post("{{url('nota/beli/buat')}}", {
						'tanggalbuat': tanggalbuat,
						'jatuhtempo': jatuhtempo,
						'pemasok': pemasok,
						'total': total,
						'objData': objData,
						'_token': "{{csrf_token()}}"
					},
					function (data) {
						window.location.replace('{{url('nota/beli')}}');
					});
			});
		});
	</script>
	</div>
</body>
@endsection