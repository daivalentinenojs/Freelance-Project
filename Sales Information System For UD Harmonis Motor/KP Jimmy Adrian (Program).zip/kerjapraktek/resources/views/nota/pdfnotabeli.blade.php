<html>

<head>
	<style type="text/css">
		table td,
		table th {
			border: 1px solid black;
		}

		body,
		table,
		div {
			text-align: center;
		}
	</style>
</head>

<body>
	<h1>
		<img src="{{asset('img/logo.png')}}" alt=""> Nota Beli UD Harmonis Motor</h1>
	<br>
	<div>
		<br/>

		<div>
			<p>Nomor Nota:
				<strong>{{$pur->id}}</strong>
			</p>
			<p>Total: Rp.
				<strong>{{number_format( $pur->total, 0 , '' , '.' )}}</strong>
			</p>
			<p>Nama Pemasok:
				<strong>{{$pur->supplier->namarekening}}</strong>
			</p>
			<p>Nama Karyawan:
				<strong>{{$pur->employee->nama}}</strong>
			</p>
			<p>Tanggal Buat:
				<strong>{{$pur->tanggalbuat}}</strong>
			</p>
			<p>Jatuh Tempo:
				<strong>{{$pur->jatuhtempo}}</strong>
			</p>
		</div>
		<br>
		<div>
			<table align="center">
				<thead>
					<tr>
						<th>Kode Barang</th>
						<th>Nama Barang</th>
						<th>Kuantiti</th>
						<th>Harga Beli</th>
						<th>Subtotal</th>
					</tr>
				</thead>
				<tbody>
					@foreach($pro as $data)
					<tr>
						<td>{{$data->id}}</td>
						<td>{{$data->nama}}</td>
						<td>{{$data->pivot->kuantiti}}</td>
						<td>Rp. {{number_format( $data->pivot->hargabeli, 0 , '' , '.' )}}</td>
						<td>Rp. {{number_format( $data->pivot->subtotal, 0 , '' , '.' )}}</td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div>
</body>

</html>