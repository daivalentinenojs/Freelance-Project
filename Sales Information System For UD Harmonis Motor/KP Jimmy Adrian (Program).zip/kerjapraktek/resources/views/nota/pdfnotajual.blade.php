<html>

<head>
	<style type="text/css">
		table td,
		table th {
			border: 1px solid black;
		}

		body,
		table,
		div {
			text-align: center;
		}
	</style>
</head>

<body>
	<h1>
		<img src="{{asset('img/logo.png')}}" alt=""> Nota Jual UD Harmonis Motor</h1>
	<br>
	<div>
		<br/>

		<div>
			<p>Nomor Nota:
				<strong>{{$sal->id}}</strong>
			</p>
			<p>Total: Rp.
				<strong>{{number_format( $sal->total, 0 , '' , '.' )}}</strong>
			</p>
			<p>Nama Pembeli:
				<strong>{{$sal->customer->nama}}</strong>
			</p>
			<p>Nama Karyawan:
				<strong>{{$sal->employee->nama}}</strong>
			</p>
			<p>Tanggal Buat:
				<strong>{{$sal->tanggalbuat}}</strong>
			</p>
			<p>Tanggal Bayar:
				<strong>{{$sal->tanggalbayar}}</strong>
			</p>
		</div>

		<div>
			<table align="center">
				<thead>
					<tr>
						<th>Kode Barang</th>
						<th>Nama Barang</th>
						<th>Kuantiti</th>
						<th>Harga Jual</th>
						<th>Subtotal</th>
					</tr>
				</thead>
				<tbody>
					@foreach($pro as $data)
					<tr>
						<td>{{$data->id}}</td>
						<td>{{$data->nama}}</td>
						<td>{{$data->pivot->kuantiti}}</td>
						<td>Rp. {{number_format( $data->pivot->hargajual, 0 , '' , '.' )}}</td>
						<td>Rp. {{number_format( $data->pivot->subtotal, 0 , '' , '.' )}}</td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div>
</body>

</html>