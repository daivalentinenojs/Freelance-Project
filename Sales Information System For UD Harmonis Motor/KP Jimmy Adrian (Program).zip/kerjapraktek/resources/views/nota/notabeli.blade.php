@extends('layouts.master') @section('title', 'Nota Beli') @section('content')

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
	<!-- Navigation-->
	@include('layouts.sidebar')
	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Nota Beli</div>
				<div class="card-body">

					@include('layouts.flash')

					<div class="pull-right" style="padding-bottom:20px">
						<a href="{{url('nota/beli/buat')}}" class="btn btn-success">
							<i class="fa fa-plus"></i> Buat Nota Beli
						</a>
					</div>

					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Nomor Nota</th>
									<th>Nama Pemasok</th>
									<th>Nama Karyawan</th>
									<th>Tanggal Buat</th>
									<th>Jatuh Tempo</th>
									<th>Total</th>
									<th>Status Beli</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>Nomor Nota</th>
									<th>Nama Pemasok</th>
									<th>Nama Karyawan</th>
									<th>Tanggal Buat</th>
									<th>Jatuh Tempo</th>
									<th>Total</th>
									<th>Status Beli</th>
								</tr>
							</tfoot>
							<tbody>
								@foreach($pur as $data)
								<tr id="{{$data->id}}">
									<td>{{$data->id}}</td>
									<td>{{$data->supplier->namarekening}}</td>
									<td>{{$data->employee->nama}}</td>
									<td>{{$data->tanggalbuat}}</td>
									<td>{{$data->jatuhtempo}}</td>
									<td>Rp. {{number_format( $data->total, 0 , '' , '.' )}}</td>
									<td>{{ucfirst($data->statusbeli)}}</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalShowNota">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Detail Nota Beli</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="{{url('nota/beli/ubah')}}" method="post" id="formUpdateNota">
							{{csrf_field()}}
							<p>
								<input type="hidden" id="id" name="id">
								<label class="col-lg-4">No Nota: </label>
								<input type="text" class="col-lg-6" id="nota" disabled>
							</p>
							<p>
								<label class="col-lg-4">Tanggal Buat: </label>
								<input type="text" class="col-lg-6" id="tanggalbuat" disabled>
							</p>
							<p>
								<label class="col-lg-4">Tanggal Jatuh Tempo: </label>
								<input type="text" class="col-lg-6" id="jatuhtempo" disabled>
							</p>
							<p>
								<label class="col-lg-4">Total: </label>
								<input type="text" class="col-lg-6" id="total" disabled>
							</p>
							<p>
								<label class="col-lg-4">Nama Pemasok: </label>
								<input type="text" class="col-lg-6" id="pemasok" disabled>
							</p>
							<p>
								<label class="col-lg-4">Nama Karyawan: </label>
								<input type="text" class="col-lg-6" id="karyawan" disabled>
							</p>
							<p>
								<label class="col-lg-4">Status Beli: </label>
								<select class="col-lg-4" name="statusbeli" id="statusbeli">
									<option value="0">Pesan</option>
									<option value="1">Dikirim</option>
									<option value="2">Lunas</option>
								</select>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnUbah" class="btn btn-primary">
									<i class="fa fa-check"></i> Ubah</button>
								<button class="btn btn-success" style="text-align:center" id="btnCetak" class="btn btn-primary">
									<i class="fa fa-print"></i> Cetak</button>
							</p>
						</form>
						<br>
						<div class="table-responsive">
							<table id="tabelBarang" class="table table-striped table-bordered table-hover nowrap">
								<thead>
									<tr>
										<th>Kode Barang</th>
										<th>Nama Barang</th>
										<th>Kuantiti</th>
										<th>Harga Beli</th>
										<th>Subtotal</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody id="dataNota">
								</tbody>
							</table>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalShowBarang">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Ubah Status Barang Nota</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="{{url('nota/beli/ubah/barang')}}" method="post" id="formChangeStatus">
							{{csrf_field()}}
							<p>
								<input type="hidden" id="ubah_id" name="id">
								<input type="hidden" id="ubah_nota" name="nota">
								<label class="col-lg-4">Status: </label>
								<select name="status" id="ubah_status">
									<option value="0">Dipesan</option>
									<option value="1">Diterima</option>
								</select>
							</p>
							<p>
								<label class="col-lg-4">Kuantiti: </label>
								<input type="number" min=1 class="col-lg-6" name="kuantiti" id="ubah_kuantiti">
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnUbahBarang" class="btn btn-primary">
									<i class="fa fa-check"></i> Ubah</button>
							</p>
						</form>
						<br>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>


		<!--Footer -->
		@include('layouts.footer')

		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>

		<!--Script-->
		@include('layouts.script')
		<script>
			$(document).ready(function () {
				var nota = 0;
				var admin = 0;
				$('#dataTable').on('click', 'tbody tr', function (e) { //delete product
					e.preventDefault();
					var status = 0;
					var id = $(this).closest('tr').attr('id');
					nota = id;
					$('#id').val(id);
					$.post("{{url('nota/beli/show')}}", {
							'id': id,
							'_token': "{{csrf_token()}}"
						},
						function (data) {
							admin = data.admin;
							$('#nota').val(data.nota);
							$('#pemasok').val(data.pemasok);
							$('#karyawan').val(data.karyawan);
							$('#tanggalbuat').val(data.tanggalbuat);
							$('#jatuhtempo').val(data.jatuhtempo);
							$('#total').val('Rp. ' + data.total);

							switch (data.statusbeli) {
								case "pesan":
									status = 0;
									break;
								case "dikirim":
									status = 1;
									break;
								case "lunas":
									status = 2;
									if(admin == 0){
										$('#statusbeli').attr('disabled', true);
									}
									break;
							}

							$('#statusbeli').val(status);

							$.post("{{url('nota/beli/show/barang')}}", {
									'id': id,
									'_token': "{{csrf_token()}}"
								},
								function (data) {
									$('#dataNota').html('');
									$('#dataNota').html(data);
								});
						});
					$('#modalShowNota').modal('show');
				});

				$('#tabelBarang').on('click', 'tbody tr', function (e) {
					var row = $(this).closest('tr');
					var id = row.find('td:eq(0)').text();
					var status = row.find('td:eq(5)').text();
					var kuantiti = row.find('td:eq(2)').text();
					if(status == 'Dipesan'){
						status = 0;
					}else{
						status = 1;
						if(admin == 0){
							$('#ubah_status').attr('disabled', true);
							$('#ubah_kuantiti').attr('disabled', true);
						}
					}

					$('#ubah_id').val(id);
					$('#ubah_nota').val(nota);
					$('#ubah_status').val(status);
					$('#ubah_kuantiti').val(kuantiti);
					$('#modalShowBarang').modal('show');
				});

				$('#btnCetak').on('click', function (e) {
					e.preventDefault();
					var id = $('#id').val();
					$.post("{{url('nota/beli/cetak')}}", {
							'id': id,
							'_token': "{{csrf_token()}}"
						},
						function (data) {
							//redirect to print page
						});
				});

				$('#formChangeStatus').on('submit',function(e){
					e.preventDefault();
					$('#ubah_status').attr('disabled', false);
					$('#ubah_kuantiti').attr('disabled', false);
					$('#formChangeStatus')[0].submit();
				});

				$('#formUpdateNota').on('submit',function(e){
					e.preventDefault();
					$('#statusbeli').attr('disabled', false);
					$('#formUpdateNota')[0].submit();
				});
			});
		</script>
	</div>
</body>
@endsection