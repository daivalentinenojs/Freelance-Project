@extends('layouts.master') @section('title', 'Buat Nota Jual') @section('content')

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
	<!-- Navigation-->
	@include('layouts.sidebar')
	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Buat Nota Jual</div>

				<div class="card-body col-lg-12">
					<div class="col-lg-6 pull-right">
						<label for="tanggalbuat" class="col-lg-4">Tanggal Buat</label>
						<input type="date" id="tanggalbuat" name="tanggalbuat" class="col-lg-6" min="{{date('Y-m-d')}}" value="{{date('Y-m-d')}}"
						 data-date-format="dd-mm-yyyy" data-date-viewmode="years" required disabled>
						<span class="fa fa-calendar"></span>
						<label for="tanggalbayar" class="col-lg-4">Tanggal Bayar</label>
						<input type="date" id="tanggalbayar" name="tanggalbayar" class="col-lg-6" min="{{date('Y-m-d')}}" value="{{date('Y-m-d')}}"
						 data-date-format="dd-mm-yyyy" data-date-viewmode="years" required>
						<span class="fa fa-calendar"></span>

						<div class="pull-right" style="margin-top: 80px">
							<label for="total">Total</label>
							<input class="text-right" type="text" disabled id="total" value="Rp. 0">
						</div>
					</div>

					<div class="col-lg-6 pull-left">
						<form action="" id="formInputBarang">
							<label class="col-lg-4" for="pembeli">Nama Pembeli</label>
							<select class="col-lg-4" name="pembeli" id="pembeli">
								@foreach($cus as $data)
								<option value="{{$data->id}}">{{$data->nama}}</option>
								@endforeach
							</select>
							<button class="btn btn-primary" id="btnPembeli">Set</button>
							<button style="display:none" id="btnGanti" class="btn btn-outline-danger">Ganti</button>
							<br>
							<br>
							<br>
							<label class="col-lg-4" for="barang">Nama Barang</label>
							<select class="col-lg-4" name="barang" id="barang">
								@foreach($pro as $data)
								<option value="{{$data->id}}">{{$data->category->nama}} - {{$data->nama}}</option>
								@endforeach
							</select>
							<label class="col-lg-4" for="stok">Stok</label>
							<label class="col-lg-4 text-left" id="stok">{{$pro[0]->stok}}</label>
							<label class="col-lg-4" for="kuantiti">Kuantiti</label>
							<input class="col-lg-4" type="number" id="kuantiti" name="kuantiti" value="1" min=1 required>
							<label class="col-lg-4" for="hargajual">Harga jual</label>
							<input class="col-lg-4" type="number" id="harga" name="harga" value="1000" min=0 step=500 required>
							<div class="text-center">
								<button style="display:none" type="submit" class="btn btn-success" id="btnAddBarang">Tambah</button>
							</div>
						</form>
					</div>
				</div>
				<br>
				<br>

				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
						<thead>
							<tr>
								<th>Kode Barang</th>
								<th>Nama Barang</th>
								<th>Harga Jual</th>
								<th>Kuantiti</th>
								<th>Sub Total</th>
							</tr>
						</thead>
						<tfoot>
							<tr>
								<th>Kode Barang</th>
								<th>Nama Barang</th>
								<th>Harga Jual</th>
								<th>Kuantiti</th>
								<th>Sub Total</th>
							</tr>
						</tfoot>
						<tbody>

						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="col-lg-12 text-center">
			<button style="display:none" class="btn btn-success" id="btnSimpan">Simpan Nota</button>
		</div>
		<br>
		<br>
	</div>

	<!--Footer -->
	@include('layouts.footer')

	<!-- Scroll to Top Button-->
	<a class="scroll-to-top rounded" href="#page-top">
		<i class="fa fa-angle-up"></i>
	</a>

	<!--Script-->
	@include('layouts.script')
	<script>
		$(document).ready(function () {
			var total = 0;
			var duplicate = 0;
			var rowIndex = 0;

			$('#tanggalbayar').on('change', function (e) { //prevent end date less than start date
				var tanggalbuat = $('#tanggalbuat').val();
				var tanggalbayar = $('#tanggalbayar').val();

				if (tanggalbayar < tanggalbuat) {
					$('#tanggalbayar').val(tanggalbuat);
				}
			});

			$('#dataTable').on('click', 'tbody tr', function (e) { //delete product
				e.preventDefault();
				var row = $(this).closest('tr');
				var id = $(this).closest('tr').attr('id');
				var idBarang = $('#barang').val();
				var stok = parseInt($('#stok').html());
				var subTotal = row.find('td:eq(4)').text();
				var kuantiti = parseInt(row.find('td:eq(3)').text());
				if(idBarang == id){
					stok += kuantiti;
				}
				total -= parseInt(subTotal.replace('Rp. ', ''));
				tbl.row('tr#' + id).remove().draw(false);
				$('#stok').html(stok);
				$('#total').val('Rp. ' + total);
			});

			$('#formInputBarang').on('submit', function (e) { //add Product to sale invoice table
				e.preventDefault();
				var stok = $('#stok').html();
				total = 0;
				var kode = $('#barang').val();
				var barang = $('#barang option:selected').text();;
				var harga = parseInt($('#harga').val());
				var kuantiti = parseInt($('#kuantiti').val());
				var subTotal = harga * kuantiti;

				if (stok < kuantiti) {
					swal('Stok Tidak Mencukupi', 'Cek Stok Terlebih Dahulu', 'error');
				} else {
					stok -= kuantiti;
					$('tbody tr').each(function () {
						var id = $(this).closest('tr').attr('id');
						if (id == kode) {
							rowIndex = $(this).index();
							duplicate++;
						}
					});

					if (duplicate == 0) { //check if there's same product already in table
						tbl.row.add([kode, barang, 'Rp. ' + harga, kuantiti, 'Rp. ' + subTotal]).node().id = kode;
						tbl.draw(false);
					} else {
						duplicate = 0;
						kuantiti += parseInt(tbl.cell(rowIndex, 3).data());
						subTotal += parseInt(tbl.cell(rowIndex, 4).data().replace('Rp. ', ''));
						tbl.cell(rowIndex, 2).data('Rp. ' + harga);
						tbl.cell(rowIndex, 3).data(kuantiti);
						tbl.cell(rowIndex, 4).data('Rp. ' + subTotal);
						tbl.draw(false);
					}

					$('tbody tr').each(function () {
						var row = $(this).closest('tr');
						var subTotal = row.find('td:eq(4)').text();
						total += parseInt(subTotal.replace('Rp. ', ''));
					});
					$('#stok').html(stok);
					$('#total').val('Rp. ' + total);
				}
			});

			$('#btnPembeli').on('click', function (e) { //lock Customer
				e.preventDefault();
				swal({
						title: 'Pilih Pembeli?',
						text: 'Anda akan memilih ' + $('#pembeli option:selected').text(),
						icon: 'info',
						buttons: ['Batal', 'Yakin']
					})
					.then((confirm) => {
						if (confirm) {
							$('#pembeli').attr('disabled', true);
							$('#btnAddBarang').show();
							$('#btnGanti').show();
							$('#btnSimpan').show();
						}
					});
			});

			$('#btnGanti').on('click', function (e) { //change Customer and reload
				e.preventDefault();
				swal({
						title: 'Ganti Pembeli?',
						text: 'Anda akan kehilangan data nota yang belum tersimpan',
						icon: 'warning',
						buttons: ['Batal', 'Yakin'],
						dangerMode: true,
					})
					.then((confirm) => {
						if (confirm) {
							location.reload();
						}
					});
			});

			$('#btnSimpan').on('click', function (e) { //save Sale invoice
				e.preventDefault();
				var objData = [];
				var idx = 0;
				var tanggalbuat = $('#tanggalbuat').val();
				var tanggalbayar = $('#tanggalbayar').val();
				var pembeli = $('#pembeli').val();
				var total = $('#total').val().replace('Rp. ', '');
				var kode = 0;
				var harga = 0;
				var kuantiti = 0;
				var subtotal = 0;

				$('tbody tr').each(function () {
					var row = $(this).closest('tr');
					var kode = $(this).closest('tr').attr('id');
					var harga = row.find('td:eq(2)').text().replace('Rp. ', '');;
					var kuantiti = row.find('td:eq(3)').text();
					var subtotal = row.find('td:eq(4)').text().replace('Rp. ', '');;
					objData[idx] = {
						'kode': kode,
						'harga': harga,
						'kuantiti': kuantiti,
						'subtotal': subtotal
					};
					idx++;
				});

				$.post("{{url('nota/jual/buat')}}", {
						'tanggalbuat': tanggalbuat,
						'tanggalbayar': tanggalbayar,
						'pembeli': pembeli,
						'total': total,
						'objData': objData,
						'_token': "{{csrf_token()}}"
					},
					function (data) {
						window.location.replace('{{url('nota/jual')}}');
					});
			});

			$('#barang').on('change', function () { //check stock
				var id = $('#barang').val();
				$.post("{{url('nota/jual/stok')}}", {
						'id': id,
						'_token': "{{csrf_token()}}"
					},
					function (data) {
						var stok = data.stok;
						$('tbody tr').each(function(){
							var row = $(this).closest('tr');
							var kode = $(this).closest('tr').attr('id');
							var kuantiti = parseInt(row.find('td:eq(3)').text());
							if(kode == id){
								stok -= kuantiti;
							}
						});
						$('#stok').html(stok);
					});
			});
		});
	</script>
	</div>
</body>
@endsection