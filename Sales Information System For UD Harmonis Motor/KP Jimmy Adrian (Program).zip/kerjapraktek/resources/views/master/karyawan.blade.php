@extends('layouts.master') @section('title', 'Data Karyawan') @section('content')

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
	<!-- Navigation-->
	@include('layouts.sidebar')
	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Data Karyawan</div>
				<div class="card-body">

					@include('layouts.flash')

					<div class="pull-right" style="padding-bottom:20px">
						<button class="btn btn-success" data-toggle="modal" data-target="#modalAddKaryawan">
							<i class="fa fa-plus"></i> Tambah Karyawan
						</button>
					</div>

					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Nama</th>
									<th>Alamat</th>
									<th>Email</th>
									<th>No Telepon</th>
									<th>Hak Akses</th>
									<th>Status Terdaftar</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>Nama</th>
									<th>Alamat</th>
									<th>Email</th>
									<th>No Telepon</th>
									<th>Hak Akses</th>
									<th>Status Terdaftar</th>
								</tr>
							</tfoot>
							<tbody>
								@foreach($emp as $data)
								<tr id="{{$data->id}}">
									<td>{{$data->nama}}</td>
									<td>{{$data->alamat}}</td>
									<td>{{$data->user->email}}</td>
									<td>{{$data->notelepon}}</td>
									<td>{{$data->user->admin == 1 ? 'Admin' : 'Karyawan'}}</td>
									<td>{{$data->user->status == 1 ? 'Aktif' : 'Tidak Aktif'}}</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalAddKaryawan">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Tambah Data Karyawan</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="" method="post" id="formAddKaryawan">
							{{csrf_field()}}
							<p>
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" name="nama" placeholder="Masukkan Nama Karyawan" required>
							</p>
							<p>
								<label class="col-lg-6">Alamat: </label>
								<input type="text" class="col-lg-4" name="alamat" placeholder="Masukkan Alamat Karyawan" required>
							</p>
							<p>
								<label class="col-lg-6">No Telepon: </label>
								<input type="tel" pattern="^[+]?[0-9]{9,15}$" class="col-lg-4" name="notelepon" placeholder="Masukkan No Telepon" required>
							</p>
							<p>
								<label class="col-lg-6">Email: </label>
								<input type="email" class="col-lg-4" name="email" placeholder="Masukkan Alamat Email" required>
							</p>
							<p>
								<label class="col-lg-6">Kata Sandi: </label>
								<input type="password" class="col-lg-4" id="addPassword" name="password" placeholder="Masukkan Password" required>
							</p>
							<p>
								<label class="col-lg-6">Ulangi Kata Sandi: </label>
								<input type="password" class="col-lg-4" id="addRepassword" name="repassword" placeholder="Masukkan Ulang Kata Sandi" required>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnAdd" class="btn btn-primary">
									<i class="fa fa-check"></i> Tambah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalEditKaryawan">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Ubah Data Karyawan</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="{{url('master/karyawan/update')}}" method="post" id="formEditKaryawan">
							{{csrf_field()}}
							<p>
								<input type="hidden" id="id" name="id" value="">
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" id="nama" name="nama" placeholder="Masukkan Nama Karyawan" required>
							</p>
							<p>
								<label class="col-lg-6">Alamat: </label>
								<input type="text" class="col-lg-4" id="alamat" name="alamat" placeholder="Masukkan Alamat Karyawan" required>
							</p>
							<p>
								<label class="col-lg-6">No Telepon: </label>
								<input type="tel" pattern="^[+]?[0-9]{9,15}$" class="col-lg-4" id="notelepon" name="notelepon" placeholder="Masukkan No Telepon"
								 required>
							</p>
							<p>
								<label class="col-lg-6">Email: </label>
								<input type="email" class="col-lg-4" id="email" name="email" placeholder="Masukkan Alamat Email" required>
							</p>
							<p>
								<label class="col-lg-6">Kata Sandi: </label>
								<input type="password" class="col-lg-4" id="editPassword" name="password" placeholder="Masukkan Kata Sandi" required>
							</p>
							<p>
								<label class="col-lg-6">Ulangi Kata Sandi: </label>
								<input type="password" class="col-lg-4" id="editRepassword" name="repassword" placeholder="Masukkan Ulang Kata Sandi" required>
							</p>
							<p>
								<label class="col-lg-6">Hak Akses: </label>
								<select name="admin" id="admin" class="col-lg-4">
									<option value="0">Karyawan</option>
									<option value="1">Admin</option>
								</select>
							</p>
							<p>
								<label class="col-lg-6">Status Terdaftar: </label>
								<select name="status" id="status" class="col-lg-4">
									<option value="0">Tidak Aktif</option>
									<option value="1">Aktif</option>
								</select>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnEdit" class="btn btn-primary">
									<i class="fa fa-check"></i> Ubah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<!--Footer -->
		@include('layouts.footer')

		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>

		<!--Script-->
		@include('layouts.script')
		<script>
			$(document).ready(function () {
				$('#dataTable').on('click', 'tbody tr', function () { //open modal when click Employee
					var id = $(this).closest('tr').attr('id'); //get id of clicked row

					$.post("{{url('master/karyawan/edit')}}", {
							'id': id,
							'_token': "{{csrf_token()}}"
						},
						function (data) {
							$('#id').val(data.id);
							$('#nama').val(data.nama);
							$('#alamat').val(data.alamat);
							$('#notelepon').val(data.notelepon);
							$('#email').val(data.email);
							$('#admin').val(data.admin);
							$('#status').val(data.status);
							$('#modalEditKaryawan').modal('show');
						});
				});

				$('#formAddKaryawan').on('submit', function (e) {
					e.preventDefault();
					var pass = $('#addPassword').val();
					var repass = $('#addRepassword').val();
					if (pass != repass) {
						swal('Kesalahan Terjadi', 'Kata Sandi Harus Sama', 'error');
						$('#addPassword').val('');
						$('#addRepassword').val('');
					} else {
						$('#formAddKaryawan')[0].submit();
					}
				});

				$('#formEditKaryawan').on('submit', function (e) {
					e.preventDefault();
					var pass = $('#editPassword').val();
					var repass = $('#editRepassword').val();
					if (pass != repass) {
						swal('Kesalahan Terjadi', 'Kata Sandi Harus Sama', 'error');
						$('#editPassword').val('');
						$('#editRepassword').val('');
					} else {
						$('#formEditKaryawan')[0].submit();
					}
				});
			});
		</script>
	</div>
</body>
@endsection