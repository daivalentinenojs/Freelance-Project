@extends('layouts.master') @section('title', 'Data Kategori') @section('content')

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
	<!-- Navigation-->
	@include('layouts.sidebar')
	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Data Kategori</div>
				<div class="card-body">

					@include('layouts.flash')

					<div class="pull-right" style="padding-bottom:20px">
						<button class="btn btn-success" data-toggle="modal" data-target="#modalAddKategori">
							<i class="fa fa-plus"></i> Tambah Kategori
						</button>
					</div>

					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Merek</th>
									<th>Status Produksi</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>Merk</th>
									<th>Status Produksi</th>
								</tr>
							</tfoot>
							<tbody>
								@foreach($cat as $data)
								<tr id="{{$data->id}}">
									<td>{{$data->nama}}</td>
									<td>{{$data->statusterdaftar == 1 ? 'Tersedia' : 'Diskontinu'}}</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>

			</div>
		</div>

		<div class="modal fade" id="modalAddKategori">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Tambah Data Kategori</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="" method="post">
							{{csrf_field()}}
							<p>
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" name="nama" placeholder="Masukkan Nama Kategori" required>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnAdd" class="btn btn-primary">
									<i class="fa fa-check"></i> Tambah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalEditKategori">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Ubah Data Kategori</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="{{url('master/kategori/update')}}" method="post">
							{{csrf_field()}}
							<p>
								<input type="hidden" id="id" name="id" value="">
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" id="nama" name="nama" placeholder="Masukkan Nama Kategori" required>
							</p>
							<p>
								<label class="col-lg-6">Status Produksi: </label>
								<select name="status" id="status" class="col-lg-4">
									<option value="0">Diskontinu</option>
									<option value="1">Tersedia</option>
								</select>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnEdit" class="btn btn-primary">
									<i class="fa fa-check"></i> Ubah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<!--Footer -->
		@include('layouts.footer')

		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>

		<!--Script-->
		@include('layouts.script')
		<script>
			$(document).ready(function () {
				$('#dataTable').on('click', 'tbody tr', function () { //open modal when click Category
					var id = $(this).closest('tr').attr('id'); //get id of clicked row

					$.post("{{url('master/kategori/edit')}}", {
							'id': id,
							'_token': "{{csrf_token()}}"
						},
						function (data) {
							$('#id').val(data.id);
							$('#nama').val(data.nama);
							$('#status').val(data.status);
							$('#modalEditKategori').modal('show');
						});
				});
			});
		</script>
	</div>
</body>
@endsection