@extends('layouts.master') @section('title', 'Data Barang') @section('content')

<body class="fixed-nav sticky-footer bg-dark" id="page-top">

	<!-- Navigation-->
	@include('layouts.sidebar')

	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Data Barang</div>
				<div class="card-body">

					@include('layouts.flash')

					<div class="pull-right" style="padding-bottom:20px">
						<button class="btn btn-success" data-toggle="modal" data-target="#modalAddBarang">
							<i class="fa fa-plus"></i> Tambah Barang
						</button>
					</div>

					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Nama</th>
									<th>Merk</th>
									<th>Tahun</th>
									<th>Harga Jual</th>
									<th>Stok</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>Nama</th>
									<th>Merek</th>
									<th>Tahun</th>
									<th>Harga Jual</th>
									<th>Stok</th>
								</tr>
							</tfoot>
							<tbody>
								@foreach($pro as $data)
								<tr id="{{$data->id}}">
									<td>{{$data->nama}}</td>
									<td>{{$data->category->nama}}</td>
									<td>{{$data->tahun}}</td>
									<td>Rp. {{number_format( $data->hargajual, 0 , '' , '.' )}}</td>
									<td>{{$data->stok}}</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalAddBarang">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Tambah Data Barang</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="" method="post">
							{{csrf_field()}}
							<p>
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" name="nama" placeholder="Masukkan Nama Barang" required>
							</p>
							<p>
								<label class="col-lg-6">Merek: </label>
								<select name="merek" class="col-lg-4" required>
									@foreach($cat as $data)
									<option value="{{$data->id}}">{{$data->nama}}</option>
									@endforeach
								</select>
							</p>
							<p>
								<label class="col-lg-6">Tahun: </label>
								<input type="number" class="col-lg-4" value="{{date('Y')}}" min=1990 max={{date( 'Y')}} name="tahun" placeholder="Masukkan Tahun"
								 required>
							</p>
							<p>
								<label class="col-lg-6">Harga Jual: </label>
								<input type="number" class="col-lg-4" min=0 step=500 name="harga" value="1000" placeholder="Masukkan Harga Jual" required>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnAdd" class="btn btn-primary">
									<i class="fa fa-check"></i> Tambah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalEditBarang">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Ubah Data Barang</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="{{url('master/barang/update')}}" method="post">
							{{csrf_field()}}
							<p>
								<input type="hidden" id="id" name="id" value="">
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" id="nama" name="nama" placeholder="Masukkan Nama Barang" required>
							</p>
							<p>
								<label class="col-lg-6">Merek: </label>
								<select id="merek" name="merek" class="col-lg-4" required>
									@foreach($cat as $data)
									<option value="{{$data->id}}">{{$data->nama}}</option>
									@endforeach
								</select>
							</p>
							<p>
								<label class="col-lg-6">Tahun: </label>
								<input type="number" value="{{date('Y')}}" min=1990 max={{date( 'Y')}} class="col-lg-4" id="tahun" name="tahun" placeholder="Masukkan Tahun"
								 required>
							</p>
							<p>
								<label class="col-lg-6">Harga Jual: </label>
								<input type="number" min=0 step=500 class="col-lg-4" id="harga" name="harga" placeholder="Masukkan Harga Jual" required>
							</p>
							<p>
								<label class="col-lg-6">Stok: </label>
								<input class="col-lg-4" type="text" id="stok" disabled>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnEdit" class="btn btn-primary">
									<i class="fa fa-check"></i> Ubah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<!--Footer -->
		@include('layouts.footer')

		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>

		<!--Script-->
		@include('layouts.script')
		<script>
			$(document).ready(function () {
				$('#dataTable tfoot th').each(function () {
					var title = $(this).text();
					$(this).html('<input type="text" placeholder="Search ' + title + '" />');
				});

				$('#dataTable').on('click', 'tbody tr', function () { //open modal when click Product
					var id = $(this).closest('tr').attr('id'); //get id of clicked row

					$.post("{{url('master/barang/edit')}}", {
							'id': id,
							'_token': "{{csrf_token()}}"
						},
						function (data) {
							$('#id').val(data.id);
							$('#nama').val(data.nama);
							$('#merek').val(data.merek);
							$('#tahun').val(data.tahun);
							$('#harga').val(data.harga);
							$('#stok').val(data.stok);
							$('#modalEditBarang').modal('show');
						});
				});

				tbl.columns().every(function () { //searching by column
					var that = this;
					$('input', this.footer()).on('keyup change', function () {
						if (that.search() !== this.value) {
							that
								.search(this.value)
								.draw();
						}
					});
				});
			});
		</script>
	</div>
</body>
@endsection