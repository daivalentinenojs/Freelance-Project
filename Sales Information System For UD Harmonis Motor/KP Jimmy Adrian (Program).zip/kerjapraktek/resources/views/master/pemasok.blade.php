@extends('layouts.master') @section('title', 'Data Pemasok') @section('content')

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
	<!-- Navigation-->
	@include('layouts.sidebar')
	<div class="content-wrapper">
		<div class="container-fluid">
			<div class="card mb-3">
				<div class="card-header">
					<i class="fa fa-table"></i> Data Pemasok</div>
				<div class="card-body">

					@include('layouts.flash')

					<div class="pull-right" style="padding-bottom:20px">
						<button class="btn btn-success" data-toggle="modal" data-target="#modalAddPemasok">
							<i class="fa fa-plus"></i> Tambah Pemasok
						</button>
					</div>

					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
							<thead>
								<tr>
									<th>Nama</th>
									<th>No Rekening</th>
									<th>Bank</th>
									<th>Alamat</th>
									<th>No Telepon</th>
									<th>Status Beli</th>
									<th>Status Terdaftar</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>Nama</th>
									<th>No Rekening</th>
									<th>Bank</th>
									<th>Alamat</th>
									<th>No Telepon</th>
									<th>Status Beli</th>
									<th>Status Terdaftar</th>
								</tr>
							</tfoot>
							<tbody>
								@foreach($sup as $data)
								<tr id="{{$data->id}}">
									<td>{{$data->namarekening}}</td>
									<td>{{$data->norekening}}</td>
									<td>{{$data->bank}}</td>
									<td>{{$data->alamat}}</td>
									<td>{{$data->notelepon}}</td>
									<td>{{$data->statusbeli == 1 ? 'Lunas' : 'Hutang'}}</td>
									<td>{{$data->statusterdaftar == 1 ? 'Aktif' : 'Tidak Aktif'}}</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalAddPemasok">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Tambah Data Pemasok</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="" method="post">
							{{csrf_field()}}
							<p>
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" name="nama" placeholder="Masukkan Nama Pemasok" required>
							</p>
							<p>
								<label class="col-lg-6">No Rekening: </label>
								<input type="number" class="col-lg-4" name="norekening" placeholder="Masukkan No Rekening Pemasok" required>
							</p>
							<p>
								<label class="col-lg-6">Bank: </label>
								<input type="text" class="col-lg-4" name="bank" placeholder="Masukkan Bank" required>
							</p>
							<p>
								<label class="col-lg-6">Alamat: </label>
								<input type="text" class="col-lg-4" name="alamat" placeholder="Masukkan Alamat Pemasok" required>
							</p>
							<p>
								<label class="col-lg-6">No Telepon: </label>
								<input type="tel" pattern="^[+]?[0-9]{9,15}$" class="col-lg-4" name="notelepon" placeholder="Masukkan No Telepon" required>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnAdd" class="btn btn-primary">
									<i class="fa fa-check"></i> Tambah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="modalEditPemasok">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Ubah Data Pemasok</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="{{url('master/pemasok/update')}}" method="post" id="formEditPemasok">
							{{csrf_field()}}
							<p>
								<input type="hidden" id="id" name="id" value="">
								<label class="col-lg-6">Nama: </label>
								<input type="text" class="col-lg-4" id="nama" name="nama" placeholder="Masukkan Nama Pemasok" required>
							</p>
							<p>
								<label class="col-lg-6">No Rekening: </label>
								<input type="number" class="col-lg-4" id="norekening" name="norekening" placeholder="Masukkan No Rekening Pemasok" required>
							</p>
							<p>
								<label class="col-lg-6">Bank: </label>
								<input type="text" class="col-lg-4" id="bank" name="bank" placeholder="Masukkan Bank" required>
							</p>
							<p>
								<label class="col-lg-6">Alamat: </label>
								<input type="text" class="col-lg-4" id="alamat" name="alamat" placeholder="Masukkan Alamat Pemasok" required>
							</p>
							<p>
								<label class="col-lg-6">No Telepon: </label>
								<input type="tel" pattern="^[+]?[0-9]{9,15}$" class="col-lg-4" id="notelepon" name="notelepon" placeholder="Masukkan No Telepon"
								 required>
							</p>
							<p>
								<label class="col-lg-6">Status Beli: </label>
								<select name="statusbeli" id="statusbeli" class="col-lg-4">
									<option value="0">Hutang</option>
									<option value="1">Lunas</option>
								</select>
							</p>
							<p>
								<label class="col-lg-6">Status Terdaftar: </label>
								<select name="statusterdaftar" id="statusterdaftar" class="col-lg-4">
									<option value="0">Tidak Aktif</option>
									<option value="1">Aktif</option>
								</select>
							</p>

							<p style="text-align:center">
								<button type="submit" class="btn btn-success" style="text-align:center" id="btnEdit" class="btn btn-primary">
									<i class="fa fa-check"></i> Ubah</button>
							</p>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
					</div>
				</div>
			</div>
		</div>

		<!--Footer -->
		@include('layouts.footer')

		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fa fa-angle-up"></i>
		</a>

		<!--Script-->
		@include('layouts.script')
		<script>
			$(document).ready(function () {
				$('#dataTable').on('click', 'tbody tr', function () { //open modal when click Supplier
					var id = $(this).closest('tr').attr('id'); //get id of clicked row

					$.post("{{url('master/pemasok/edit')}}", {
							'id': id,
							'_token': "{{csrf_token()}}"
						},
						function (data) {
							$('#id').val(data.id);
							$('#nama').val(data.nama);
							$('#norekening').val(data.norekening);
							$('#bank').val(data.bank);
							$('#notelepon').val(data.notelepon);
							$('#alamat').val(data.alamat);
							$('#statusbeli').val(data.statusbeli);
							$('#statusterdaftar').val(data.statusterdaftar);
							$('#modalEditPemasok').modal('show');
						});
				});

				$('#formEditPemasok').on('submit', function(){ //to prevent error data not submitted (disabled)
					$('#statusbeli').removeAttr('disabled');
				});
			});
		</script>
	</div>
</body>
@endsection