<?php
use Illuminate\Support\Facades\Auth;

Route::get('/', function () {
    if (Auth::check()) {
        return view('dashboard.beranda');
    }
    return view('auth.login');
});

Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
Route::post('login', 'Auth\LoginController@login');
Route::post('logout', 'Auth\LoginController@logout')->name('logout');

Route::get('beranda', 'HomeController@index')->name('home');
Route::get('tentang', 'HomeController@about');

Route::get('master/karyawan', 'EmployeeController@index');
Route::post('master/karyawan', 'EmployeeController@store');
Route::post('master/karyawan/edit', 'EmployeeController@edit');
Route::post('master/karyawan/update', 'EmployeeController@update');

Route::get('master/pembeli', 'CustomerController@index');
Route::post('master/pembeli', 'CustomerController@store');
Route::post('master/pembeli/edit', 'CustomerController@edit');
Route::post('master/pembeli/update', 'CustomerController@update');

Route::get('master/pemasok', 'SupplierController@index');
Route::post('master/pemasok', 'SupplierController@store');
Route::post('master/pemasok/edit', 'SupplierController@edit');
Route::post('master/pemasok/update', 'SupplierController@update');

Route::get('master/barang', 'ProductController@index');
Route::post('master/barang', 'ProductController@store');
Route::post('master/barang/edit', 'ProductController@edit');
Route::post('master/barang/update', 'ProductController@update');

Route::get('master/kategori', 'CategoryController@index');
Route::post('master/kategori', 'CategoryController@store');
Route::post('master/kategori/edit', 'CategoryController@edit');
Route::post('master/kategori/update', 'CategoryController@update');

Route::get('nota/beli', 'PurchaseController@index');
Route::get('nota/beli/buat', 'PurchaseController@create');
Route::post('nota/beli/buat', 'PurchaseController@processInput');
Route::post('nota/beli/ubah', 'PurchaseController@update');
Route::post('nota/beli/ubah/barang', 'PurchaseController@changeProductStatus');
Route::post('nota/beli/show', 'PurchaseController@show');
Route::post('nota/beli/show/barang', 'PurchaseController@showProduct');
Route::post('nota/beli/cetak', 'PurchaseController@print');

Route::get('nota/jual', 'SaleController@index');
Route::get('nota/jual/buat', 'SaleController@create');
Route::post('nota/jual/buat', 'SaleController@processInput');
Route::post('nota/jual/ubah', 'SaleController@update');
Route::post('nota/jual/show', 'SaleController@show');
Route::post('nota/jual/show/barang', 'SaleController@showProduct');
Route::post('nota/jual/stok', 'SaleController@checkStock');
Route::post('nota/jual/cetak', 'SaleController@print');