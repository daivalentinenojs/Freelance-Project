<?php $__env->startSection('title','Destination'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <span class="subheading" style="font-size:25px">Let's plan your unforgettable holiday!</span>
            </div>
        </div>

        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate" style="background-color:#fefaf8">
                <h2 class="mb-4">Here's our travel package recommendations</h2>
                <p>You have chosen Tokyo as a tourist destination</p>
            </div>
        </div>
        <br>
        <div class="row d-flex">
            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:750px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/2.jpg')); ?>');">
                    </span>
                    <div class="d-flex align-items-center pt-2 mb-4 topp">
                        <div class="one mr-2">
                            <span class="day">7</span>
                        </div>
                        <div class="two">
                            <span class="yr">Days</span>
                            <span class="yr">$8,800</span>
                        </div>
                    </div>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Titanium Package - 5 people</span></h3>
                        <p>The ultimate travel membership
                            with private jet, yacht, villa and
                            luxury home access, a dedicated
                            concierge and the ability to
                            create custom trips.</p>
                        <p>Day 1 : Shibuya <br> Day 2 : Harajuku <br> Day 3 : Ginza <br> Day 4 : Minato <br> Day 5 :
                            Teamlab <br> Day 6 : Osaka</p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0"><a class="btn btn-primary" href="<?php echo e(url('destination/package_detail')); ?>">See details</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:750px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/3.jpg')); ?>');">
                    </span>
                    <div class="d-flex align-items-center pt-2 mb-4 topp">
                        <div class="one mr-2">
                            <span class="day">7</span>
                        </div>
                        <div class="two">
                            <span class="yr">Days</span>
                            <span class="yr">$6,100</span>
                        </div>
                    </div>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Platinum Package - 5 people</span></h3>
                        <p>An elite offering with early
                            access to all the DreamTrips and
                            next level amenities. <br><br><br></p>
                        <p>Day 1 : Asakusa <br> Day 2 : Ueno <br> Day 3 : Ginza <br> Day 4 : Samida <br> Day 5 :
                            Oedo Onsen <br> Day 6 : Tokyo</p>
                        <div class="d-flex align-items-center mt-4 meta">
                        <p class="mb-0"><a class="btn btn-primary" href="<?php echo e(url('destination/package_detail')); ?>">See details</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:750px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/1.jpg')); ?>');">
                    </span>
                    <div class="d-flex align-items-center pt-2 mb-4 topp">
                        <div class="one mr-2">
                            <span class="day">7</span>
                        </div>
                        <div class="two">
                            <span class="yr">Days</span>
                            <span class="yr">$5,900</span>
                        </div>
                    </div>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Gold Package - 5 people</span></h3>
                        <p>Exclusive travel packages,
                            concierge access and special
                            offers from preferred retailers. <br><br></p>
                        <p>Day 1 : Shinjuku <br> Day 2 : Asakusa <br> Day 3 : Ueno <br> Day 4 : Yanaka <br> Day 5 :
                            Ginza <br> Day 6 : Nagasaki</p>
                        <div class="d-flex align-items-center mt-4 meta">
                        <p class="mb-0"><a class="btn btn-primary" href="<?php echo e(url('destination/package_detail')); ?>">See details</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:750px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/4.jpg')); ?>');">
                    </span>
                    <div class="d-flex align-items-center pt-2 mb-4 topp">
                        <div class="one mr-2">
                            <span class="day">7</span>
                        </div>
                        <div class="two">
                            <span class="yr">Days</span>
                            <span class="yr">$5,700</span>
                        </div>
                    </div>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Culinary Package - 5 people</span></h3>
                        <p>The best way to experience exotic customs is by feasting on local produce, savoring regional
                            spices with the national beer and sitting down to share a meal. <br></p>
                        <p>Day 1 : Osaka <br> Day 2 : Hiroshima <br> Day 3 : Nagasaki <br> Day 4 : Kyoto <br> Day 5 :
                            Ginza <br> Day 6 : Tokyo</p>
                        <div class="d-flex align-items-center mt-4 meta">
                        <p class="mb-0"><a class="btn btn-primary" href="<?php echo e(url('destination/package_detail')); ?>">See details</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:750px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/5.jpg')); ?>');">
                    </span>
                    <div class="d-flex align-items-center pt-2 mb-4 topp">
                        <div class="one mr-2">
                            <span class="day">7</span>
                        </div>
                        <div class="two">
                            <span class="yr">Days</span>
                            <span class="yr">$5,700</span>
                        </div>
                    </div>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Halal Trip Package - 5 people</span></h3>
                        <p>This fully integrated all-in-one app not only helps Muslims with their everyday faith bases
                            requirements, but also assists in planning the ideal Muslim-friendly trip.<br></p>
                        <p>Day 1 : Ginza <br> Day 2 : Tokyo <br> Day 3 : Osaka <br> Day 4 : Yanaka <br> Day 5 :
                            Kyoto <br> Day 6 : Nagasaki</p>
                        <div class="d-flex align-items-center mt-4 meta">
                        <p class="mb-0"><a class="btn btn-primary" href="<?php echo e(url('destination/package_detail')); ?>">See details</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:750px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/6.jpg')); ?>');">
                    </span>
                    <div class="d-flex align-items-center pt-2 mb-4 topp">
                        <div class="one mr-2">
                            <span class="day">7</span>
                        </div>
                        <div class="two">
                            <span class="yr">Days</span>
                            <span class="yr">$5,700</span>
                        </div>
                    </div>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Budget Package - 5 people</span></h3>
                        <p>Get inspired by our selection of the best budget tours and cheap trips that will take you to
                            exciting destinations around the world. <br></p>
                        <p>Day 1 : Shinjuku <br> Day 2 : Ueno <br> Day 3 : Tokyo <br> Day 4 : Asakusa <br> Day 5 :
                            Ginza <br> Day 6 : Nagasaki</p>
                        <div class="d-flex align-items-center mt-4 meta">
                        <p class="mb-0"><a class="btn btn-primary" href="<?php echo e(url('destination/package_detail')); ?>">See details</a></p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- <form action="#" class="search-property-1">
            <div class="row">
                <div class="col-lg align-self-end">
                    <div class="form-group">
                        <div class="form-field">
                            <a href=""><input type="button" value="Generate another packages"
                                    class="form-control btn btn-success"></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg align-self-end">
                    <div class="form-group">
                        <div class="form-field">
                            <a href="<?php echo e(url('destination/package_detail')); ?>"><input type="button" value="Next"
                                    class="form-control btn btn-success"></a>
                        </div>
                    </div>
                </div>
            </div>
        </form> -->
    </div>
</section>

<section class="ftco-intro img" id="destination-section"
    style="background-image: url(<?php echo e(asset('assets/images/bg_3.jpg)')); ?>;">
    <div class="overlay"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 text-center">
                <h2>Choose the Perfect Destination</h2>
                <p>We can manage your dream building</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>