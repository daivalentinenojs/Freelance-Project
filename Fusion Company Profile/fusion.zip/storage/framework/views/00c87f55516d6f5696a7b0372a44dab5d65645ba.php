<?php $__env->startSection('title','Simple Flowers'); ?>
<?php $__env->startSection('music'); ?>
<div class="gla_music_icon">
   <i class="ti ti-music"></i>
</div>
<div class="gla_music_icon_cont">
   <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/108238095&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" allow="autoplay"></iframe>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">
   <div class="container text-left">
     <div class="form-group row">
          <div class="col-md-12">
              <input type="button" class="btn submit" id="edit_event" value="Edit">
          </div>
     </div>
   </div>
</div>

<?php echo $template_design->rendered; ?>


<div class="modal fade" id="event_template" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
       <div class="modal-content">
           <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Tutup</span></button>
               <h4 class="modal-title" id="myModalLabel">Edit Template</h4>
           </div>
           <div class="modal-body">
           <form class="form-horizontal" id="form_template" name="form_template" method="POST">
              <?php echo csrf_field(); ?>
              <div class="modal-body">
                 <div class="panel-body">
                   <div class="col-md-12">
                     <?php if(isset($template_design_detail)): ?>
                     <input type="hidden" name="eid" value="<?php echo e($template_design_detail->eid); ?>">
                     <?php endif; ?>
                     <div class="form-group row">
                         <div class="col-md-12">
                             <label>Event's Title* <small class="form-text text-muted"> Ex. The Wedding Of Kevin & Alexandra</small></label>
                               <input type="text" name="event_title" class="form-control form-opacity" required data-parsley-maxlength="300" data-parsley-minlength="3" value="<?php echo e(old('event_title',(isset($template_design_detail)?$template_design_detail->name:''))); ?>">
                         </div>
                     </div>
                     <?php $__currentLoopData = $template_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php if($td['types'] == 'text' || $td['types'] == 'image' || $td['types'] == 'date'): ?>
                       <div class="form-group row">
                           <div class="col-md-12">
                               <label><?php echo e($td['detail_name']); ?>* <small class="form-text text-muted"> Ex. <?php echo e($td['example']); ?></small></label>
                               <?php if($td['types'] == 'text'): ?>
                                <input type="text" name="template[<?php echo e($td['id_detail']); ?>]" class="form-control form-opacity" required data-parsley-maxlength="300" data-parsley-minlength="3" value="<?php echo e(old('$td[\'id_detail\']',(isset($template_design_detail)?$template_design_detail->name:''))); ?>">
                               <?php elseif($td['types'] == 'image'): ?>
                               <input type="file" name="template[<?php echo e($td['id_detail']); ?>]" class="form-control form-opacity" required value="<?php echo e(old('$td[\'id_detail\']',(isset($template_design_detail)?$template_design_detail->name:''))); ?>">
                               <?php elseif($td['types'] == 'date'): ?>
                               <input type="date" name="template[<?php echo e($td['id_detail']); ?>]" class="form-control form-opacity" required value="<?php echo e(old('$td[\'id_detail\']',(isset($template_design_detail)?$template_design_detail->name:''))); ?>">
                               <?php endif; ?>
                           </div>
                       </div>
                       <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <input type="hidden" name="event_id" value="<?php echo e($template_detail[0]['id']); ?>">
                     <input type="hidden" name="event_name" value="<?php echo e($template_detail[0]['nama']); ?>">
                     <div class="form-group" style="text-align:center;">
                            <input type="submit" id="btn_save" name="btn_save" value="Save" class="btn btn-success">
                     </div>
                   </div>
                  </div>
                </div>
              </form>
           </div>
           <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
           </div>
       </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
$(function(){
   $(document).on('click','#edit_event',function(e){
       e.preventDefault();
       $("#event_template").modal('show');
   });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>