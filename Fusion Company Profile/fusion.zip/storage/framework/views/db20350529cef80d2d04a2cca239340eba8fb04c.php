<?php $__env->startSection('title','Simple Flowers'); ?>
<?php $__env->startSection('music'); ?>
<div class="gla_music_icon">
   <i class="ti ti-music"></i>
</div>
<div class="gla_music_icon_cont">
   <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/108238095&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" allow="autoplay"></iframe>
</div>
<div class="gla_floating_container">
  <?php if(Auth::check()): ?>
  <i class="ti ti-pencil" id="edit_event"></i>
  <?php else: ?>
  <a href="<?php echo e(url('login')); ?>">
    <i class="ti ti-pencil" style="color:white;"></i>
  </a>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $template_design->rendered; ?>


<div class="modal fade" id="event_template" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog">
   <div class="modal-content">
     <form class="form-horizontal" id="form_template" name="form_template" method="POST" enctype="multipart/form-data" action="<?php echo e(url('p/'.$link_url)); ?>">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Tutup</span></button>
         <h4 class="modal-title" id="myModalLabel">Edit Template</h4>
       </div>
       <div class="modal-body">
        <?php echo csrf_field(); ?>
       <div class="panel-body">
         <div class="col-md-12">
           <?php if(isset($template_design)): ?>
            <input type="hidden" name="eid" value="<?php echo e($template_design->eid); ?>">
           <?php endif; ?>
           <?php if(isset($previews)): ?>
             <div class="form-group row">
               <div class="col-md-12">
                 <!-- <label>Event's Title* <small class="form-text text-muted"> Ex. The Wedding Of Kevin & Alexandra</small></label> -->
                 <label>Event's Title</label>
                 <input type="text" name="event_title" class="form-control form-opacity" placeholder="Ex. The Wedding Of Kevin & Alexandra" value="<?php echo e($previews->event->nama); ?>">
               </div>
             </div>
             <?php $__currentLoopData = $previews->event->event_design->text; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($td->template_design_detail->types == 'text' || $td->template_design_detail->types == 'date'): ?>
               <div class="form-group row">
                 <div class="col-md-12">
                   <label><?php echo e($td->template_design_detail->name); ?></label>
                   <?php if($td->template_design_detail->types == 'text'): ?>
                    <input type="text" name="template[text][<?php echo e($td->template_design_detail_id); ?>]" class="form-control form-opacity" placeholder="<?php echo e($td->template_design_detail->example); ?>" value="<?php echo e($td->value); ?>">
                   <?php elseif($td->template_design_detail->types == 'date'): ?>
                    <input type="date" name="template[text][<?php echo e($td->template_design_detail_id); ?>]" class="form-control form-opacity" value="<?php echo e($td->value); ?>">
                   <?php endif; ?>
                 </div>
               </div>
               <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php $__currentLoopData = $previews->event->event_design->file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($td->template_design_detail->types == 'image'): ?>
               <div class="form-group row">
                 <div class="col-md-12">
                   <label><?php echo e($td->template_design_detail->name); ?></label>
                   <?php if($td->template_design_detail->types == 'image'): ?>
                    <input type="file" name="template[file][<?php echo e($td->template_design_detail_id); ?>]" class="dropify" data-default-file="<?php echo e($td->value); ?>" />
                   <?php endif; ?>
                 </div>
               </div>
               <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php else: ?>
             <div class="form-group row">
               <div class="col-md-12">
                 <label>Event's Title</label>
                 <input type="text" name="event_title" class="form-control form-opacity" placeholder="Ex. The Wedding Of Kevin & Alexandra">
               </div>
             </div>
             <?php $__currentLoopData = $template_design->template_design_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($td->types == 'text' || $td->types == 'date'): ?>
               <div class="form-group row">
                 <div class="col-md-12">
                   <label><?php echo e($td->name); ?></label>
                   <?php if($td->types == 'text'): ?>
                    <input type="text" name="template[text][<?php echo e($td->id); ?>]" class="form-control form-opacity" placeholder="<?php echo e($td->example); ?>">
                   <?php elseif($td->types == 'date'): ?>
                    <input type="date" name="template[text][<?php echo e($td->id); ?>]" class="form-control form-opacity">
                   <?php endif; ?>
                 </div>
               </div>
               <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php $__currentLoopData = $template_design->template_design_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($td->types == 'image'): ?>
               <div class="form-group row">
                 <div class="col-md-12">
                   <label><?php echo e($td->name); ?></label>
                   <?php if($td->types == 'image'): ?>
                    <input type="file" name="template[file][<?php echo e($td->id); ?>]" class="dropify" data-default-file="<?php echo e($td->html); ?>" />
                   <?php endif; ?>
                 </div>
               </div>
               <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
           <input type="hidden" name="event_id" value="<?php echo e($template_design->id); ?>">
           <input type="hidden" name="event_name" value="<?php echo e($template_design->nama); ?>">
         </div>
        </div>
       </div>
       <div class="modal-footer">
         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
         <button type="submit" name="preview" class="btn btn-warning">Preview</button>
         <button type="submit" name="save" class="btn btn-info">Save</button>
       </div>
     </form>
   </div>
 </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('assets/lib/dropify/css/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />
<style>
.gla_floating_container{
  position: fixed;
  color: rgb(238, 238, 238);
  bottom: 45px;
  left: 50px;
  z-index: 2;
  font-size: 24px;
  cursor: pointer;
  transition: all 0.3s ease 0s;
  border-radius: 50px;
  padding: 20px;
  background :  rgb(28, 136, 224);
  border: 2px solid rgb(28, 136, 224);
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/lib/dropify/js/dropify.min.js')); ?>" type="text/javascript"></script>
<script>
$(function() {
  thisform.d_init();
}), thisform = {
  d_init : function() {
    $('.dropify').dropify();
  },
};

$(function(){
 $(document).on('click','#edit_event',function(e){
   e.preventDefault();
   $("#event_template").modal('show');
 });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>