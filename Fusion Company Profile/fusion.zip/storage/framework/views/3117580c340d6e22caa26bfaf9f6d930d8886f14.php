<footer class="ftco-footer ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About <span><a href="index.html">Travier</a></span></h2>
              <p>Travier is your best travel companion. It has a lot of features to provide your every need when you travel. It will enhance your traveling experience through our suite: Radar, Social, and Plan.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="<?php echo e(url('http://www.instagram.com/travier.travel')); ?>" target="_blank"><span class="icon-instagram"></span></a></li>
                <li class="ftco-animate"><a href="<?php echo e(url('https://twitter.com/Travier7')); ?>" target="_blank"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="<?php echo e(url('https://www.facebook.com/travier.travel')); ?>" target="_blank"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="<?php echo e(url('http://www.instagram.com/travier.testimonials')); ?>" target="_blank"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2">Information</h2>
              <ul class="list-unstyled">
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Booking</a></li>
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Facilities</a></li>
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Contact Us</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Experience</h2>
              <ul class="list-unstyled">
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Adventure</a></li>
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Hotel and Restaurant</a></li>
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Beach</a></li>
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Nature</a></li>
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Camping</a></li>
                <li><a href=""><span class="icon-long-arrow-right mr-2"></span>Party</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-4">
	              <ul>
                  <li style="margin:auto"><img src="<?php echo e(asset('assets/images/office/office.jpg')); ?>" width="200px" height="120px"/></li><br>
	                <li><span class="icon icon-map-marker"></span><span class="text">Mount Palm Block D6 Number 6, North Citraland, Surabaya, East Java, Indonesia</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+866 968 750 604</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@travier.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
	
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
