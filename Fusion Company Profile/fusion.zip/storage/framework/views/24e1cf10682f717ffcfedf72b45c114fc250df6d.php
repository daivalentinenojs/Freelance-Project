<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
<div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">
   <div class="container text-left">
      <div class="row">
         <div class="col-md-8">
            <h1 class="gla_h1_title">3Vite Time Line</h1>
            <h3>Some Subtitle</h3>
         </div>
      </div>
   </div>
</div>
<section id="gla_content" class="gla_content">
   <section class="gla_section">
      <div class="container">
         <div class="row">
            <div class="col-md-8 col-xs-12">
               <div class="gla_post_item">
                  <div class="gla_post_img">
                     <a href="#"><img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10094863536_8f293da2ad_k.jpg')); ?>" alt=""></a>
                  </div>
                  <div class="gla_post_title">
                     <h3><a href="#">We Love to design</a></h3>
                  </div>
                  <div class="gla_post_info">
                     August 10
                     <span class="slash-divider">/</span>
                     <a href="#">Harold Henry</a>
                     <span class="slash-divider">/</span>
                     <a href="#">Web-design</a>, <a href="#">Marketing</a>
                  </div>
                  <p>
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                  </p>
                  <div class="gla_post_more clearfix">
                     <div class="pull-left">
                        <a href="#" class="btn">READ MORE</a>
                     </div>
                     <div class="pull-right" >
                        <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                        <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                        <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                        <i class="ti ti-sharethis"></i>
                        </a>
                        <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                           <li><a href="#"><i class="ti ti-facebook"></i></a>
                           </li>
                           <li><a href="#"><i class="ti ti-twitter"></i></a>
                           <li><a href="#"><i class="ti ti-instagram"></i></a>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="gla_post_item">
                  <div class="gla_post_img gla_team_slider_single">
                     <a href="#"><img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10094956883_a882196f8c_k.jpg')); ?>" alt=""></a>
                     <a href="#"><img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10095069494_01a19308a8_k.jpg')); ?>" alt=""></a>
                     <a href="#"><img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10095079386_b830b27b52_k.jpg')); ?>" alt=""></a>
                  </div>
                  <div class="gla_post_title">
                     <h3><a href="#">Post with Slider Gallery</a></h3>
                  </div>
                  <div class="gla_post_info">
                     August 10
                     <span class="slash-divider">/</span>
                     <a href="#">Harold Henry</a>
                     <span class="slash-divider">/</span>
                     <a href="#">Web-design</a>, <a href="#">Marketing</a>
                  </div>
                  <p>
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                  </p>
                  <div class="gla_post_more clearfix">
                     <div class="pull-left">
                        <a href="#" class="btn">READ MORE</a>
                     </div>
                     <div class="pull-right" >
                        <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                        <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                        <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                        <i class="ti ti-sharethis"></i>
                        </a>
                        <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                           <li><a href="#"><i class="ti ti-facebook"></i></a>
                           </li>
                           <li><a href="#"><i class="ti ti-twitter"></i></a>
                           <li><a href="#"><i class="ti ti-instagram"></i></a>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="gla_post_item">
                  <div class="gla_post_img">
                     <!-- <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/239793212&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false" style="width: 100%; height: 166px; border: 0;"></iframe> -->
                  </div>
                  <div class="gla_post_title">
                     <h3><a href="#">Post with Soundcloud</a></h3>
                  </div>
                  <div class="gla_post_info">
                     August 10
                     <span class="slash-divider">/</span>
                     <a href="#">Harold Henry</a>
                     <span class="slash-divider">/</span>
                     <a href="#">Web-design</a>, <a href="#">Marketing</a>
                  </div>
                  <p>
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                  </p>
                  <div class="gla_post_more clearfix">
                     <div class="pull-left">
                        <a href="#" class="btn">READ MORE</a>
                     </div>
                     <div class="pull-right" >
                        <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                        <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                        <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                        <i class="ti ti-sharethis"></i>
                        </a>
                        <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                           <li><a href="#"><i class="ti ti-facebook"></i></a>
                           </li>
                           <li><a href="#"><i class="ti ti-twitter"></i></a>
                           <li><a href="#"><i class="ti ti-instagram"></i></a>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="gla_post_item">
                  <div class="gla_post_img">
                     <!-- <iframe style="width: 100%; height: 600px; border: 0;" src="https://www.youtube.com/embed/uVju5--RqtY?rel=0&amp;controls=0&amp;showinfo=0" allowfullscreen></iframe> -->
                  </div>
                  <div class="gla_post_title">
                     <h3><a href="#">Post with Video</a></h3>
                  </div>
                  <div class="gla_post_info">
                     August 10
                     <span class="slash-divider">/</span>
                     <a href="#">Harold Henry</a>
                     <span class="slash-divider">/</span>
                     <a href="#">Web-design</a>, <a href="#">Marketing</a>
                  </div>
                  <p>
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                  </p>
                  <div class="gla_post_more clearfix">
                     <div class="pull-left">
                        <a href="#" class="btn">READ MORE</a>
                     </div>
                     <div class="pull-right" >
                        <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                        <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                        <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                        <i class="ti ti-sharethis"></i>
                        </a>
                        <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                           <li><a href="#"><i class="ti ti-facebook"></i></a>
                           </li>
                           <li><a href="#"><i class="ti ti-twitter"></i></a>
                           <li><a href="#"><i class="ti ti-instagram"></i></a>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="gla_post_item">
                  <div class="gla_post_img">
                     <a href="images/wedding/andy_jeska/10095086876_adc6b57d6e_k.jpg')}}" class="lightbox">
                     <img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10095086876_adc6b57d6e_k.jpg')); ?>" alt="">
                     </a>
                  </div>
                  <div class="gla_post_title">
                     <h3><a href="#">Post with Lighbox</a></h3>
                  </div>
                  <div class="gla_post_info">
                     August 10
                     <span class="slash-divider">/</span>
                     <a href="#">Harold Henry</a>
                     <span class="slash-divider">/</span>
                     <a href="#">Web-design</a>, <a href="#">Marketing</a>
                  </div>
                  <p>
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                  </p>
                  <div class="gla_post_more clearfix">
                     <div class="pull-left">
                        <a href="#" class="btn">READ MORE</a>
                     </div>
                     <div class="pull-right" >
                        <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                        <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                        <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                        <i class="ti ti-sharethis"></i>
                        </a>
                        <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                           <li><a href="#"><i class="ti ti-facebook"></i></a>
                           </li>
                           <li><a href="#"><i class="ti ti-twitter"></i></a>
                           <li><a href="#"><i class="ti ti-instagram"></i></a>
                        </ul>
                     </div>
                  </div>
               </div>
               <nav class="gla_blog_pag">
                  <ul class="pagination">
                     <li><a href="#"><i class="ti ti-angle-left"></i></a></li>
                     <li class="active" ><a href="#">1</a></li>
                     <li><a href="#">2</a></li>
                     <li><a href="#">3</a></li>
                     <li><a href="#">4</a></li>
                     <li><a href="#">5</a></li>
                     <li><a href="#"><i class="ti ti-angle-right"></i></a></li>
                  </ul>
               </nav>
            </div>
            <div class="col-md-3 col-md-push-1 hidden-xs hidden-sm">
               <div class="widget">
                  <h6 class="title">About The Author</h6>
                  <p>
                     Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua.
                  </p>
               </div>
               <div class="widget">
                  <h6 class="title">Search Blog</h6>
                  <form>
                     <input class="form-control" type="text" placeholder="Enter Your Keywords" />
                  </form>
               </div>
               <div class="widget">
                  <h6 class="title">Blog Categories</h6>
                  <ul class="list-unstyled">
                     <li>
                        <a href="#">Business</a>
                     </li>
                     <li>
                        <a href="#">Creative</a>
                     </li>
                     <li>
                        <a href="#">Photography</a>
                     </li>
                     <li>
                        <a href="#">Freelance</a>
                     </li>
                  </ul>
               </div>
               <div class="widget">
                  <h6 class="title">Recent Posts</h6>
                  <ul class="list-unstyled recent-posts">
                     <li>
                        <a href="#">Ut enim ad minim veniam, quis nostrud</a>
                        <span class="date">November 10, 2016</span>
                     </li>
                     <li>
                        <a href="#">Excepteur sint occaecat</a>
                        <span class="date">November 08, 2016</span>
                     </li>
                     <li>
                        <a href="#">Duis aute irure dolor in reprehenderit in voluptate velit</a>
                        <span class="date">November 05, 2016</span>
                     </li>
                  </ul>
               </div>
               <div class="widget bg-secondary p24">
                  <h6 class="title">Subscribe Now</h6>
                  <p>
                     Subscribe to our newsletter.
                  </p>
                  <form>
                     <input type="text" class="form-control" name="email" placeholder="Email Address" />
                     <input type="submit" class="btn btn-default no-margin" value="Subscribe" />
                  </form>
               </div>
            </div>
         </div>
      </div>
   </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>