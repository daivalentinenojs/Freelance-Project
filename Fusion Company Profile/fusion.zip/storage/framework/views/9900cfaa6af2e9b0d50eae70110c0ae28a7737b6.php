<?php $__env->startSection('title','Pink Invitation'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding_m/anne-edgar-119384_2.jpg')); ?>" id="gla_page" >

<!-- Over -->
<div class="gla_over" data-color="#181224" data-opacity="0.3"></div>


    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>

    <!-- Music -->
    <div class="gla_music_icon">
        <i class="ti ti-music"></i>
    </div>
    <div class="gla_music_icon_cont">
        <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/47701713&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>
    </div>

    <!-- Header -->
    <header>



        <nav class="gla_light_nav gla_transp_nav">

            <div class="container">

                <div class="gla_logo_container clearfix">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="gla_logo_rev">
                    <div class="gla_logo_txt">
                        <!-- Logo -->
                        <a href="http://glanz.starkethemes.com/" class="gla_logo">Clark & Ann</a>

                        <!-- Text Logo -->
                        <div class="gla_logo_und"><?php echo e($date['date']); ?></div>
                    </div>
                </div>

                <!-- Menu -->
                <div class="gla_main_menu gla_main_menu_mobile">

                    <div class="gla_main_menu_icon">
                        <i></i><i></i><i></i><i></i>
                        <b>Menu</b>
                        <b class="gla_main_menu_icon_b">Back</b>
                    </div>
                </div>

                <!-- Menu Content -->
                <!-- <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
                <!-- menu content end -->

                <!-- Search Block -->
                <div class="gla_search_block">

                    <div class="gla_search_block_link gla_search_parent"><i class="ti ti-search"></i>
                        <ul>
                            <li>
                                <form>
                                    <input type="text" class="form-control" placeholder="Enter Your Keywords">
                                    <button type="submit" class="btn">
                                      <i class="ti ti-search"></i>
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Search Block End -->

                <!-- Top Menu -->
                <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- Top Menu End -->



            </div>
            <!-- container end -->
        </nav>

    </header>
    <!-- Header End -->




    <!-- Content -->
    <section id="gla_content" class="gla_content">

        <div class="gla_invitation_container">
            <div class="gla_invitation_i gla_invitation_ii gla_image_bck" data-image="<?php echo e(asset('assets/images/invitations/inv_i/back3.jpg')); ?>">
                <p><img src="<?php echo e(asset('assets/images/invitations/inv_i/save_the_date_pu.gif')); ?>" alt="" height="240"></p>
                <br><br>
                <h2>Kevin & Julie</h2>
                <h4><?php echo e($date['date']); ?></h4>
                <h4>St. Thomas's Church, Bristol</h4>
            </div>
        </div>


    </section>
    <!-- Content End -->




</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>