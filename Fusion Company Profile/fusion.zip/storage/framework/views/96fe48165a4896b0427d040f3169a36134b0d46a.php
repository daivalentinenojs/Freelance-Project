<?php $__env->startSection('title','About Us'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page" id="gla_page">



    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>

    <!-- Header -->
    <header>



        <nav class="gla_light_nav gla_transp_nav">
            <div class="container">

                <div class="gla_logo_container clearfix">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="gla_logo_rev">
                    <div class="gla_logo_txt">
                        <!-- Logo -->
                        <a href="" class="gla_logo">3Vite Company</a>

                        <!-- Text Logo -->
                        <div class="gla_logo_und">About Us</div>
                    </div>
                </div>

                <!-- Menu -->
                <div class="gla_main_menu gla_main_menu_mobile">

                    <div class="gla_main_menu_icon">
                        <i></i><i></i><i></i><i></i>
                        <b>Menu</b>
                        <b class="gla_main_menu_icon_b">Back</b>
                    </div>
                </div>

                <!-- Menu Content -->
                <!-- <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
                <!-- menu content end -->

                <!-- Search Block -->
                <div class="gla_search_block">

                    <div class="gla_search_block_link gla_search_parent"><i class="ti ti-search"></i>
                        <ul>
                            <li>
                                <form>
                                    <input type="text" class="form-control" placeholder="Enter Your Keywords">
                                    <button type="submit" class="btn">
                                      <i class="ti ti-search"></i>
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Search Block End -->

                <!-- Top Menu -->
                <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- Top Menu End -->



            </div>
            <!-- container end -->
        </nav>

    </header>
    <!-- Header End -->


    <!-- PAGE TITLE SMALL -->
    <div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">



      <div class="container text-left">
        <div class="row">

          <div class="col-md-8">
            <h1 class="gla_h1_title">About Us</h1>
            <h3>Some Subtitle</h3>
          </div>
        </div>
      </div>
    </div>

    <!-- Content -->
    <section id="gla_content" class="gla_content">



        <!-- section -->
        <section class="gla_section gla_image_bck" data-color="#fafafd">



            <div class="container text-center">
                <p><img src="<?php echo e(asset('assets/images/animations/flower5.gif')); ?>" data-bottom-top="@src:images/animations/flower5.gif; opacity:1" class="gla_animated_flower" height="150" alt=""></p>
                <h2>Our Story</h2>
                <h3 class="gla_subtitle">The Fourth of July</h3>



                <p>My fiancé proposed on the Fourth of July. My mother asked us to go to the backyard to get some chairs and he took me by the shed where we could see all of the fireworks. He kissed me, then he took the ring box out of his pocket and asked me to be his wife. He was shaking a little. The proposal was a little silly but perfect, just like him." — Jeska Cords</p>



            </div>
            <!-- container end -->

        </section>
        <!-- section end -->

        <!-- section -->
        <section class="gla_section gla_image_bck gla_fixed" data-stellar-background-ratio="0.2" data-image="<?php echo e(asset('assets/images/wedding/ian_kelsey/14815177364_46f0b9d71e_k.jpg')); ?>">


            <div class="container">
                <div class="row gla_auto_height">
                    <div class="col-md-6 gla_image_bck" data-color="#eee">
                        <div class="gla_simple_block">
                            <h2>Dian Yulius</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio mollitia, ipsa accusamus eius. Aspernatur ab sed minima, doloremque eligendi voluptatibus repellat unde, facilis natus ex ipsum eius atque suscipit fugit.</p>
                            <!-- Social Buttons -->
                            <div class="gla_footer_social">
                                <a href="#"><i class="ti ti-facebook gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-instagram gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-google gla_icon_box"></i></a>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding/ian_kelsey/14818410145_0413998881_k.jpg')); ?>">

                    </div>
                    <div class="col-md-6 col-md-push-6 gla_image_bck" data-color="#eee">
                        <div class="gla_simple_block">
                            <h2>Daivalentineno Janitra Salim</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio mollitia, ipsa accusamus eius. Aspernatur ab sed minima, doloremque eligendi voluptatibus repellat unde, facilis natus ex ipsum eius atque suscipit fugit.</p>
                            <!-- Social Buttons -->
                            <div class="gla_footer_social">
                                <a href="#"><i class="ti ti-facebook gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-instagram gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-google gla_icon_box"></i></a>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 col-md-pull-6 gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding/ian_kelsey/14815312201_0608beeccd_k.jpg')); ?>">

                    </div>
                    <div class="col-md-6 gla_image_bck" data-color="#eee">
                        <div class="gla_simple_block">
                            <h2>Fransisca Alexandra Stefanie</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio mollitia, ipsa accusamus eius. Aspernatur ab sed minima, doloremque eligendi voluptatibus repellat unde, facilis natus ex ipsum eius atque suscipit fugit.</p>
                            <!-- Social Buttons -->
                            <div class="gla_footer_social">
                                <a href="#"><i class="ti ti-facebook gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-instagram gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-google gla_icon_box"></i></a>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding/ian_kelsey/14818410145_0413998881_k.jpg')); ?>">

                    </div>
                </div>

            </div>
            <!-- container end -->

        </section>
        <!-- section end -->

        <!-- section -->
        <section class="gla_section gla_lg_padding gla_image_bck gla_fixed gla_wht_txt" data-stellar-background-ratio="0.2" data-image="<?php echo e(asset('assets/images/wedding/carita_lee/15499168455_d3a42471c3_k.jpg')); ?>">

             <div class="gla_slider_flower" data-bottom-top="@class:active" data--200-bottom="@class:no_active">
            <div class="gla_slider_flower_c1 gla_slider_flower_item"></div>
            <div class="gla_slider_flower_c2 gla_slider_flower_item"></div>
            <div class="gla_slider_flower_c3 gla_slider_flower_item"></div>
            <div class="gla_slider_flower_c4 gla_slider_flower_item"></div>
            <div class="gla_slider_flower_c5 gla_slider_flower_item"></div>
            <div class="gla_slider_flower_c6 gla_slider_flower_item"></div>
        </div>


            <div class="container text-center">

                <p><img src="<?php echo e(asset('assets/images/animations/ourwedding_wh.gif')); ?>" data-bottom-top="@src:images/animations/ourwedding_wh.gif')}}" height="150" alt=""></p>

                <h2>We’re Getting Married!</h2>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium nisi earum nihil perspiciatis magnam facilis, error explicabo obcaecati maiores sunt exercitationem doloribus tempora, sit voluptate autem quibusdam velit alias. Reprehenderit.</p>



            </div>
            <!-- container end -->

        </section>
        <!-- section end -->

        <!-- section -->
        <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.4" data-image="<?php echo e(asset('assets/images/wedding/mark_liz/10502734756_d295257d36_k.jpg')); ?>">

            <!-- Over -->
            <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>

            <div class="container text-left">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <h2>Our Story</h2>
                        <h3 class="gla_subtitle">The Fourth of July</h3>

                        <p>My fiancé proposed on the Fourth of July. My mother asked us to go to the backyard to get some chairs and he took me by the shed where we could see all of the fireworks. He kissed me, then he took the ring box out of his pocket and asked me to be his wife. He was shaking a little. The proposal was a little silly but perfect, just like him." — Jeska Cords</p>
                    </div>
                </div>


            </div>
            <!-- container end -->

        </section>
        <!-- section end -->

        <!-- section -->
        <section class="gla_section">



            <div class="container text-center">



                <div class="row text-center">

                    <div class="col-md-4 gla_round_block">
                        <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding/carita_lee/600x600/15503304111_d927414239_k.jpg')); ?>"></div>
                        <h3>Dian Yulius</h3>
                    </div>
                    <div class="col-md-4 gla_round_block">
                        <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding/carita_lee/600x600/15319460687_17d6396bac_k.jpg')); ?>"></div>
                        <h3>Daivalentineno <br> Janitra Salim</h3>
                    </div>
                    <div class="col-md-4 gla_round_block">
                        <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding/carita_lee/600x600/15503304111_d927414239_k.jpg')); ?>"></div>
                        <h3>Fransisca Alexandra Stefanie</h3>
                    </div>

                </div>



            </div>
            <!-- container end -->

        </section>
        <!-- section end -->



    </section>
    <!-- Content End -->


    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <!-- Footer End -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>