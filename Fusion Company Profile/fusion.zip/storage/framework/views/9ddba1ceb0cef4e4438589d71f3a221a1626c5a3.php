 <ul>
   <!-- <li><a href="<?php echo e(url('/')); ?>">Home</a></li> -->
   <li class="gla_parent">
      <a>Invitation</a>
      <ul>
         <?php $__currentLoopData = $gbl_event_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><a href="<?php echo e(url('category/'.$category->link_url)); ?>"><?php echo e($category->nama); ?></a></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </li>
    <?php if(!(Auth::check()) || (Auth::check() && Auth::user()->jabatan == 2)): ?>
      <!-- <li class="gla_parent">
         <a href="">Template</a>
         <ul>
            <li><a href="<?php echo e(url('template/animatedflower')); ?>">Animated Flower</a></li>
            <li><a href="<?php echo e(url('template/pinkanimatedflower')); ?>">Pink Animated Flower</a></li>
            <li><a href="<?php echo e(url('template/goldenbadge')); ?>">Golden Badge</a></li>
            <li><a href="<?php echo e(url('template/greatflower')); ?>">Great Flower</a></li>
            <li><a href="<?php echo e(url('template/simpleflower')); ?>">Simple Flower</a></li>
            <li><a href="<?php echo e(url('template/abstractflower')); ?>">Abstract Flower</a></li>
            <li><a href="<?php echo e(url('template/parallax')); ?>">Parallax</a></li>
            <li><a href="<?php echo e(url('template/landing')); ?>">Landing</a></li>
         </ul>
      </li> -->
      <!-- <li class="gla_parent">
         <a href="">Partner</a>
         <ul>
            <li><a href="<?php echo e(url('partner/weddingplanner')); ?>">Wedding Planner</a></li>
            <li><a href="<?php echo e(url('partner/weddingflower')); ?>">Wedding Flower</a></li>
            <li><a href="<?php echo e(url('partner/weddingcake')); ?>">Wedding Cake</a></li>
            <li><a href="<?php echo e(url('partner/shop')); ?>">Wedding Shop</a></li>
         </ul>
      </li> -->
    <?php endif; ?>

    <?php if(Auth::check()): ?>
    <!-- <li><a href="<?php echo e(url('event')); ?>">Make Event</a></li> -->
    <?php else: ?>
    <!-- <li><a href="<?php echo e(url('event/x')); ?>">Make Event</a></li> -->
    <?php endif; ?>

    <li><a href="<?php echo e(url('timeline')); ?>">Timeline</a></li>

    <?php if(Auth::check()): ?>
      <?php if(Auth::user()->jabatan == 1): ?>
      <li class="gla_parent">
         <a href="">Master Data</a>
         <ul>
            <li><a href="<?php echo e(url('master/user')); ?>">User</a></li>
            <li><a href="<?php echo e(url('master/category')); ?>">Event Category</a></li>
            <li><a href="<?php echo e(url('master/template')); ?>">Event Template</a></li>
            <li><a href="<?php echo e(url('master/detail')); ?>">Event Detail</a></li>
            <li><a href="<?php echo e(url('master/weddingplanner')); ?>">Wedding Planner</a></li>
            <li><a href="<?php echo e(url('master/weddingflower')); ?>">Wedding Flower</a></li>
            <li><a href="<?php echo e(url('master/weddingcake')); ?>">Wedding Cake</a></li>
            <li><a href="<?php echo e(url('master/item')); ?>">Item</a></li>
         </ul>
      </li>
      <?php endif; ?>
    <?php endif; ?>

    <li class="gla_parent">
       <a href="">Help</a>
       <ul>
          <li><a href="<?php echo e(url('contact-us')); ?>">Contact Us</a></li>
          <li><a href="<?php echo e(url('about-us')); ?>">About Us</a></li>
       </ul>
    </li>
    <!-- <li><a href="<?php echo e(url('aboutus')); ?>">About Us</a></li> -->

    <?php if(!(Auth::check())): ?>
      <li><a href="<?php echo e(url('login')); ?>">Login / Register</a></li>
    <?php else: ?>
      <li class="gla_parent">
         <a href=""><?php echo e(ucwords(Auth::user()->nama)); ?></a>
         <ul>
            <li><a href="<?php echo e(url('event')); ?>">Event</a></li>
            <li><a href="<?php echo e(url('profile/data')); ?>">Profile</a></li>
            <li><a href="<?php echo e(url('profile/account')); ?>">Change Password</a></li>
            <li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
         </ul>
      </li>
    <?php endif; ?>

 </ul>
