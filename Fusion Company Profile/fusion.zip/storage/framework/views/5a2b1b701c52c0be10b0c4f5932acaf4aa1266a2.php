<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('includes.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<!-- Body -->
<body class="gla_middle_titles">

<!-- Page -->
<div class="gla_page" id="gla_page">    
    
    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>

    <!-- Music -->
    <?php echo $__env->yieldContent('music'); ?>
    <!-- Music End -->

    <!-- Header -->
    <header>
        <nav class="gla_light_nav gla_transp_nav">
            <!-- Container -->              
            <?php echo $__env->make('includes.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Container end -->
        </nav>        
    </header>
    <!-- Header End -->

    <!-- Slider -->
    <?php echo $__env->yieldContent('slider'); ?>
    <!-- Slider End -->

    <!-- Section -->
    <section id="gla_content" class="gla_content">

      <!-- Content -->
      <?php echo $__env->yieldContent('content'); ?>
      <!-- Content End -->

      <!-- Footer -->
      <?php echo $__env->make('includes.footer-complete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- Footer End -->
        
    </section>
    <!-- Section End --> 

</div>
<!-- Page End -->

<?php echo $__env->make('includes.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>

</body>
</html>