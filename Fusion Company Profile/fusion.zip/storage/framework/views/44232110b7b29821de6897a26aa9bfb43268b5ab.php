<?php $__env->startSection('title','Event'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">
   <div class="container text-left">
      <div class="row">
         <div class="col-md-8">
            <h1 class="gla_h1_title">Add Guest</h1>
            <h3>This page may you to add, view, or edit your guest</h3>
         </div>
      </div>
   </div>
</div>
<form class="form-horizontal" method="POST" id="form_guest" action="<?php echo e(url()->current()); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php if($errors->any()): ?>
   <div class="alert alert-danger">
     <span aria-hidden="true" class="alert-icon icon_blocked"></span><strong>Error! </strong>There are some problems.
       <ul>
           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
   </div>
<?php endif; ?>
<section id="gla_content" class="gla_content">
  <section class="gla_section">
     <div class="container">
       <?php if(session('status')): ?>
       <div class="alert <?php echo e(session('status')['alert']); ?>">
         <span aria-hidden="true" class="alert-icon icon_blocked"></span><strong><?php echo e(session('status')['status']); ?> </strong><?php echo e(session('status')['message']); ?>

       </div>
       <?php endif; ?>
       <div class="form-group row">
           <div class="col-md-6">
               <label>Guest's Name* <small class="form-text text-muted"> Ex. Daivalentineno Janitra Salim</small></label>
                 <input type="text" name="guest_name" id="guest_name" class="form-control form-opacity" data-parsley-maxlength="300" data-parsley-minlength="3" value="">
           </div>
           <div class="col-md-6">
               <label>Address* <small class="form-text text-muted"> Ex. North Citraland Block D6 Number 6</small></label>
                 <input type="text" name="address" id="address" class="form-control form-opacity" data-parsley-maxlength="300" data-parsley-minlength="3" value="">
           </div>
       </div>
       <div class="form-group row">
           <div class="col-md-6">
               <label>Phone* <small class="form-text text-muted"> Ex. 089695969367</small></label>
                 <input type="text" name="phone" id="phone" onkeypress="return isNumberKey(event)" class="form-control form-opacity" data-parsley-maxlength="300" data-parsley-minlength="3" value="">
           </div>
           <div class="col-md-6">
               <label>Email* <small class="form-text text-muted"> Ex. daivalentinenojs@gmail.com</small></label>
                 <input type="email" name="email" id="email" class="form-control form-opacity" data-parsley-maxlength="300" data-parsley-minlength="3" value="">
           </div>
       </div>
       <div class="form-group row">
           <div class="col-md-6">
               <label>Whats App* <small class="form-text text-muted"> Ex. 089695969367</small></label>
                 <input type="text" name="whatsapp" id="whatsapp" onkeypress="return isNumberKey(event)" class="form-control form-opacity" data-parsley-maxlength="300" data-parsley-minlength="3" value="">
           </div>
           <div class="col-md-6">
               <label>Line* <small class="form-text text-muted"> Ex. 089695969367</small></label>
                 <input type="text" name="line" id="line" class="form-control form-opacity" data-parsley-maxlength="300" data-parsley-minlength="3" value="">
           </div>
       </div>
       <div class="form-group row">
         <div class="col-md-6">
           <label>Category* <small class="form-text text-muted"> Ex. Family</small></label>
           <select class="form-control select col-md-6" name="id_category" id="id_category" data-live-search="true">
             <option value="1">Family</option>
             <option value="2">Couple</option>
             <option value="3">Single</option>
           </select>
         </div>
         <div class="col-md-6">
               <input type="hidden" name="id_guest" id="id_guest" class="form-control form-opacity" value="">
               <input type="hidden" name="id_action" id="id_action" class="form-control form-opacity" value="">
               <input type="hidden" name="id_event" id="id_event" class="form-control form-opacity" value="<?php echo e($did); ?>">
         </div>
       </div>
       <div class="col-md-12">
         <div class="form-group">
               <div class="col-md-4">
               </div>
               <div class="col-md-8"><br>
                  <!-- <input type="submit" class="btn btn-success" name="btnAdd" value="Add Guest">
                  <input type="submit" class="btn btn-danger" name="btnDelete" value="Delete Guest"> -->
                  <button type="button" id="addRow" class="btn btn-success" name="addRow">Add Guest</button>
                  <button type="button" id="deleteRow" class="btn btn-danger" name="deleteRow">Delete Guest</button><br><br><br>
               </div>
         </div>
       </div>
       <div class="row">
          <div>
             <div class="col-md-12 gla_main_sidebar">
                <table class="table" id="DataTableGuest">
                   <thead>
                      <tr>
                         <th>Name</th>
                         <th>Address</th>
                         <th>Phone</th>
                         <th>Email</th>
                         <th>Whats App</th>
                         <th>Line</th>
                         <th>Category</th>
                      </tr>
                   </thead>
                   <tbody>
                       <?php $__currentLoopData = $guest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                         <td><?php echo e($g->nama); ?></td>
                         <td><?php echo e($g->alamat); ?></td>
                         <td><?php echo e($g->telepon); ?></td>
                         <td><?php echo e($g->email); ?></td>
                         <td><?php echo e($g->whatsapp); ?></td>
                         <td><?php echo e($g->line); ?></td>
                         <td>
                           <?php if($g->jenis == 1): ?>
                              Family
                           <?php elseif($g->jenis == 2): ?>
                              Couple
                           <?php elseif($g->jenis == 3): ?>
                              Single
                           <?php endif; ?>
                         </td>
                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                   <tfoot>
                      <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Whats App</th>
                        <th>Line</th>
                        <th>Category</th>
                      </tr>
                   </tfoot>
                </table>
             </div>
          </div>
       </div>
     </div>
  </section>
</section>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('assets/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
<script>
// var ArrayName = new Array();
// var ArrayAddress = new Array();
// var ArrayPhone = new Array();
// var ArrayEmail = new Array();
// var ArrayWhatsApp = new Array();
// var ArrayLine = new Array();
// var ArrayCategory = new Array();

var t = $('#DataTableGuest').DataTable();

function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if ((charCode > 31 && (charCode < 48 || charCode > 57)))
        return false;
    return true;
}

$('#addRow').on( 'click', function () {
  $('#id_action').val(1);
  $('#form_guest').submit();
});

$('#deleteRow').on( 'click', function () {
  $('#id_action').val(2);
  $('#form_guest').submit();
})

$(document).ready(function() {
    // $('#addRow').on( 'click', function () {
    //   Name = $('#guest_name').val();
    //   Address = $('#address').val();
    //   Phone = $('#phone').val();
    //   Email = $('#email').val();
    //   Whatsapp = $('#whatsapp').val();
    //   Line = $('#line').val();
    //   IDCategory = $('#id_category').val();
    //
    //   if (Name != '' && Address != '' && Phone != '' && Email != '' && Whatsapp != '' && Line != '' && IDCategory != '') {
    //     ArrayName.push(Name);
    //     $('<input>').attr({
    //       type:'hidden',
    //       name:'ArrayName[]',
    //       value:Name
    //     }).appendTo('form');
    //
    //     ArrayAddress.push(Address);
    //     $('<input>').attr({
    //       type:'hidden',
    //       name:'ArrayAddress[]',
    //       value:Address
    //     }).appendTo('form');
    //
    //     ArrayPhone.push(Phone);
    //     $('<input>').attr({
    //       type:'hidden',
    //       name:'ArrayPhone[]',
    //       value:Phone
    //     }).appendTo('form');
    //
    //     ArrayEmail.push(Email);
    //     $('<input>').attr({
    //       type:'hidden',
    //       name:'ArrayEmail[]',
    //       value:Email
    //     }).appendTo('form');
    //
    //     ArrayWhatsApp.push(Whatsapp);
    //     $('<input>').attr({
    //       type:'hidden',
    //       name:'ArrayWhatsApp[]',
    //       value:Whatsapp
    //     }).appendTo('form');
    //
    //     ArrayLine.push(Line);
    //     $('<input>').attr({
    //       type:'hidden',
    //       name:'ArrayLine[]',
    //       value:Line
    //     }).appendTo('form');
    //
    //     ArrayCategory.push(IDCategory);
    //     $('<input>').attr({
    //       type:'hidden',
    //       name:'ArrayCategory[]',
    //       value:IDCategory
    //     }).appendTo('form');
    //
    //     if (IDCategory == 1) {
    //       StrCategory = 'Family';
    //     } else if (IDCategory == 2) {
    //       StrCategory = 'Couple';
    //     } else if (IDCategory == 3) {
    //       StrCategory = 'Single';
    //     }
    //
    //     t.row.add([
    //         Name,
    //         Address,
    //         Phone,
    //         Email,
    //         Whatsapp,
    //         Line,
    //         StrCategory
    //     ] ).draw(true);
    //
    //     $('#guest_name').val('');
    //     $('#address').val('');
    //     $('#phone').val('');
    //     $('#email').val('');
    //     $('#whatsapp').val('');
    //     $('#line').val('');
    //
    //   } else {
    //
    //     alert('Please fill required field');
    //
    //   }
    // });

    $('#DataTableGuest tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        } else {
           t.$('tr.selected').removeClass('selected');
           $(this).addClass('selected');
           Index = t.row( this ).index();
           NamaGuest = t.row(Index).data();
           $('#id_guest').val(NamaGuest);
           // console.log(NamaGuest);
        }
    });

    // $('#deleteRow').click( function () {
    //     t.row('.selected').remove().draw( false );
    //
    //     ArrayName.splice(Index, 1);
    //     ArrayAddress.splice(Index, 1);
    //     ArrayPhone.splice(Index, 1);
    //     ArrayEmail.splice(Index, 1);
    //     ArrayWhatsApp.splice(Index, 1);
    //     ArrayLine.splice(Index, 1);
    //     ArrayCategory.splice(Index, 1);
    // });
});

// $(function () {
//   thisform.init();
// }), thisform = {
//   init : function () {
//     $('#table').DataTable({
//         processing: true,
//         serverSide: true,
//         ajax: "<?php echo e(url('event/dt')); ?>",
//         columns: [
//             {data: 'nama', name: 'nama'},
//             {data: 'template', name: 'template'},
//             {data: 'category', name: 'category'},
//             {data: 'action', name: 'action'},
//         ]
//     });
//   },
// }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>