<?php $__env->startSection('title','Contact Us'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section bg-light" id="blog-section">
    <div class="container">
      <div class="row justify-content-center mb-5 pb-5">
        <div class="col-md-7 heading-section text-center ftco-animate">
          <span class="subheading">Blog</span>
          <h2 class="mb-4">Our Blog</h2>
          <p>"Your brand is what other people say about you when you are not in the room." - Jeff Bezos</p>
        </div>
      </div>
      <div class="row d-flex">
        <div class="col-md-6 col-lg-4 d-flex ftco-animate">
          <div class="blog-entry justify-content-end">
            <a href="single.html" class="block-20" style="background-image: url('<?php echo e(asset('assets/images/image_1.jpg')); ?>');">
            </a>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">12</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">april</span>
                </div>
              </div>
              <h3 class="heading"><a href="single.html">Why Lead Generation is Key for Business Growth</a></h3>
              <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="#" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <a href="#" class="mr-2">Admin</a>
                  <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 d-flex ftco-animate">
          <div class="blog-entry justify-content-end">
            <a href="single.html" class="block-20" style="background-image: url('<?php echo e(asset('assets/images/image_2.jpg')); ?>');">
            </a>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">12</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">april</span>
                </div>
              </div>
              <h3 class="heading"><a href="single.html">Why Lead Generation is Key for Business Growth</a></h3>
              <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="#" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <a href="#" class="mr-2">Admin</a>
                  <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 d-flex ftco-animate">
          <div class="blog-entry">
            <a href="single.html" class="block-20" style="background-image: url('<?php echo e(asset('assets/images/image_3.jpg')); ?>');">
            </a>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">12</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">april</span>
                </div>
              </div>
              <h3 class="heading"><a href="single.html">Why Lead Generation is Key for Business Growth</a></h3>
              <p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="#" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <a href="#" class="mr-2">Admin</a>
                  <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>