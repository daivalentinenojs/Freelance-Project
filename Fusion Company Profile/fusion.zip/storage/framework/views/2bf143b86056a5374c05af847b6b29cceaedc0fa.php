<?php $__env->startSection('title','Blog'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section bg-light" id="blog-section">
    <div class="container">
      <div class="row justify-content-center mb-5 pb-5">
        <div class="col-md-7 heading-section text-center ftco-animate">
          <span class="subheading">Blog</span>
          <h2 class="mb-4">Travier Blog</h2>
          <p>"Your brand is what other people say about you when you are not in the room." - Jeff Bezos</p>
        </div>
      </div>
      <div class="row d-flex">
        
        <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
          <div class="blog-entry justify-content-end">
            <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/1.jpg')); ?>');">
            </span>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">26th</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">August</span>
                </div>
              </div>
              <h3 class="heading"><span>Sydney Bridge Climb, Sydney, Australia</span></h3>
              <p>Step your Sydney sightseeing up a gear by taking on the Sydney Bridge Climb.</p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="<?php echo e(url('/blog/1')); ?>" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <span class="mr-2">Admin</span>
                  <span class="meta-chat"><span class="icon-chat"></span> 2</span>
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
          <div class="blog-entry justify-content-end">
            <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/2.jpg')); ?>');">
            </span>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">27th</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">August</span>
                </div>
              </div>
              <h3 class="heading"><span>White Water River Rafting,Balsa River, Costa Rica</span></h3>
              <p>Practice your rafting skills before embarking on this rafting tour. </p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="<?php echo e(url('/blog/2')); ?>" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <span class="mr-2">Admin</span>
                  <span class="meta-chat"><span class="icon-chat"></span> 1</span>
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
          <div class="blog-entry">
            <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/3.jpg')); ?>');">
            </span>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">28th</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">August</span>
                </div>
              </div>
              <h3 class="heading"><span>Tandem Parasail Flight over the Bay of Islands, New Zealand</span></h3>
              <p>Fly high above the Bay of Islands on a tandem parasailing tour. </p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="<?php echo e(url('/blog/3')); ?>" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <span class="mr-2">Admin</span>
                  <span class="meta-chat"><span class="icon-chat"></span> 3</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
          <div class="blog-entry">
            <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/4.jpg')); ?>');">
            </span>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">29th</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">August</span>
                </div>
              </div>
              <h3 class="heading"><span>Snorkel with Wild Dolphins & Reef Adventure!, Hawaii</span></h3>
              <p>14 guest max, no massive crowds! Snorkel with wild dolphins. </p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="<?php echo e(url('/blog/4')); ?>" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <span class="mr-2">Admin</span>
                  <span class="meta-chat"><span class="icon-chat"></span> 1</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
          <div class="blog-entry">
            <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/5.jpg')); ?>');">
            </span>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">30th</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">August</span>
                </div>
              </div>
              <h3 class="heading"><span>Private Customizable Sailing Tour in Cancun</span></h3>
              <p>Enjoy a private sailing tour for you and your party aboard a 44-feet sailboat Bavaria.</p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="<?php echo e(url('/blog/5')); ?>" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <span class="mr-2">Admin</span>
                  <span class="meta-chat"><span class="icon-chat"></span> 2</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
          <div class="blog-entry">
            <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/6.jpg')); ?>');">
            </span>
            <div class="text float-right d-block">
              <div class="d-flex align-items-center pt-2 mb-4 topp">
                <div class="one mr-2">
                  <span class="day">31st</span>
                </div>
                <div class="two">
                  <span class="yr">2019</span>
                  <span class="mos">August</span>
                </div>
              </div>
              <h3 class="heading"><span>Bali Boarders Surfschool, Bali,  Indonesia</span></h3>
              <p>Bali Boarders Surfing is a local Surfing School located in Bali.  </p>
              <div class="d-flex align-items-center mt-4 meta">
                <p class="mb-0"><a href="<?php echo e(url('/blog/6')); ?>" class="btn btn-primary">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                <p class="ml-auto mb-0">
                  <span class="mr-2">Admin</span>
                  <span class="meta-chat"><span class="icon-chat"></span> 3</span>
                </p>
              </div>
            </div>
          </div>
        </div>        

      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>