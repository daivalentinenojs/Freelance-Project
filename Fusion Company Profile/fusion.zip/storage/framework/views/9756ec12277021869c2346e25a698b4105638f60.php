<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page" id="gla_page">



    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>

    <!-- Header -->
    <header>



        <nav class="gla_light_nav gla_transp_nav">
            <div class="container">

                <div class="gla_logo_container clearfix">
                    <img src="<?php echo e(asset('assets/images/glanz_logo.png')); ?>" alt="" class="gla_logo_rev">
                    <div class="gla_logo_txt">
                        <!-- Logo -->
                        <a href="http://glanz.starkethemes.com/" class="gla_logo">Andy & Jeska</a>

                        <!-- Text Logo -->
                        <div class="gla_logo_und">August 10, 2017</div>
                    </div>
                </div>

                <!-- Menu -->
                <div class="gla_main_menu gla_main_menu_mobile">

                    <div class="gla_main_menu_icon">
                        <i></i><i></i><i></i><i></i>
                        <b>Menu</b>
                        <b class="gla_main_menu_icon_b">Back</b>
                    </div>
                </div>

                <!-- Menu Content -->
                <!-- <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
                <!-- menu content end -->

                <!-- Search Block -->
                <div class="gla_search_block">

                    <div class="gla_search_block_link gla_search_parent"><i class="ti ti-search"></i>
                        <ul>
                            <li>
                                <form>
                                    <input type="text" class="form-control" placeholder="Enter Your Keywords">
                                    <button type="submit" class="btn">
                                      <i class="ti ti-search"></i>
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Search Block End -->

                <!-- Top Menu -->
                <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- Top Menu End -->



            </div>
            <!-- container end -->
        </nav>

    </header>
    <!-- Header End -->


    <!-- PAGE TITLE SMALL -->
    <div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">



      <div class="container text-left">
        <div class="row">

          <div class="col-md-8">
            <h1 class="gla_h1_title">Blog</h1>
            <h3>Some Subtitle</h3>
          </div>

          <div class="col-md-4">
            <div class="breadcrumbs">
              <a href="#">Home</a><a href="#">Blog</a><span>Blog</span>
            </div>
          </div>

        </div>
      </div>
    </div>

    <!-- Content -->
    <section id="gla_content" class="gla_content">





        <!-- section -->
        <section class="gla_section">
            <div class="container">

            <div class="row">
                <div class="col-md-8 col-xs-12">

                    <!-- Post Item -->
                    <div class="gla_post_item">

                        <div class="gla_post_img">
                          <a href="#"><img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10094863536_8f293da2ad_k.jpg')); ?>" alt=""></a>
                        </div>

                        <div class="gla_post_title">
                          <h3><a href="#">We Love to design</a></h3>
                        </div>

                        <div class="gla_post_info">
                            August 10
                            <span class="slash-divider">/</span>
                            <a href="#">Harold Henry</a>
                            <span class="slash-divider">/</span>
                            <a href="#">Web-design</a>, <a href="#">Marketing</a>
                        </div>


                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                        </p>

                        <div class="gla_post_more clearfix">

                          <div class="pull-left">
                            <a href="#" class="btn">READ MORE</a>
                          </div>

                          <div class="pull-right" >
                            <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                            <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                            <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                              <i class="ti ti-sharethis"></i>
                            </a>
                            <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                              <li><a href="#"><i class="ti ti-facebook"></i></a>
                              </li>
                              <li><a href="#"><i class="ti ti-twitter"></i></a>
                              <li><a href="#"><i class="ti ti-instagram"></i></a>
                            </ul>
                          </div>

                        </div>
                    </div>
                    <!-- item end -->

                    <!-- Post Item -->
                    <div class="gla_post_item">

                        <div class="gla_post_img gla_team_slider_single">
                          <a href="#"><img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10094956883_a882196f8c_k.jpg')); ?>" alt=""></a>
                          <a href="#"><img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10095069494_01a19308a8_k.jpg')); ?>" alt=""></a>
                          <a href="#"><img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10095079386_b830b27b52_k.jpg')); ?>" alt=""></a>
                        </div>

                        <div class="gla_post_title">
                          <h3><a href="#">Post with Slider Gallery</a></h3>
                        </div>

                        <div class="gla_post_info">
                            August 10
                            <span class="slash-divider">/</span>
                            <a href="#">Harold Henry</a>
                            <span class="slash-divider">/</span>
                            <a href="#">Web-design</a>, <a href="#">Marketing</a>
                        </div>


                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                        </p>

                        <div class="gla_post_more clearfix">

                          <div class="pull-left">
                            <a href="#" class="btn">READ MORE</a>
                          </div>

                          <div class="pull-right" >
                            <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                            <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                            <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                              <i class="ti ti-sharethis"></i>
                            </a>
                            <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                              <li><a href="#"><i class="ti ti-facebook"></i></a>
                              </li>
                              <li><a href="#"><i class="ti ti-twitter"></i></a>
                              <li><a href="#"><i class="ti ti-instagram"></i></a>
                            </ul>
                          </div>

                        </div>
                    </div>
                    <!-- item end -->

                    <!-- Post Item -->
                    <div class="gla_post_item">

                        <div class="gla_post_img">
                          <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/239793212&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false" style="width: 100%; height: 166px; border: 0;"></iframe>
                        </div>

                        <div class="gla_post_title">
                          <h3><a href="#">Post with Soundcloud</a></h3>
                        </div>

                        <div class="gla_post_info">
                            August 10
                            <span class="slash-divider">/</span>
                            <a href="#">Harold Henry</a>
                            <span class="slash-divider">/</span>
                            <a href="#">Web-design</a>, <a href="#">Marketing</a>
                        </div>


                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                        </p>

                        <div class="gla_post_more clearfix">

                          <div class="pull-left">
                            <a href="#" class="btn">READ MORE</a>
                          </div>

                          <div class="pull-right" >
                            <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                            <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                            <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                              <i class="ti ti-sharethis"></i>
                            </a>
                            <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                              <li><a href="#"><i class="ti ti-facebook"></i></a>
                              </li>
                              <li><a href="#"><i class="ti ti-twitter"></i></a>
                              <li><a href="#"><i class="ti ti-instagram"></i></a>
                            </ul>
                          </div>

                        </div>
                    </div>
                    <!-- item end -->


                    <!-- Post Item -->
                    <div class="gla_post_item">

                        <div class="gla_post_img">
                            <iframe style="width: 100%; height: 600px; border: 0;" src="https://www.youtube.com/embed/uVju5--RqtY?rel=0&amp;controls=0&amp;showinfo=0" allowfullscreen></iframe>
                        </div>

                        <div class="gla_post_title">
                          <h3><a href="#">Post with Video</a></h3>
                        </div>

                        <div class="gla_post_info">
                            August 10
                            <span class="slash-divider">/</span>
                            <a href="#">Harold Henry</a>
                            <span class="slash-divider">/</span>
                            <a href="#">Web-design</a>, <a href="#">Marketing</a>
                        </div>


                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                        </p>

                        <div class="gla_post_more clearfix">

                          <div class="pull-left">
                            <a href="#" class="btn">READ MORE</a>
                          </div>

                          <div class="pull-right" >
                            <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                            <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                            <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                              <i class="ti ti-sharethis"></i>
                            </a>
                            <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                              <li><a href="#"><i class="ti ti-facebook"></i></a>
                              </li>
                              <li><a href="#"><i class="ti ti-twitter"></i></a>
                              <li><a href="#"><i class="ti ti-instagram"></i></a>
                            </ul>
                          </div>

                        </div>
                    </div>
                    <!-- item end -->

                    <!-- Post Item -->
                    <div class="gla_post_item">

                        <div class="gla_post_img">
                          <a href="images/wedding/andy_jeska/10095086876_adc6b57d6e_k.jpg')}}" class="lightbox">
                              <img src="<?php echo e(asset('assets/images/wedding/andy_jeska/10095086876_adc6b57d6e_k.jpg')); ?>" alt="">
                          </a>
                        </div>

                        <div class="gla_post_title">
                          <h3><a href="#">Post with Lighbox</a></h3>
                        </div>

                        <div class="gla_post_info">
                            August 10
                            <span class="slash-divider">/</span>
                            <a href="#">Harold Henry</a>
                            <span class="slash-divider">/</span>
                            <a href="#">Web-design</a>, <a href="#">Marketing</a>
                        </div>


                        <p>
                          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, nostrum, cumque culpa provident aliquam commodi assumenda laudantium magnam illo nostrum. Donec nibh sapien, molestie quis elementum et, dim non atino ipsum.
                        </p>

                        <div class="gla_post_more clearfix">

                          <div class="pull-left">
                            <a href="#" class="btn">READ MORE</a>
                          </div>

                          <div class="pull-right" >
                            <a href="#" class="gla_post_more_link"><i class="ti ti-comment"></i><span>14</span></a>
                            <a href="#" class="gla_post_more_link"><i class="ti ti-heart"></i><span>154</span></a>
                            <a href="#" class="dropdown-toggle gla_post_more_link" data-toggle="dropdown" aria-expanded="false" >
                              <i class="ti ti-sharethis"></i>
                            </a>
                            <ul class="gla_post_more_social_menu dropdown-menu dropdown-menu-right" role="menu">
                              <li><a href="#"><i class="ti ti-facebook"></i></a>
                              </li>
                              <li><a href="#"><i class="ti ti-twitter"></i></a>
                              <li><a href="#"><i class="ti ti-instagram"></i></a>
                            </ul>
                          </div>

                        </div>
                    </div>
                    <!-- item end -->

                    <!-- navigation -->
                    <nav class="gla_blog_pag">
                        <ul class="pagination">
                            <li><a href="#"><i class="ti ti-angle-left"></i></a></li>
                            <li class="active" ><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">5</a></li>
                            <li><a href="#"><i class="ti ti-angle-right"></i></a></li>
                        </ul>
                    </nav>
                    <!-- navigation end -->

                </div>
                <!-- col end -->

                <!--Sidebar-->
                <div class="col-md-3 col-md-push-1 hidden-xs hidden-sm">


                    <div class="widget">
                        <h6 class="title">About The Author</h6>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    </div>


                    <div class="widget">
                        <h6 class="title">Search Blog</h6>
                        <form>
                            <input class="form-control" type="text" placeholder="Enter Your Keywords" />
                        </form>
                    </div>


                    <div class="widget">
                        <h6 class="title">Blog Categories</h6>
                        <ul class="list-unstyled">
                            <li>
                                <a href="#">Business</a>
                            </li>
                            <li>
                                <a href="#">Creative</a>
                            </li>
                            <li>
                                <a href="#">Photography</a>
                            </li>
                            <li>
                                <a href="#">Freelance</a>
                            </li>
                        </ul>
                    </div>

                    <div class="widget">
                        <h6 class="title">Recent Posts</h6>
                        <ul class="list-unstyled recent-posts">
                            <li>
                                <a href="#">Ut enim ad minim veniam, quis nostrud</a>
                                <span class="date">November 10, 2016</span>
                            </li>
                            <li>
                                <a href="#">Excepteur sint occaecat</a>
                                <span class="date">November 08, 2016</span>
                            </li>
                            <li>
                                <a href="#">Duis aute irure dolor in reprehenderit in voluptate velit</a>
                                <span class="date">November 05, 2016</span>
                            </li>
                        </ul>
                    </div>


                    <div class="widget bg-secondary p24">
                        <h6 class="title">Subscribe Now</h6>
                        <p>
                            Subscribe to our newsletter.
                        </p>
                        <form>
                            <input type="text" class="form-control" name="email" placeholder="Email Address" />
                            <input type="submit" class="btn btn-default no-margin" value="Subscribe" />
                        </form>
                    </div>



                </div>
                <!--Sidebar End-->

            </div>



            </div>
            <!-- container end -->
        </section>
        <!-- section end -->



    </section>
    <!-- Content End -->


    <!-- Footer -->
    <section class="gla_section gla_image_bck gla_wht_txt" data-color="#292929">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4">
                    <h4>Contact Us</h4>
                    <p>
                    68 Cardamon Place, Melbourne Vic 3000<br>
                    Call us: 1.777.77.777<br>
                    <a href="mailto:hello@glanztheme.com">hello@glanztheme.com</a>
                    </p>

                    <form action="#">
                        <input placeholder="Enter Your Email" class="form-control form-opacity no-margin newsletter_input" type="email" required/>
                        <a href="#" class="btn">Subscribe</a>

                    </form>

                </div>
                <div class="col-md-4 col-sm-4">
                    <h4>Latest Posts</h4>
                    <ul class="list-unstyled">
                        <li><a href="#">Made with Love in Toronto</a></li>
                        <li><a href="#">Startup News & Emerging Tech</a></li>
                        <li><a href="#">Bitcoin Will Soon Rule The World</a></li>
                        <li><a href="#">Wearable Technology On The Rise</a></li>
                        <li><a href="#">Learn Web Design in 30 Days!</a></li>
                    </ul>
                </div>
                <div class="col-md-4 col-sm-4">
                    <h4>Latest Tweets</h4>
                    <div class="gla_twitter">
                        <a class="twitter-timeline" data-tweet-limit="1" data-theme="dark" data-link-color="#eee" data-chrome="noscrollbar noheader nofooter noborders transparent" href="https://twitter.com/envato">Tweets by Envato</a> <script async src="../../platform.twitter.com/widgets.js" charset="utf-8"></script>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="gla_block">
                        <p>© Glanz 2017. Copyright. Glanz Theme.</p>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Footer End -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>