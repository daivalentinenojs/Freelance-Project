<?php $__env->startSection('title','About Us'); ?>

<?php $__env->startSection('music'); ?>
<div class="gla_music_icon">
    <i class="ti ti-music"></i>
</div>
<div class="gla_music_icon_cont">
    <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/108238095&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" allow="autoplay"></iframe>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section" id="services-section">
<section class="ftco-counter img ftco-section ftco-no-pt ftco-no-pb" id="about-section">
    <div class="container">
        <div class="row no-gutters d-flex">
            <div class="col-md-6 col-lg-5 d-flex">
                <div class="img d-flex align-self-stretch align-items-center" style="background-image:url(<?php echo e(asset('assets/images/about.jpg)')); ?>;">
                </div>
            </div>
            <div class="col-md-6 col-lg-7 px-lg-5 py-md-5 bg-darken">
                <div class="py-md-5">
                    <div class="row justify-content-start pb-3">
                    <div class="col-md-12 heading-section ftco-animate p-5 p-lg-0">
                    <span class="subheading">Get in touch with us</span>
                    <h2 class="mb-4">Get Best Travel Deals</h2>
                    <p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
                    <p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p>
                    <p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
                    <p><a href="#" class="btn btn-primary py-3 px-4">Book now</a> <a href="#" class="btn btn-white py-3 px-4">Contact us</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>