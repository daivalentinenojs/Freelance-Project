<?php $__env->startSection('title','Facilities'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading">Facilities</span>
                <h2 class="mb-4">Travier Services</h2>
                <p>"Just having satisfied customers isn’t good enough anymore. <br> If you really want a booming
                    business, you have to create raving fans." ― Ken Blanchard</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-gliding"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Activities</h3>
                        <p>Decide where to go, and then how to go, where to stay, what kind of food or restaurant
                            available near the travel location, and what kind of transportation will be available in the
                            destination</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-world"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Travel Arrangement</h3>
                        <p>Provide list of information such as ticketing, stay place hotel or room, local event, and
                            place to go recommendation, and even photographer recommendation in a single itinerary
                            document.</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-tour-guide"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Private Guide</h3>
                        <p>Manage traveler planning without being afraid to lose track of time or missing important
                            place or attractive event around the designated destination. </p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-map-of-roads"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Location Manager</h3>
                        <p>Cut much of useless waste of time that usually has to use to plan travel. Recommend the
                            travel plan from how to go, the time traveling estimation will be provided, and stay place
                            recommendation.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-wallet"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Low Budget</h3>
                        <p>Low budget? No worries. We can adjust the itinerary based on your budget.</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-manager"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Travelers Love Us</h3>
                        <p>Our itineraries are curated to match with travelers' preferences.</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-calendar"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Create Your Own</h3>
                        <p>You can also create and manage your own itinerary. So, you never miss.</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-layers"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Find Locals</h3>
                        <p>Travier can recommend you nearby restaurants, tourist attractions, and so many more.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>