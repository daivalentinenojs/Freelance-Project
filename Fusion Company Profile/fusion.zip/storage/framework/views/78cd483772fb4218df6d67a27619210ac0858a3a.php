<?php $__env->startSection('title','Destination'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <span class="subheading" style="font-size:25px">Let's plan your unforgettable holiday!</span>
            </div>
        </div>

        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate" style="background-color:#fefaf8">
                <h2 class="mb-4">Finish Travier Payment</h2>
                <p>You have chosen Tokyo (Titanium Package) as a tourist destination</p>
            </div>
        </div>
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section"><br>
                <p><b>Price&emsp;&emsp;&emsp;&nbsp;: $800 / person</b></p>
                <p><b>People&emsp;&emsp;&nbsp;:5</b></p>
                <p><b>Total Price&nbsp;&nbsp;: $4,000</b></p><br>
                <p>Our payment is secured by <img style="height:30px; width=50px" src="<?php echo e(asset('assets/images/payment/0.jpg')); ?>" alt=""></p>
                
            </div>
        </div>
        <div class="row d-flex">
            <div class="col-md-6 col-lg-4 d-flex" style="height:300px">
                <div class="blog-entry">
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Paypal</span></h3>
                        <p>Get 5% discount and Point 200.</p>
                        <img style="height:70px; width=100px" src="<?php echo e(asset('assets/images/payment/1.jpg')); ?>" alt="">
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0"><a id="btn_paypal" class="btn btn-primary">Choose</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex" style="height:300px">
                <div class="blog-entry">
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>May Bank</span></h3>
                        <p>Get 15% discount and Point 150.</p>
                        <img style="height:70px; width=100px" src="<?php echo e(asset('assets/images/payment/2.jpg')); ?>" alt="">
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0"><a id="btn_may_bank" class="btn btn-primary">Choose</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex" style="height:300px">
                <div class="blog-entry">
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Post Office</span></h3>
                        <p>Get 2% discount and Point 50.</p>
                        <img style="height:70px; width=100px" src="<?php echo e(asset('assets/images/payment/3.jpg')); ?>" alt="">
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0"><a id="btn_post_office" class="btn btn-primary">Choose</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <form action="#" class="search-property-1">
            <div class="row">
                <div class="col-lg align-self-end">
                    <div class="form-group">
                        <div class="form-field">
                            <a href="<?php echo e(url('destination')); ?>"><input type="button" value="Finish"
                                    class="form-control btn btn-primary"></a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<section class="ftco-intro img" id="destination-section"
    style="background-image: url(<?php echo e(asset('assets/images/bg_3.jpg)')); ?>;">
    <div class="overlay"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 text-center">
                <h2>Choose the Perfect Destination</h2>
                <p>We can manage your dream building</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
$(function() {
    $(document).on('click', '#btn_paypal', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to pay using Paypal ?",
            function() {
                alertify.success('Paypal has been chosen');
            },
            function() {
                alertify.error('Paypal has been canceled');
            });
    });
});

$(function() {
    $(document).on('click', '#btn_may_bank', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to pay using May Bank ?",
            function() {
                alertify.success('May Bank has been chosen');
            },
            function() {
                alertify.error('May Bank has been canceled');
            });
    });
});

$(function() {
    $(document).on('click', '#btn_post_office', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to pay using Post Office ?",
            function() {
                alertify.success('Post Office has been chosen');
            },
            function() {
                alertify.error('Post Office has been canceled');
            });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>