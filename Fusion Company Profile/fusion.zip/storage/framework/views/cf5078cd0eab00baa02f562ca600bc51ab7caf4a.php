<?php $__env->startSection('title','Animated Flowers'); ?>

<?php $__env->startSection('music'); ?>
<div class="gla_music_icon">
    <i class="ti ti-music"></i>
</div>
<div class="gla_music_icon_cont">
    <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/108238095&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" allow="autoplay"></iframe>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_slider gla_image_bck  gla_wht_txt gla_fixed"  data-image="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/01.jpg')); ?>" data-stellar-background-ratio="0.8">
    <div class="gla_over" data-color="#9abab6" data-opacity="0.2"></div>
    <div class="container">
        <div class="gla_slide_txt gla_slide_center_middle text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/ourwedding_wh.gif')); ?>" data-top-bottom="@src:<?php echo e(asset('assets/images/animations/ourwedding_wh.gif')); ?>;" alt="" height="200"></p>
            <div class="gla_slide_midtitle" style="text-shadow: 0 0 3px black, 0 0 5px black;">Raymond & Debora <br><?php echo e($date['date']); ?></div>
        </div>
    </div>
    <a class="gla_scroll_down gla_go" href="#gla_content">
        <b></b>
        Scroll
    </a>
</div>

<section id="gla_content" class="gla_content">
    <section class="gla_section gla_image_bck" data-color="#f9fbf7">
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/flowers.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/flowers.gif')); ?>;" height="150" alt=""></p>
            <h2>Our Story</h2>
            <h3 class="gla_subtitle">The Love at the PT Eclectic Consulting</h3>
            <p>Raymond and Debora met for the first time five years ago, accidentally introduced by a colleague, Mrs. Yuni. At first, it was difficult for them to 
            understand each other, until finally, Raymond and Debora found common ground between them, namely watching anime and playing games. Finally, Raymond and Debora fell 
            in love and became a couple.</p>
        </div>
    </section>
    <section class="gla_section gla_image_bck gla_fixed gla_wht_txt" data-stellar-background-ratio="0.8" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/03.jpg')); ?>">
        <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/savethedate_wh.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/savethedate_wh.gif')); ?>;" height="150" alt=""></p>
            <h2><?php echo e($date['date']); ?></h2>
            <h3 class="gla_subtitle">Zhang Palace 3th Floor,<br>Raya Lontar No. 127, Surabaya, East Java, Indonesia</h3>
            <div class="gla_countdown" data-year="<?php echo e($date['year']); ?>" data-month="<?php echo e($date['month']); ?>" data-day="<?php echo e($date['day']); ?>"></div>
        </div>
    </section>
    <section class="gla_section">
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/flowers2.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/flowers2.gif')); ?>;" height="150" alt=""></p>
            <h2>Wedding Details</h2>
            <h3 class="gla_subtitle">When & Where</h3>
            <p>Our ceremony and reception will be held at the Zhang Palace. This European style building provides a luxurious western atmosphere.</p>
            <div class="gla_icon_boxes row text-left">
                <div class="col-md-4 col-sm-6">
                    <a href="" class="gla_news_block">
                        <span class="gla_news_img">
                            <span class="gla_over" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/venues/02.jpg')); ?>"></span>    
                        </span>
                        <span class="gla_news_title">Holy Matrimony</span>
                        <p><strong>At 12.00 PM<br>GKA Gloria Kota Satelit,</strong><br>HR. Muhammad No. 401 - 403,<br>Surabaya</p>
                    </a>
                    <a target="_blank" href="<?php echo e(url('https://goo.gl/maps/i9GkW6VK833AE7hM7')); ?>" class="btn">View Map</a>
                </div> 
                <div class="col-md-4 col-sm-6">
                    <a href="" class="gla_news_block">
                        <span class="gla_news_img">
                            <span class="gla_over" data-stellar-background-ratio="0.95" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/venues/01.jpg')); ?>"></span>    
                        </span>
                        <span class="gla_news_title">Wedding Reception</span>
                        <p><strong>At 06.00 PM<br>Zhang Palace 3rd Floor,</strong><br>Raya Lontar No. 127,<br>Surabaya</p>
                        <a target="_blank" href="<?php echo e(url('https://goo.gl/maps/TkyZAas9hpoRayPK9')); ?>" class="btn">View Map</a>
                    </a>                    
                </div> 
                <div class="col-md-4 col-sm-6">
                    <a href="#" class="gla_news_block">
                        <span class="gla_news_img">
                            <span class="gla_over" data-image="<?php echo e(asset('assets/images/dress/01.jpg')); ?>"></span>    
                        </span>
                        <span class="gla_news_title">Dress Code</span>
                        <p>Man<br><strong>Suit and Tie</strong><br>Woman<br><strong>Cocktail Dresses</strong></p>
                    </a>
                </div> 
            </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_fixed gla_wht_txt" data-stellar-background-ratio="0.4" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/06.jpg')); ?>">
        <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/just_wh.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/just_wh.gif')); ?>;" height="150" alt=""></p>
            <h3>You’re wonderful. Can you be wonderful forever?"</h3>
            <p class="gla_subtitle">— Brennan. A true master of words.</p>
        </div>
    </section>

    <section class="gla_section gla_image_bck">
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/flowers3.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/flowers3.gif')); ?>;" height="130" alt=""></p>
            <h2>The Day We Got Engaged</h2>
            <div class="button-group filter-button-group">
                <a data-filter="*">Show All</a>
                <a data-filter=".pre-wedding">Pre Wedding</a>
                <a data-filter=".ceremony">Ceremony</a>
            </div>
            <div class="gla_portfolio_no_padding grid">
                <div class="col-sm-4 gla_anim_box grid-item ceremony">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/11.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/11.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/01.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/01.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item ceremony">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/17.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/17.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/03.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/03.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/09.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/09.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/06.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/06.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/07.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/07.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/08.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/08.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/04.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/04.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/02.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/02.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item ceremony">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/15.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/15.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item pre-wedding">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/10.jpg')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/10.jpg')); ?>" alt="">
                        </a>
                    </div>
                </div>
             </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.8" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/10_1.jpg')); ?>">
        <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>
        <div class="container text-center">
            <h2>Registry</h2>
            <p>We’re lucky enough to have nearly everything we need for our home already. And since neither of us has ever been outside of Indonesia, we want our honeymoon to be extra special! If you want to help make it unforgettable, you can contribute using the link to the right. If you would like to give us something to update our home, we’ve compiled a short registry as well.</p>
        </div>
    </section>

    <section class="gla_section">
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/rsvp.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/rsvp.gif')); ?>;" height="180" alt=""></p>
            <div class="row">
                <div class="col-md-8 col-md-push-2">
                    <form>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Your name*</label>
                                <input type="text" name="name" required class="form-control form-opacity">
                            </div>
                            <div class="col-md-6">
                                <label>Your e-mail*</label>
                                <input type="text" name="email" required class="form-control form-opacity">
                            </div>
                            <div class="col-md-6">
                                <label>Will you attend?</label>

                                <input type="radio" name="attend" value="Yes, I will be there">
                                <span>Yes, I will be there</span><br>
                                <input type="radio" name="attend" value="Sorry, I can't come">
                                <span>Sorry, I can't come</span>
                            </div>
                            <div class="col-md-6">
                                <label>Meal preference</label>
                                <select name="meal" class="form-control form-opacity">
                                    <option value="i eat anything">I eat anything</option>
                                    <option value="Beef">Beef</option>
                                    <option value="Chicken">Chicken</option>
                                    <option value="Vegetarian">Vegetarian</option>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label>Greeting</label>
                                <textarea name="message" class="form-control form-opacity"></textarea>
                            </div>
                            <div class="col-md-12">
                                <button class="btn submit">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_fixed gla_wht_txt" data-stellar-background-ratio="0.8" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311002-raymond-debora/photos/07_1.jpg')); ?>">
        <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/thnyou_wh.gif')); ?>" alt="" height="200" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/thnyou_wh.gif')); ?>;"></p>
        </div>
    </section>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>