<?php $__env->startSection('title','About Us'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section" id="services-section">
<section class="ftco-counter img ftco-section ftco-no-pt ftco-no-pb" id="about-section">
    <div class="container">
        <div class="row no-gutters d-flex">
            <div class="col-md-6 col-lg-5 d-flex">
                <div class="img d-flex align-self-stretch align-items-center" style="background-image:url(<?php echo e(asset('assets/images/aboutus/travier.png)')); ?>; background-size: 90% 80%;">
                </div>
            </div>
            <div class="col-md-6 col-lg-7 px-lg-5 py-md-5 bg-darken">
                <div class="py-md-5">
                    <div class="row justify-content-start pb-3">
                    <div class="col-md-12 heading-section ftco-animate p-5 p-lg-0">
                    <span class="subheading">Get in Touch with Travier</span>
                    <h2 class="mb-4">Travier - Get Best Travel Deals</h2>
                    <p>Travier was found in August 2019 and based in Taipei, Taiwan. Travier is the first startup made by Engineering Experience.</p>
                    <p>Travier introduces a trusted web and mobile platform for travelers can list, discover, and create a perfect itinerary. Travier may help travelers to reach a world-wide from their handphone. Travier also give the best place, price, and promotion as your holiday. Travier is the simplest way for travelers to make their travel dreams come true.</p>
                    <a href="<?php echo e(url('/contact-us')); ?>" class="btn btn-white py-3 px-4">Contact us</a></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row no-gutters d-flex">
            <div class="col-md-6 col-lg-5 d-flex">
                <div class="img d-flex align-self-stretch align-items-center" style="background-image:url(<?php echo e(asset('assets/images/aboutus/1.jpg)')); ?>;">
                </div>
            </div>
            <div class="col-md-6 col-lg-7 px-lg-5 py-md-5 bg-darken">
                <div class="py-md-5">
                    <div class="row justify-content-start pb-3">
                    <div class="col-md-12 heading-section ftco-animate p-5 p-lg-0">
                    <span class="subheading">Chief Executive Officer</span>
                    <h2 class="mb-4">Jeff L Gaol</h2>
                    <p style="text-align:justify;">My name is Jeff L Gaol. I was born in Malang, Indonesia. I speak English, a little French, Javanese, Bahasa, Malay, and now a little bit of Mandarin.</p>
                    <p style="text-align:justify;">I am an active photographer, traveler, and coder. Cliffs, beaches, hills, and waterfalls are scenic spots that I love to visit wherever I go on vacation. These hobbies already inspire me to initiate a startup company to make travelers live easier.</p>
                    <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                        <li class="ftco-animate"><a href="<?php echo e(url('https://www.facebook.com/jefflgaolnetwork')); ?>" target="_blank"><span class="icon-facebook"></span></a></li>
                        <li class="ftco-animate"><a href="<?php echo e(url('https://www.instagram.com/jefflgaol')); ?>" target="_blank"><span class="icon-instagram"></span></a></li>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row no-gutters d-flex">
            <div class="col-md-6 col-lg-5 d-flex">
                <div class="img d-flex align-self-stretch align-items-center" style="background-image:url(<?php echo e(asset('assets/images/aboutus/2.jpg)')); ?>;">
                </div>
            </div>
            <div class="col-md-6 col-lg-7 px-lg-5 py-md-5 bg-darken">
                <div class="py-md-5">
                    <div class="row justify-content-start pb-3">
                    <div class="col-md-12 heading-section ftco-animate p-5 p-lg-0">
                    <span class="subheading">Chief Financial Officer</span>
                    <h2 class="mb-4">Ferdyan Dannes Krisandika </h2>
                    <p style="text-align:justify;">My name is Ferdyan Dannes Krisandika. I was born on August 29, 1996, in Surabaya.</p>
                    <p style="text-align:justify;">I enjoyed study electrical engineering when on my third study year. My concern study is about industrial electronics field. In that field, I study a lot of things that related to the machinery industries, but there is one thing that I interest in, image processing. I see that by using image processing any works seems easier to do and more efficient, then I focused on image and I finished my undergraduate final project with image processing topics.</p>
                    <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                        <li class="ftco-animate"><a href="<?php echo e(url('https://www.facebook.com/ferdyan.dannes')); ?>" target="_blank"><span class="icon-facebook"></span></a></li>
                        <li class="ftco-animate"><a href="<?php echo e(url('https://www.instagram.com/ferdyandannes')); ?>" target="_blank"><span class="icon-instagram"></span></a></li>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row no-gutters d-flex">
            <div class="col-md-6 col-lg-5 d-flex">
                <div class="img d-flex align-self-stretch align-items-center" style="background-image:url(<?php echo e(asset('assets/images/aboutus/3.jpg)')); ?>;">
                </div>
            </div>
            <div class="col-md-6 col-lg-7 px-lg-5 py-md-5 bg-darken">
                <div class="py-md-5">
                    <div class="row justify-content-start pb-3">
                    <div class="col-md-12 heading-section ftco-animate p-5 p-lg-0">
                    <span class="subheading">Chief Technology Officer</span>
                    <h2 class="mb-4">Daivalentineno Janitra Salim</h2>
                    <p style="text-align:justify;">My name is Daivalentineno Janitra Salim. I graduated from Faculty of Engineering, majoring in Informatics Engineering, University of Surabaya, Indonesia with GPA 4.00 out of 4.00. I learned many programming language, such as desktop application (C++, C#, and Java), Web Application (HTML, CSS, PHP, JavaScript, Ajax, Laravel, JSON), Mobile Application (Android), Game Application (Unity, Flash), Database (MySQL), SAP S/4 HANA (ABAP), and Python. I also learn about language, I can talk using Indonesian as my mother language, English as my second language, and Mandarin.</p>
                    <p style="text-align:justify;">I worked as a SAP IT Consultant at PT Eclectic Consulting. I started my career as ABAPer. ABAPer is a programmer in SAP software. They are called ABAPer because SAP software uses ABAP language as primary programming language.</p>
                    <p style="text-align:justify;">I have reached many awards from many categories, such as English competition, Talent competition, Informatics competition, and Mathematics competition. My best award is 50th Champion of ACM ICPC Singapore World Challenge at National University of Singapore (2015).</p>
                    <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                        <li class="ftco-animate"><a href="<?php echo e(url('https://www.facebook.com/Daiva24')); ?>" target="_blank"><span class="icon-facebook"></span></a></li>
                        <li class="ftco-animate"><a href="<?php echo e(url('https://www.instagram.com/daivalentineno24')); ?>" target="_blank"><span class="icon-instagram"></span></a></li>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row no-gutters d-flex">
            <div class="col-md-6 col-lg-5 d-flex">
                <div class="img d-flex align-self-stretch align-items-center" style="background-image:url(<?php echo e(asset('assets/images/aboutus/4.jpg)')); ?>;">
                </div>
            </div>
            <div class="col-md-6 col-lg-7 px-lg-5 py-md-5 bg-darken">
                <div class="py-md-5">
                    <div class="row justify-content-start pb-3">
                    <div class="col-md-12 heading-section ftco-animate p-5 p-lg-0">
                    <span class="subheading">Chief Marketing Officer</span>
                    <h2 class="mb-4">Batara Parada Siahaan</h2>
                    <p style="text-align:justify;">Graduate student from NTUST Information Management, and Master of Science in Management ITB, have good experience in computer programming languages and project management tools. </p>
                    <p style="text-align:justify;">I have experience on some company System Information project, managing the project of government and private companies for System Information Development. Coaching the regional ACM ICPC members, publishing some papers in international journals and conferences.</p>
                    <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                        <li class="ftco-animate"><a href="<?php echo e(url('https://www.facebook.com/parada.batara')); ?>" target="_blank"><span class="icon-facebook"></span></a></li>
                        <li class="ftco-animate"><a href="<?php echo e(url('https://www.instagram.com/bataraparada')); ?>" target="_blank"><span class="icon-instagram"></span></a></li>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>