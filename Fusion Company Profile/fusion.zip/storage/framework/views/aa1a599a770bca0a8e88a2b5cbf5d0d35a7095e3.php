<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>
<!-- <section id="home-section" class="hero">
    <img src="<?php echo e(asset('assets/images/blob-shape-3.svg')); ?>" class="svg-blob" alt="Colorlib Free Template">
    <div class="home-slider owl-carousel">
        <div class="slider-item">
            <div class="overlay"></div>
            <div class="container-fluid p-0">
                <div class="row d-md-flex no-gutters slider-text align-items-center justify-content-end"
                    data-scrollax-parent="true">
                    <div class="one-third order-md-last">
                        <div class="img" style="background-image:url(<?php echo e(asset('assets/images/bg_1.jpg)')); ?>;">
                            <div class="overlay"></div>
                        </div>
                        <div class="bg-primary">
                            <div class="vr"><span class="pl-3 py-4"
                                    style="background-image: url(<?php echo e(asset('assets/images/bg_1-1.jpg)')); ?>">Greece</span>
                            </div>
                        </div>
                    </div>
                    <div class="one-forth d-flex align-items-center ftco-animate"
                        data-scrollax=" properties: { translateY: '70%' }">
                        <div class="text">
                            <span class="subheading pl-5">Discover Greece</span>
                            <h1 class="mb-4 mt-3">Explore Your Travel Destinations like never before</h1>
                            <p>Explore the largest city of Greece from famous museums around the world to a nightlife
                                and tradition you have never experienced before.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="slider-item">
            <div class="overlay"></div>
            <div class="container-fluid p-0">
                <div class="row d-flex no-gutters slider-text align-items-center justify-content-end"
                    data-scrollax-parent="true">
                    <div class="one-third order-md-last">
                        <div class="img" style="background-image:url(<?php echo e(asset('assets/images/bg_2.jpg)')); ?>;">
                            <div class="overlay"></div>
                        </div>
                        <div class="vr"><span class="pl-3 py-4"
                                style="background-image: url(<?php echo e(asset('assets/images/bg_2-2.jpg)')); ?>;">Africa</span>
                        </div>
                    </div>
                    <div class="one-forth d-flex align-items-center ftco-animate"
                        data-scrollax=" properties: { translateY: '70%' }">
                        <div class="text">
                            <span class="subheading pl-5">Discover Africa</span>
                            <h1 class="mb-4 mt-3">Never Stop Exploring</span></h1>
                            <p>Explore the secrets of the Africa peninsula and get to know more about the Olympic games,
                                the countless ancient sites, natural beauty,Sparta of the famous 300 and extreme sports
                                by exploring Greece through the ages.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->
<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <iframe src="https://www.youtube.com/embed/cBk15K5C_2Y" width="100%" height="500" frameborder="0"
                allowfullscreen></iframe>
        </div>
    </div>
</section>

<section class="ftco-section ftco-services-2" id="services-section" style="margin-top:-50px;">
    <div class="container">
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <span class="subheading" style="font-size:25px">Let's plan your unforgettable holiday!</span>
                <h2 class="mb-4">Where do you want to go?</h2>
                <p>"Wherever you go, go with all your heart." – Confucius</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="search-wrap-1 ftco-animate p-4">
                    <form action="#" class="search-property-1">
                        <div class="row">
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">From</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-search"></span></div>
                                        <select name="from" id="" class="form-control">
                                            <option value="Beijing, China">Beijing, China</option>
                                            <option value="England, United Kingdom">England, United Kingdom</option>
                                            <option value="Jakarta, Indonesia">Jakarta, Indonesia</option>
                                            <option value="Paris, France">Paris, France</option>
                                            <option value="Roma, Italia">Roma, Italia</option>
                                            <option value="Seoul, South Korea">Seoul, South Korea</option>
                                            <option value="Taipei, Taiwan">Taipei, Taiwan</option>
                                            <option value="Tokyo, Japan">Tokyo, Japan</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Destination</label>
                                    <select name="destination" id="" class="form-control">
                                        <option value="Beijing, China">Beijing, China</option>
                                        <option value="England, United Kingdom">England, United Kingdom</option>
                                        <option value="Jakarta, Indonesia">Jakarta, Indonesia</option>
                                        <option value="Paris, France">Paris, France</option>
                                        <option value="Roma, Italia">Roma, Italia</option>
                                        <option value="Seoul, South Korea">Seoul, South Korea</option>
                                        <option value="Taipei, Taiwan">Taipei, Taiwan</option>
                                        <option value="Tokyo, Japan">Tokyo, Japan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Check-in date</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-calendar"></span></div>
                                        <input name="check_in" type="date" class="form-control checkin_date"
                                            placeholder="Check In Date">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Check-out date</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-calendar"></span></div>
                                        <input name="check_out" type="date" class="form-control checkout_date"
                                            placeholder="Check Out Date">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">People</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-search"></span></div>
                                        <input name="people" type="number" class="form-control"
                                            placeholder="# of People">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-self-end">
                                <div class="form-group">
                                    <div class="form-field">
                                        <a href=""><input type="submit" value="Search"
                                                class="form-control btn btn-primary"></a>
                                    </div>
                                </div>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-lg align-self-end">
                                <div class="form-group">
                                    <div class="form-field">
                                        <a href="<?php echo e(url('/destination/itineraries')); ?>"><input type="button"
                                                value="Add Destination" class="form-control btn btn-success"></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-self-end">
                                <div class="form-group">
                                    <div class="form-field">
                                        <a href=""><input type="submit" value="Next"
                                                class="form-control btn btn-success"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <h2 class="mb-4">Recommended Places</h2>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/1.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1300</h4>
                            <span>Tokyo Tower</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/1.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/2.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1300</h4>
                            <span>Great Wall of China</span>
                            <h3><a href="">Beijing, China</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/2.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/3.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$3700</h4>
                            <span>Eifell Tower</span>
                            <h3><a href="">Paris, France</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/3.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/4.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$3300</h4>
                            <span>Pissa Tower</span>
                            <h3><a href="">Roma, Italia</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/4.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/5.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1200</h4>
                            <span>Taipei 101</span>
                            <h3><a href="">Taipei, Taiwan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/5.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/6.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1700</h4>
                            <span>Lumpini Park</span>
                            <h3><a href="">Bangkok, Thailand</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/6.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/7.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$3000</h4>
                            <span>Big Bang Tower</span>
                            <h3><a href="">England, United Kingdom</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/7.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/8.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1800</h4>
                            <span>Seoul Tower</span>
                            <h3><a href="">Seoul, South Korea</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/8.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/9.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1100</h4>
                            <span>Kuta Beach</span>
                            <h3><a href="">Bali, Indonesia</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/9.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading">Facilities</span>
                <h2 class="mb-4">Travier Services</h2>
                <p>"Just having satisfied customers isn’t good enough anymore. <br> If you really want a booming
                    business, you have to create raving fans." ― Ken Blanchard</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-gliding"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Activities</h3>
                        <p>Decide where to go, and then how to go, where to stay, what kind of food or restaurant
                            available near the travel location, and what kind of transportation will be available in the
                            destination</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-world"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Travel Arrangement</h3>
                        <p>Provide list of information such as ticketing, stay place hotel or room, local event, and
                            place to go recommendation, and even photographer recommendation in a single itinerary
                            document.</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-tour-guide"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Private Guide</h3>
                        <p>Manage traveler planning without being afraid to lose track of time or missing important
                            place or attractive event around the designated destination. </p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-map-of-roads"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Location Manager</h3>
                        <p>Cut much of useless waste of time that usually has to use to plan travel. Recommend the
                            travel plan from how to go, the time traveling estimation will be provided, and stay place
                            recommendation.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-wallet"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Low Budget</h3>
                        <p>Low budget? No worries. We can adjust the itinerary based on your budget.</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-manager"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Travelers Love Us</h3>
                        <p>Our itineraries are curated to match with travelers' preferences.</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-calendar"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Create Your Own</h3>
                        <p>You can also create and manage your own itinerary. So, you never miss.</p>
                    </div>
                </div>
            </div>
            <div class="col-md d-flex align-self-stretch ftco-animate">
                <div class="media block-6 services text-center d-block">
                    <div class="icon justify-content-center align-items-center d-flex"><span
                            class="flaticon-layers"></span></div>
                    <div class="media-body">
                        <h3 class="heading mb-3">Find Locals</h3>
                        <p>Travier can recommend you nearby restaurants, tourist attractions, and so many more.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading" style="font-size:25px;">Do you like to stay in luxury place? These are our
                    recommendations</span>
                <h2 class="mb-4">Find Nearest Hotel</h2>
                <p>"All good hotels tend to lead people to do things they wouldn't necessarily do at home." - Andre
                    Balazs</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <div class="vr"><span>Sale</span></div>
                        <a href=""><img src="<?php echo e(asset('assets/images/hotel/1.jpg')); ?>" class="img-fluid"
                                alt="Colorlib Template"></a>
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="old-price mr-2">$800</span>$700</h4>
                        <span>3 nights</span>
                        <h3><a href="">Hotel Higashi Ikebukuro</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/hotel/1.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <a href=""><img src="<?php echo e(asset('assets/images/hotel/2.jpg')); ?>" class="img-fluid"
                                alt="Colorlib Template"></a>
                    </div>
                    <div class="text">
                        <h4 class="price">$300</h4>
                        <span>1 nights</span>
                        <h3><a href="">The Peninsula Tokyo</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/hotel/2.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <a href=""><img src="<?php echo e(asset('assets/images/hotel/3.jpg')); ?>" class="img-fluid"
                                alt="Colorlib Template"></a>
                    </div>
                    <div class="text">
                        <h4 class="price">$500</h4>
                        <span>2 nights</span>
                        <h3><a href="">InterContinental Tokyo Bay</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/hotel/3.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
        </div>
        <div class="row justify-content-center pb-5 pt-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading" style="font-size:25px;">Do you need a cheap living place? These are for
                    you.</span>
                <h2 class="mb-4">Best Rooms Offer</h2>
                <p>"Smile. It instantly lifts the face, and it just lights up the room." - Christie Brinkley</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 room-wrap">
                <div class="row">
                    <div class="col-md-7 d-flex ftco-animate">
                        <div class="img align-self-stretch"
                            style="background-image: url(<?php echo e(asset('assets/images/room/1.jpg)')); ?>;"></div>
                    </div>
                    <div class="col-md-5 ftco-animate">
                        <div class="text py-5">
                            <h3><a href="">Hotel Alpin Spa Tuxerhof</a></h3>
                            <p class="pos">from <span class="price">$120.00</span> / night</p>
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div><br>
                            <p>Our Alpine Spa is a haven for individuals and especially for couples. We have several
                                offers for partner treatments. Enjoy a snow crystal peeling on the hot stone, a
                                melissa-lemon bath in the romantic tub or an anti-stress massage together with your
                                partner and rest in the soft waterbeds. Enjoy our convivial atmosphere, the spacious and
                                comfortable accommodation in our new suites and our excellent cuisine.</p>
                            <p><a href="" class="btn btn-secondary">Details</a> <a href="" class="btn btn-primary">Book
                                    now</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                <div class="row">
                    <div class="col-md-3 ftco-animate">
                        <a href="" class="d-flex thumb">
                            <div class="img align-self-stretch"
                                style="background-image: url(<?php echo e(asset('assets/images/room/2.jpg)')); ?>;"></div>
                            <div class="text pl-3 py-3">
                                <h3>Ikosien Oceania</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 ftco-animate">
                        <a href="" class="d-flex thumb">
                            <div class="img align-self-stretch"
                                style="background-image: url(<?php echo e(asset('assets/images/room/3.jpg)')); ?>;"></div>
                            <div class="text pl-3 py-3">
                                <h3>Standard Room</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 ftco-animate">
                        <a href="" class="d-flex thumb">
                            <div class="img align-self-stretch"
                                style="background-image: url(<?php echo e(asset('assets/images/room/4.jpg)')); ?>;"></div>
                            <div class="text pl-3 py-3">
                                <h3>Classic Suites Family Room</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 ftco-animate">
                        <a href="" class="d-flex thumb">
                            <div class="img align-self-stretch"
                                style="background-image: url(<?php echo e(asset('assets/images/room/5.jpg)')); ?>;"></div>
                            <div class="text pl-3 py-3">
                                <h3>Clifftop Resort</h3>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section" id="restaurant-section">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading" style="font-size:25px;">Are you hungry? Travier has some recommendation
                    restaurant for you.</span>
                <h2 class="mb-4">Nearest Resturant</h2>
                <p>"Life is like a restaurant; you can have anything you want as long as you are willing to pay the
                    price" - Moffat Machingura</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/restaurant/1.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="mr-2">menu start at</span>$45.00</h4>
                        <span>Tokyo, Jepang</span>
                        <h3><a href="project.html">Steak House</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                        <p><a href="" class="btn btn-secondary">Details</a> <a href="" class="btn btn-primary">Book
                                now</a></p>
                    </div>
                    <a href="<?php echo e(asset('assets/images/restaurant/1.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/restaurant/2.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="mr-2">menu start at</span>$20.00</h4>
                        <span>Tokyo, Jepang</span>
                        <h3><a href="project.html">Halal Indonesian Food</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                        <p><a href="" class="btn btn-secondary">Details</a> <a href="" class="btn btn-primary">Book
                                now</a></p>
                    </div>
                    <a href="<?php echo e(asset('assets/images/restaurant/2.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/restaurant/3.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="mr-2">menu start at</span>$14.00</h4>
                        <span>Tokyo, Jepang</span>
                        <h3><a href="project.html">Cake and Bakery</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                        <p><a href="" class="btn btn-secondary">Details</a> <a href="" class="btn btn-primary">Book
                                now</a></p>
                    </div>
                    <a href="<?php echo e(asset('assets/images/restaurant/3.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="ftco-section testimony-section">
    <img src="<?php echo e(asset('assets/images/blob-shape-2.svg')); ?>" class="svg-blob" alt="Colorlib Free Template">
    <img src="<?php echo e(asset('assets/images/blob-shape-2.svg')); ?>" class="svg-blob-2" alt="Colorlib Free Template">
    <div class="container">
        <div class="row justify-content-center pb-3">
            <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
                <span class="subheading">Our Testimonials</span>
                <h2 class="mb-4">What Traveler Says</h2>
            </div>
        </div>
        <div class="row ftco-animate justify-content-center">
            <div class="col-md-12">
                <div class="carousel-testimony owl-carousel ftco-owl">
                    <div class="item">
                        <div class="testimony-wrap text-center py-4 pb-5">
                            <div class="user-img"
                                style="background-image: url(<?php echo e(asset('assets/images/testimonials/1.jpg)')); ?>;">
                                <span class="quote d-flex align-items-center justify-content-center">
                                    <i class="icon-quote-left"></i>
                                </span>
                            </div>
                            <div class="text px-4 pb-5">
                                <p class="mb-4">Traveling using a traveler helped my trip, all can be done in just one
                                    application starting from preparing the itinerary until finished traveling.</p>
                                <p class="name">Stefanie Amelia</p>
                                <span class="position">Architect</span>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimony-wrap text-center py-4 pb-5">
                            <div class="user-img"
                                style="background-image: url(<?php echo e(asset('assets/images/testimonials/2.jpg)')); ?>;">
                                <span class="quote d-flex align-items-center justify-content-center">
                                    <i class="icon-quote-left"></i>
                                </span>
                            </div>
                            <div class="text px-4 pb-5">
                                <p class="mb-4">In the beginning, I thought travier was just an application to book
                                    plane or hotel tickets, but after I used it for traveling, travier was more than
                                    what I expected.</p>
                                <p class="name">Della Budiono</p>
                                <span class="position">Full Stack Programmer</span>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimony-wrap text-center py-4 pb-5">
                            <div class="user-img"
                                style="background-image: url(<?php echo e(asset('assets/images/testimonials/3.jpg)')); ?>;">
                                <span class="quote d-flex align-items-center justify-content-center">
                                    <i class="icon-quote-left"></i>
                                </span>
                            </div>
                            <div class="text px-4 pb-5">
                                <p class="mb-4">With travier, I can save a lot of money because I can choose which
                                    itinerary that match with my budget also I can save time because Travier gives me
                                    every detail.</p>
                                <p class="name">Wahyu Tri Anggoro</p>
                                <span class="position">Database Analyst</span>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimony-wrap text-center py-4 pb-5">
                            <div class="user-img"
                                style="background-image: url(<?php echo e(asset('assets/images/testimonials/4.jpg)')); ?>;">
                                <span class="quote d-flex align-items-center justify-content-center">
                                    <i class="icon-quote-left"></i>
                                </span>
                            </div>
                            <div class="text px-4 pb-5">
                                <p class="mb-4">Do you want your holiday dreams to be achieved? Use travier.</p>
                                <p class="name">Richardo Tiono</p>
                                <span class="position">Student</span>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimony-wrap text-center py-4 pb-5">
                            <div class="user-img"
                                style="background-image: url(<?php echo e(asset('assets/images/testimonials/5.jpg)')); ?>;">
                                <span class="quote d-flex align-items-center justify-content-center">
                                    <i class="icon-quote-left"></i>
                                </span>
                            </div>
                            <div class="text px-4 pb-5">
                                <p class="mb-4">I recommend all travelers to use travier, this application is perfect
                                    for scheduling your vacation.</p>
                                <p class="name">Ian Dharmawan</p>
                                <span class="position">Civil Engineer</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>










<section class="ftco-gallery">
    <div class="container-fluid px-0">
        <div class="row no-gutters">
            <div class="col-md-4 col-lg-2 ftco-animate">
                <a href="<?php echo e(asset('assets/images/gallery/1.jpg')); ?>"
                    class="gallery image-popup img d-flex align-items-center"
                    style="background-image: url(<?php echo e(asset('assets/images/gallery/1.jpg)')); ?>;">
                    <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-2 ftco-animate">
                <a href="<?php echo e(asset('assets/images/gallery/2.jpg')); ?>"
                    class="gallery image-popup img d-flex align-items-center"
                    style="background-image: url(<?php echo e(asset('assets/images/gallery/2.jpg)')); ?>;">
                    <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-2 ftco-animate">
                <a href="<?php echo e(asset('assets/images/gallery/3.jpg')); ?>"
                    class="gallery image-popup img d-flex align-items-center"
                    style="background-image: url(<?php echo e(asset('assets/images/gallery/3.jpg)')); ?>;">
                    <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-2 ftco-animate">
                <a href="<?php echo e(asset('assets/images/gallery/4.jpg')); ?>"
                    class="gallery image-popup img d-flex align-items-center"
                    style="background-image: url(<?php echo e(asset('assets/images/gallery/4.jpg)')); ?>;">
                    <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-2 ftco-animate">
                <a href="<?php echo e(asset('assets/images/gallery/5.jpg')); ?>"
                    class="gallery image-popup img d-flex align-items-center"
                    style="background-image: url(<?php echo e(asset('assets/images/gallery/5.jpg)')); ?>;">
                    <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-lg-2 ftco-animate">
                <a href="<?php echo e(asset('assets/images/gallery/6.jpg')); ?>"
                    class="gallery image-popup img d-flex align-items-center"
                    style="background-image: url(<?php echo e(asset('assets/images/gallery/6.jpg)')); ?>;">
                    <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>