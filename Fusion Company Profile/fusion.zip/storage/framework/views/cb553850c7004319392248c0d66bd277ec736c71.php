<?php $__env->startSection('title','Master Data User'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page" id="gla_page">

    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>

    <!-- Header -->
    <header>

        <nav class="gla_light_nav gla_transp_nav">
            <div class="container">

                <div class="gla_logo_container clearfix">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="gla_logo_rev">
                    <div class="gla_logo_txt">
                        <!-- Logo -->
                        <a href="" class="gla_logo">3Vite Master Data</a>

                        <!-- Text Logo -->
                        <div class="gla_logo_und">User Information</div>
                    </div>
                </div>

                <!-- Menu -->
                <div class="gla_main_menu gla_main_menu_mobile">

                    <div class="gla_main_menu_icon">
                        <i></i><i></i><i></i><i></i>
                        <b>Menu</b>
                        <b class="gla_main_menu_icon_b">Back</b>
                    </div>
                </div>

                <!-- Menu Content -->
                <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- menu content end -->

                <!-- Search Block -->
                <div class="gla_search_block">

                    <div class="gla_search_block_link gla_search_parent"><i class="ti ti-search"></i>
                        <ul>
                            <li>
                                <form>
                                    <input type="text" class="form-control" placeholder="Enter Your Keywords">
                                    <button type="submit" class="btn">
                                      <i class="ti ti-search"></i>
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Search Block End -->

                <!-- Top Menu -->
                <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- Top Menu End -->



            </div>
            <!-- container end -->
        </nav>

    </header>
    <!-- Header End -->


    <!-- PAGE TITLE SMALL -->
    <div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">

      <div class="container text-left">
        <div class="row">

          <div class="col-md-8">
            <h1 class="gla_h1_title">Master Data User</h1>
            <h3>This page contains about User information.</h3>
          </div>
        </div>
      </div>
    </div>

    <!-- Content -->
    <section id="gla_content" class="gla_content">

        <!-- section -->
        <section class="gla_section gla_image_bck" data-color="#fafafd">

          <div class="col-md-12 scCol" style="background:white;">
            <form class="form-horizontal" action="<?php echo e(url('mstoreuser')); ?>" method="POST" enctype="multipart/form-data">
              <div class="panel-body col-md-12">
                 <div class="form-group">
                    <button class="btn btn-success pull-right" data-toggle>Add New User</button>
                 </div>
              </div>
            </form>
          </div>

          <div class="col-md-12 scCol" style="background:white;">

                <div class="panel-body">

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">User Information Table</h3>
                        </div>
                        <div class="panel-body">
                            <table class="table" id="datatableuser">
                                <thead>
                                    <tr>
                                        <th style="text-align:center;">ID</th>
                                        <th style="text-align:center;">Nama</th>
                                        <th style="text-align:center;">Email</th>
                                        <th style="text-align:center;">Status</th>
                                        <th style="text-align:center;">Detail</th>
                                        <th style="text-align:center;">Ubah</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                   <tr>
                                     <th style="text-align:center;">ID</th>
                                     <th style="text-align:center;">Nama</th>
                                     <th style="text-align:center;">Email</th>
                                     <th style="text-align:center;">Status</th>
                                     <th style="text-align:center;">Detail</th>
                                     <th style="text-align:center;">Ubah</th>
                                   </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
        </div>

        </section>
        <!-- section end -->

    </section>
    <!-- Content End -->


    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Footer End -->

</div>
<!--
<div class="modal fade" id="mymodalcreate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
       <div class="modal-content">
           <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Tutup</span></button>
               <h4 class="modal-title" id="myModalLabel">Add New User</h4>
           </div>
           <div class="modal-body">
           <form class="form-horizontal" id="FormTambahAdmin" name="FormTambahAdmin" method="POST" enctype="multipart/form-data">
              <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
              <div class="modal-body">
                     <div class="panel-body">
                           <div class="col-md-12">
                             <div class="form-group">
                                   <label class="col-md-5 control-label">Nama Pengguna</label>
                                   <div class="col-md-4">
                                        <input type="text" name="Username" required class="form-control" value="" placeholder="Nama Pengguna" style="background:white; color:black;"/>
                                   </div>
                             </div>
                             <div class="form-group">
                                   <label class="col-md-5 control-label">Email</label>
                                   <div class="col-md-5">
                                        <input type="email" name="Email" required class="form-control" value="" placeholder="Email" style="background:white; color:black;"/>
                                   </div>
                             </div>
                             <div class="form-group">
                                   <label class="col-md-5 control-label">Kata Sandi</label>
                                   <div class="col-md-4">
                                        <input type="password" name="Password" required class="form-control" value="" placeholder="Kata Sandi" style="background:white; color:black;"/>
                                   </div>
                             </div>
                             <br><br>
                               <div class="form-group">
                                     <label class="col-md-5 control-label">Nama Admin</label>
                                     <div class="col-md-5">
                                          <input type="text" name="Nama" required class="form-control" value="" placeholder="Nama Admin" style="background:white; color:black;"/>
                                     </div>
                               </div>
                               <div class="form-group">
                                    <label class="col-md-5 control-label">Foto Admin</label>
                                    <div class="col-md-5">
                                          <input type="file" required id="FotoAdmin" name="FotoAdmin"/>
                                    </div>
                               </div>
                               <div class="form-group" style="text-align:center;">
                                      <input type="submit" id="BtnCreateAdmin" name="BtnCreateAdmin" value="Tambah" class="btn btn-success">
                               </div>
                           </div>
                      </div>
                </div>
              </form>
           </div>
           <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
           </div>
       </div>
   </div>
</div>

<div class="modal fade" id="mymodalview" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
       <div class="modal-content">
           <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Tutup</span></button>
               <h4 class="modal-title" id="myModalLabel">View User</h4>
           </div>
           <div class="modal-body-view" id="modal-body-view">

           </div>
           <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
           </div>
       </div>
   </div>
</div>

<div class="modal fade" id="mymodaledit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
       <div class="modal-content">
           <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Tutup</span></button>
               <h4 class="modal-title" id="myModalLabel">Edit User</h4>
           </div>
           <div class="modal-body-edit" id="modal-body-edit">

           </div>
           <div class="modal-footer">
               <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
           </div>
       </div>
   </div>
</div> -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('assets/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>

<script>
function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode == 46)
        return true;
    if ((charCode > 31 && (charCode < 48 || charCode > 57)))
        return false;
    return true;
}

$(document).ready(function() {
   // var dataTable = $('#datatableuser').DataTable( {
   //    "processing": true,
   //    "serverSide": true,
   //    "bDestroy": true,
   //    "scrollX": true,
   //    "ajax":{
   //       url : "majaxuser",
   //       type: "get",
   //    },
   //    "columns":[
   //       {"data":0,
   //          "render" : function ( data, type, full, meta ) {
   //             return '<div style="text-align:center">'+data+'</div>';
   //          }
   //       },
   //       {"data":1,
   //          "render" : function ( data, type, full, meta ) {
   //             return '<div style="text-align:left">'+data+'</div>';
   //          }
   //       },
   //       {"data":2,
   //          "render" : function ( data, type, full, meta ) {
   //             return '<div style="text-align:left">'+data+'</div>';
   //          }
   //       },
   //       {"data":3,
   //          "render" : function ( data, type, full, meta ) {
   //             return '<div style="text-align:center">'+data+'</div>';
   //          }
   //       },
   //       {"data":4,
   //          "render" : function ( data, type, full, meta ) {
   //             return '<div style="text-align:center"><a href="#" class="viewdatauser" data-id="'+data+'"><i class="fa fa-eye"></i></a></div>';
   //          }
   //       },
   //       {"data":5,
   //          "render" : function ( data, type, full, meta ) {
   //             return '<div style="text-align:center"><a href="#" class="editdatauser" data-id="'+data+'"><i class="fa fa-pencil"></i></a></div>';
   //          }
   //       }
   //       ],
   //    "order":[[0, 'asc']]
   // });
});

$(function(){
   $(document).on('click','.viewdatauser',function(e){
       e.preventDefault();
       $("#mymodalview").modal('show');
       $.post('modal/Admin/AdminModalView.blade.php',
           {ID:$(this).attr('data-id')},
           function(html){
               $("#modal-body-view").html(html);
           }
       );
   });
});

$(function(){
   $(document).on('click','.editdatauser',function(e){
       e.preventDefault();
       $("#mymodaledit").modal('show');
       $.post('modal/Admin/AdminModalEdit.blade.php',
           {ID:$(this).attr('data-id')},
           function(html){
               $("#modal-body-edit").html(html);
           }
       );
   });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>