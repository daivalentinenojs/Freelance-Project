<?php $__env->startSection('title','About Us'); ?>

<?php $__env->startSection('music'); ?>
<div class="gla_music_icon">
    <i class="ti ti-music"></i>
</div>
<div class="gla_music_icon_cont">
    <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/108238095&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" allow="autoplay"></iframe>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">
  <div class="container text-left">
    <div class="row">
      <div class="col-md-8">
        <h1 class="gla_h1_title">About Us</h1>
        <h4>Over years ago, people are so used to the idea of guestbook in every event. <br> Stands, queues, writes, and gifts. <br> What if we could do something better?</h4>
      </div>
    </div>
  </div>
</div>

<section id="gla_content" class="gla_content">
    <section class="gla_section gla_image_bck" data-color="#fafafd">
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/flower5.gif')); ?>" data-bottom-top="@src:assets/images/animations/flower5.gif; opacity:1" class="gla_animated_flower" height="150" alt=""></p>
            <h2>What we do</h2>
            <!-- <h3 class="gla_subtitle">What we do</h3> -->
            <h4>We create experiences that make inviting people and <br /> attending events become simpler and easier.</h4>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.4" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/03.JPEG')); ?>">
        <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>
        <div class="container text-left">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <h2>How it works</h2>
                    <!-- <h3 class="gla_subtitle">How it works</h3> -->
                    <h4>Creating and spreading the invitations right on your fingertips. <br /> <br /> Attending events without queuing to write the guest - book, but showing and scanning the barcode in the invitations.</h4>
                </div>
            </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_fixed" data-stellar-background-ratio="0.2" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/05.JPEG')); ?>">
        <div class="container">
            <div class="row gla_auto_height">
              <div class="col-md-6 gla_image_bck" data-color="#eee">
                  <div class="gla_simple_block">
                      <h2>Fransisca Alexandra Stefanie</h2>
                      <h3>Founder</h3>
                      <p style="text-align:justify;">The public face of 3Vite company, the best digital invitiation card, possesses a wealth of business ownership, 
                      technology, analytics, and ecomonic insight. She makes major corporate decisions, manages the overall operations and resources.</p>                   
                      <h4>Connect with me</h4> <br>
                      <div class="gla_footer_social">
                          <a target="blank" href="<?php echo e(url('https://www.facebook.com/alexavannie')); ?>"><i class="ti ti-facebook gla_icon_box"></i></a>
                          <a target="blank" href="<?php echo e(url('https://www.instagram.com/alexastefanie')); ?>"><i class="ti ti-instagram gla_icon_box"></i></a>
                          <a target="blank" href="<?php echo e(url('https://www.linkedin.com/in/alexastefanie/')); ?>"><i class="ti ti-linkedin gla_icon_box"></i></a>
                      </div>
                  </div>
              </div>
              <div class="col-md-6 gla_image_bck" data-image="<?php echo e(asset('assets/images/aboutus/alexa.jpg')); ?>">
              </div>
                <div class="col-md-6 col-md-push-6 gla_image_bck" data-color="#eee">
                    <div class="gla_simple_block">
                        <h2>Daivalentineno Janitra Salim</h2>
                        <h3>Co - Founder</h3>
                        <p style="text-align:justify;">Energetic chief operations officer with 2+ years of experience as a change agent, leader, and 
                        communicator in a tech company. He manages operations, marketing, production, and reorganizes sales teams to focus more on 
                        customer communication. He collaborates with the IT team to create a proprietary intra-departmental communications platform.</p>                   
                        <h4>Connect with me</h4> <br>
                        <div class="gla_footer_social">
                            <a target="blank" href="<?php echo e(url('https://www.facebook.com/Daiva24')); ?>"><i class="ti ti-facebook gla_icon_box"></i></a>
                            <a target="blank" href="<?php echo e(url('https://www.instagram.com/daivalentineno24')); ?>"><i class="ti ti-instagram gla_icon_box"></i></a>
                            <a target="blank" href="<?php echo e(url('https://github.com/daivalentinenojs')); ?>"><i class="ti ti-github gla_icon_box"></i></a>
                            <a target="blank" href="<?php echo e(url('https://www.linkedin.com/in/daivalentineno-janitra-salim-7b1317165/')); ?>"><i class="ti ti-linkedin gla_icon_box"></i></a>
                            <a target="blank" href="<?php echo e(url('http://daivalentinenojs.my.id/')); ?>"><i class="ti ti-google gla_icon_box"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-md-pull-6 gla_image_bck" data-image="<?php echo e(asset('assets/images/aboutus/daiva.jpg')); ?>">
                </div>
                <div class="col-md-6 gla_image_bck" data-color="#eee">
                    <div class="gla_simple_block">
                        <h2>Dian Yulius</h2>
                        <h3>Co - Founder</h3>
                        <p style="text-align:justify;">Highly regarded for more than 5 years of progressive experience developing, implementing and supporting complex
                        infrastructures and technical solutions.  Superior expertise with development methodologies, developer supervision and client relations. 
                        Out-of-the-box thinker who thrives in collaborative environments, working across business and technical teams to increase profits and reduce
                        costs through continuous improvements and strategic IT infrastructure planning.
                        <h4>Connect with me</h4> <br>
                        <div class="gla_footer_social">
                            <a href="<?php echo e(url('https://github.com/dianyulius')); ?>"><i class="ti ti-github gla_icon_box"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 gla_image_bck" data-image="<?php echo e(asset('assets/images/aboutus/yulius.jpg')); ?>">
                </div>
            </div>
        </div>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>