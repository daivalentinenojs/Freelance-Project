<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('includes.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php echo $__env->yieldPushContent('css'); ?>
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light site-navbar-target" id="ftco-navbar">
	    <div class="container">
          <?php echo $__env->make('includes.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    </div>
	  </nav>
	  
    <?php echo $__env->yieldContent('content'); ?>
    
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

  <?php echo $__env->make('includes.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldPushContent('script'); ?>
    
  </body>
</html>