<?php $__env->startSection('title','Destination'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <span class="subheading" style="font-size:25px">Let's plan your unforgettable holiday!</span>
                <h2 class="mb-4">Where do you want to go?</h2>
                <p>"Wherever you go, go with all your heart." – Confucius</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="search-wrap-1 ftco-animate p-4">
                    <form action="#" class="search-property-1">
                        <div class="row">
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">From</label>
                                    <label for="#">Taipei, Taiwan</label>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Destination</label>
                                    <label for="#">Tokyo, Japan</label>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Check-in date</label>
                                    <label for="#">12/21/2019</label>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Check-out date</label>
                                    <label for="#">12/27/2019</label>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">People</label><br>
                                    <label for="#">5</label>
                                </div>
                            </div>
                            <div class="col-lg align-self-end">
                                <div class="form-group">
                                    <div class="form-field">
                                    </div>
                                </div>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">From</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-search"></span></div>
                                        <select name="destination" id="" class="form-control">
                                            <option value="Beijing, China">Beijing, China</option>
                                            <option value="England, United Kingdom">England, United Kingdom</option>
                                            <option value="Jakarta, Indonesia">Jakarta, Indonesia</option>
                                            <option value="Paris, France">Paris, France</option>
                                            <option value="Roma, Italia">Roma, Italia</option>
                                            <option value="Seoul, South Korea">Seoul, South Korea</option>
                                            <option value="Taipei, Taiwan">Taipei, Taiwan</option>
                                            <option value="Tokyo, Japan">Tokyo, Japan</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Destination</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-search"></span></div>
                                        <select name="destination" id="" class="form-control">
                                            <option value="Beijing, China">Beijing, China</option>
                                            <option value="England, United Kingdom">England, United Kingdom</option>
                                            <option value="Jakarta, Indonesia">Jakarta, Indonesia</option>
                                            <option value="Paris, France">Paris, France</option>
                                            <option value="Roma, Italia">Roma, Italia</option>
                                            <option value="Seoul, South Korea">Seoul, South Korea</option>
                                            <option value="Taipei, Taiwan">Taipei, Taiwan</option>
                                            <option value="Tokyo, Japan">Tokyo, Japan</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Check-in date</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-calendar"></span></div>
                                        <input type="date" class="form-control checkin_date"
                                            placeholder="Check In Date">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">Check-out date</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-calendar"></span></div>
                                        <input type="date" class="form-control checkout_date"
                                            placeholder="Check Out Date">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-items-end">
                                <div class="form-group">
                                    <label for="#">People</label>
                                    <div class="form-field">
                                        <div class="icon"><span class="ion-ios-search"></span></div>
                                        <input type="number" class="form-control" placeholder="# of People">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-self-end">
                                <div class="form-group">
                                    <div class="form-field">
                                        <a href=""><input type="submit" value="Search"
                                                class="form-control btn btn-primary"></a>
                                    </div>
                                </div>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-lg align-self-end">
                                <div class="form-group">
                                    <div class="form-field">
                                        <a href=""><input type="button" value="Add Destination"
                                                class="form-control btn btn-success"></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg align-self-end">
                                <div class="form-group">
                                    <div class="form-field">
                                        <a href="<?php echo e(url('/destination/adjustment/1')); ?>"><input type="button" value="Next"
                                                class="form-control btn btn-success"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <h2 class="mb-4">Recommended Places</h2>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/1.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1300</h4>
                            <span>Tokyo Tower</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/1.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/2.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1300</h4>
                            <span>Great Wall of China</span>
                            <h3><a href="">Beijing, China</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/2.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/3.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$3700</h4>
                            <span>Eifell Tower</span>
                            <h3><a href="">Paris, France</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/3.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/4.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$3300</h4>
                            <span>Pissa Tower</span>
                            <h3><a href="">Roma, Italia</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/4.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/5.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1200</h4>
                            <span>Taipei 101</span>
                            <h3><a href="">Taipei, Taiwan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/5.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/6.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1700</h4>
                            <span>Lumpini Park</span>
                            <h3><a href="">Bangkok, Thailand</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/6.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/7.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$3000</h4>
                            <span>Big Bang Tower</span>
                            <h3><a href="">England, United Kingdom</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/7.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/8.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1800</h4>
                            <span>Seoul Tower</span>
                            <h3><a href="">Seoul, South Korea</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/8.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/recommended/9.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1100</h4>
                            <span>Kuta Beach</span>
                            <h3><a href="">Bali, Indonesia</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/recommended/9.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-intro img" id="destination-section"
    style="background-image: url(<?php echo e(asset('assets/images/bg_3.jpg)')); ?>;">
    <div class="overlay"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 text-center">
                <h2>Choose the Perfect Destination</h2>
                <p>We can manage your dream building</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>