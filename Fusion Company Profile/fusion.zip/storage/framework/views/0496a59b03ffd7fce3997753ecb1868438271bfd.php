<?php
require 'connection/init.php';
$mysqli = mysqli_connect($domain, $username, $password, $database);

$query_template_design = "SELECT template_design.id AS 'id', template_design.nama AS 'nama', template_design.imgpreview AS 'imgpreview', template_design.html AS 'html'
                      FROM template_design
                      WHERE template_design.event_category_id = '4'";
$hasil_template_design = mysqli_query($mysqli, $query_template_design);
$template_design = array();
while($Hasil = mysqli_fetch_assoc($hasil_template_design))
{
  $template_design[] = $Hasil;
}

mysqli_close($mysqli);

?>
<div class="form-group row">
    <div class="col-md-6">
        <label>Template* <small class="form-text text-muted"> Ex. parallax</small></label>
        <select name="id_template" id="id_template" class="form-control form-opacity" required>
            <?php $__currentLoopData = $template_design; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($td['id']); ?>" <?php echo e((old('template',(isset($event)? $event->template_design_id : ''))==$td['id']) ? 'selected' : ''); ?>><?php echo e($td['nama']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
