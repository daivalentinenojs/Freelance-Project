<?php $__env->startSection('title','Wedding Shop'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page" id="gla_page">



    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>

    <!-- Header -->
    <header>



        <nav class="gla_light_nav gla_transp_nav">
            <div class="container">

                <div class="gla_logo_container clearfix">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="gla_logo_rev">
                    <div class="gla_logo_txt">
                        <!-- Logo -->
                        <a href="" class="gla_logo">3Vite Shop</a>

                        <!-- Text Logo -->
                        <div class="gla_logo_und">Wedding Shop</div>
                    </div>
                </div>

                <!-- Menu -->
                <div class="gla_main_menu gla_main_menu_mobile">

                    <div class="gla_main_menu_icon">
                        <i></i><i></i><i></i><i></i>
                        <b>Menu</b>
                        <b class="gla_main_menu_icon_b">Back</b>
                    </div>
                </div>

                <!-- Menu Content -->
                <!-- <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
                <!-- menu content end -->

                <!-- Search Block -->
                <div class="gla_search_block">

                    <div class="gla_search_block_link gla_search_parent"><i class="ti ti-search"></i>
                        <ul>
                            <li>
                                <form>
                                    <input type="text" class="form-control" placeholder="Enter Your Keywords">
                                    <button type="submit" class="btn">
                                      <i class="ti ti-search"></i>
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Search Block End -->

                <!-- Top Menu -->
                <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- Top Menu End -->



            </div>
            <!-- container end -->
        </nav>

    </header>
    <!-- Header End -->


    <!-- PAGE TITLE SMALL -->
    <div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">



      <div class="container text-left">
        <div class="row">

          <div class="col-md-8">
            <h1 class="gla_h1_title">Shop Category</h1>
            <h3>Some Subtitle</h3>
          </div>

        </div>
      </div>
    </div>

    <!-- Content -->
    <section id="gla_content" class="gla_content">





        <!-- section -->
        <section class="gla_section">
            <div class="container">

                <div class="row">
                    <div class="col-md-8 col-xs-12">


                        <div class="gla_shop_header">
                            <div class="row">
                                <div class="col-md-6">
                                    Showing 1–10 of 24 results
                                </div>
                                <div class="col-md-6 text-right">
                                    <select name="type">
                                        <option value="" selected="selected">Sort By</option>
                                        <option value="">What's new</option>
                                        <option value="">Price high to low</option>
                                        <option value="">Price low to high</option>
                                    </select>
                                </div>
                            </div>
                        </div>



                        <div class="row">

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_sale">Sale</span>
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/alvin-mahmudov-181259.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Vintage Floral
                                    <b><s>$120.36</s> $12.96</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/anne-edgar-119373.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Lost Ink
                                    <b>$13.16</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/brooke-cagle-193346.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    New Look
                                    <b>$10.96</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/brandon-morgan-17707.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Full Midi
                                    <b>$8.28</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>



                </div>
                <!-- row end -->

                <div class="row">


                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">

                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/brooke-cagle-193349.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Vintage Floral
                                    <b><s>$120.36</s> $12.96</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/caroline-veronez-131137.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Lost Ink
                                    <b>$13.16</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/emma-frances-logan-barker-200055.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    New Look
                                    <b>$10.96</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/anete-lusina-147373.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Full Midi
                                    <b>$8.28</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>



                </div>
                <!-- row end -->


                <div class="row">


                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">

                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/tamara-menzi-224980.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Vintage Floral
                                    <b><s>$120.36</s> $12.96</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/tom-pumford-229944.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Lost Ink
                                    <b>$13.16</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/tom-pumford-230331.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    New Look
                                    <b>$10.96</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 gla_anim_box">
                            <div class="gla_shop_item">
                                <span class="gla_shop_item_slider">
                                    <img src="<?php echo e(asset('assets/images/wedding_m/600x600/tom-pumford-241908.jpg')); ?>" alt="">
                                </span>

                                <a href="#" class="gla_shop_item_title">
                                    Full Midi
                                    <b>$8.28</b>
                                </a>
                                <div class="gla_shop_item_links">
                                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                                </div>
                            </div>
                        </div>



                </div>
                <!-- row end -->

                        <nav class="gla_blog_pag">
                            <ul class="pagination">
                                <li><a href="#"><i class="ti ti-angle-left"></i></a></li>
                                <li class="active" ><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#">5</a></li>
                                <li><a href="#"><i class="ti ti-angle-right"></i></a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- col end -->

                    <!--Sidebar-->
                    <div class="col-md-3 col-md-push-1 hidden-xs hidden-sm">


                        <div class="widget">
                            <h6 class="title">About The Author</h6>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua.
                            </p>
                        </div>


                        <div class="widget">
                            <h6 class="title">Search Blog</h6>
                            <form>
                                <input class="form-control" type="text" placeholder="Enter Your Keywords" />
                            </form>
                        </div>


                        <div class="widget">
                            <h6 class="title">Blog Categories</h6>
                            <ul class="list-unstyled">
                                <li>
                                    <a href="#">Business</a>
                                </li>
                                <li>
                                    <a href="#">Creative</a>
                                </li>
                                <li>
                                    <a href="#">Photography</a>
                                </li>
                                <li>
                                    <a href="#">Freelance</a>
                                </li>
                            </ul>
                        </div>

                        <div class="widget">
                            <h6 class="title">Recent Posts</h6>
                            <ul class="list-unstyled recent-posts">
                                <li>
                                    <a href="#">Ut enim ad minim veniam, quis nostrud</a>
                                    <span class="date">November 10, 2016</span>
                                </li>
                                <li>
                                    <a href="#">Excepteur sint occaecat</a>
                                    <span class="date">November 08, 2016</span>
                                </li>
                                <li>
                                    <a href="#">Duis aute irure dolor in reprehenderit in voluptate velit</a>
                                    <span class="date">November 05, 2016</span>
                                </li>
                            </ul>
                        </div>


                        <div class="widget bg-secondary p24">
                            <h6 class="title">Subscribe Now</h6>
                            <p>
                                Subscribe to our newsletter.
                            </p>
                            <form>
                                <input type="text" class="form-control" name="email" placeholder="Email Address" />
                                <input type="submit" class="btn btn-default no-margin" value="Subscribe" />
                            </form>
                        </div>



                    </div>
                    <!--Sidebar End-->

                </div>
            </div>
            <!-- container end -->
        </section>
        <!-- section end -->



    </section>
    <!-- Content End -->


    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
    <!-- Footer End -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>