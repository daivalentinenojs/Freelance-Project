<div class="form-group row">
  <div class="col-md-6">
    <label>Name* <small class="form-text text-muted"> Ex. Daivalentineno Janitra Salim</small></label>
    <input type="text" name="name" class="form-control form-opacity" required data-parsley-maxlength="85" data-parsley-minlength="5" value="<?php echo e(old('name',(isset($event)?$event->nama:''))); ?>">
  </div>
  <div class="col-md-6">
    <label>Telephone* <small class="form-text text-muted"> Ex. 081 1234567890</small></label>
    <input type="text" name="telephone" class="form-control form-opacity form-masked" data-parsley-minlength="10" data-parsley-minlength="14" required data-inputmask="'mask': '999-999999999'" data-parsley-type="digits" value="<?php echo e(old('telephone',(isset($event)? $event->telepon : ''))); ?>">
  </div>
</div>
<div class="form-group row">
  <div class="col-md-12">
    <label>Address* <small class="form-text text-muted"> Ex. North Citraland D6 Number 6</small></label>
    <textarea name="address" rows="3" cols="80" class="form-control form-opacity" data-parsley-minlength="15" required><?php echo e(old('address',(isset($event)? $event->alamat : ''))); ?></textarea>
  </div>
</div>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/js/jquery.inputmask.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/parsley.min.js')); ?>"></script>
<script></script>
<?php $__env->stopPush(); ?>
