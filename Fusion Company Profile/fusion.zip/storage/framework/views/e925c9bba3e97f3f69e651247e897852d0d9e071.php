<?php $__env->startSection('title','Destination'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <span class="subheading" style="font-size:25px">Let's plan your unforgettable holiday!</span>
            </div>
        </div>

        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate" style="background-color:#fefaf8">
                <h2 class="mb-4">Your final adjustment</h2>
                <p>You have chosen Tokyo (Titanium Package) as a tourist destination</p>
            </div>
        </div>
        <br>
        <div class="col-md-12">
            <!-- START JUSTIFIED TABS -->
            <div class="panel panel-default tabs">
                <ul class="nav nav-tabs nav-justified">
                    <li class="active"><a href="#tab1" data-toggle="tab">Day 1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    </li>
                    <li><a href="#tab2" data-toggle="tab">Day 2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    </li>
                    <li><a href="#tab3" data-toggle="tab">Day 3&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    </li>
                    <li><a href="#tab4" data-toggle="tab">Day 4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    </li>
                    <li><a href="#tab5" data-toggle="tab">Day 5&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    </li>
                    <li><a href="#tab6" data-toggle="tab">Day 6&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    </li>
                    <li><a href="#tab7" data-toggle="tab">Day 7&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                    </li>
                </ul>
                <div class="panel-body tab-content">
                    <div class="tab-pane active" id="tab1"><br>
                        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
                            <div class="col-md-12 heading-section">
                                <p><b>Total Price : $800 / person</b></p>
                            </div>
                        </div>
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/1.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/2.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/3.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:130px; width=400px" src="<?php echo e(asset('assets/images/timeline/4.png')); ?>"
                                class="img-fluid">
                        </div>
                    </div>
                    <div class="tab-pane" id="tab2"><br>
                        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
                            <div class="col-md-12 heading-section">
                                <p><b>Total Price : $700 / person</b></p>
                            </div>
                        </div>
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <img style="height:600px; width=400px" src="<?php echo e(asset('assets/images/timeline/5.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/2.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/3.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:130px; width=400px" src="<?php echo e(asset('assets/images/timeline/4.png')); ?>"
                                class="img-fluid">
                        </div>
                    </div>
                    <div class="tab-pane" id="tab3"><br>
                        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
                            <div class="col-md-12 heading-section">
                                <p><b>Total Price : $600 / person</b></p>
                            </div>
                        </div>
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <img style="height:600px; width=400px" src="<?php echo e(asset('assets/images/timeline/5.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/2.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/3.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:130px; width=400px" src="<?php echo e(asset('assets/images/timeline/4.png')); ?>"
                                class="img-fluid">
                        </div>
                    </div>
                    <div class="tab-pane" id="tab4"><br>
                        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
                            <div class="col-md-12 heading-section">
                                <p><b>Total Price : $900 / person</b></p>
                            </div>
                        </div>
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <img style="height:600px; width=400px" src="<?php echo e(asset('assets/images/timeline/5.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/2.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/3.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:130px; width=400px" src="<?php echo e(asset('assets/images/timeline/4.png')); ?>"
                                class="img-fluid">
                        </div>
                    </div>
                    <div class="tab-pane" id="tab5"><br>
                        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
                            <div class="col-md-12 heading-section">
                                <p><b>Total Price : $1000 / person</b></p>
                            </div>
                        </div>
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <img style="height:600px; width=400px" src="<?php echo e(asset('assets/images/timeline/5.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/2.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/3.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:130px; width=400px" src="<?php echo e(asset('assets/images/timeline/4.png')); ?>"
                                class="img-fluid">
                        </div>
                    </div>
                    <div class="tab-pane" id="tab6"><br>
                        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
                            <div class="col-md-12 heading-section">
                                <p><b>Total Price : $800 / person</b></p>
                            </div>
                        </div>
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <img style="height:600px; width=400px" src="<?php echo e(asset('assets/images/timeline/5.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/2.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/3.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:130px; width=400px" src="<?php echo e(asset('assets/images/timeline/4.png')); ?>"
                                class="img-fluid">
                        </div>
                    </div>
                    <div class="tab-pane" id="tab7"><br>
                        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
                            <div class="col-md-12 heading-section">
                                <p><b>Total Price : $900 / person</b></p>
                            </div>
                        </div>
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <img style="height:600px; width=400px" src="<?php echo e(asset('assets/images/timeline/5.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/2.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:700px; width=400px" src="<?php echo e(asset('assets/images/timeline/3.png')); ?>"
                                class="img-fluid"><br>
                            <img style="height:130px; width=400px" src="<?php echo e(asset('assets/images/timeline/4.png')); ?>"
                                class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
            <!-- END JUSTIFIED TABS -->
        </div>
        <form action="#" class="search-property-1">
            <div class="row">
                <div class="col-lg align-self-end">
                    <div class="form-group">
                        <div class="form-field">
                            <a href="<?php echo e(url('destination/payment')); ?>"><input type="button" value="Proceed" class="form-control btn btn-primary"></a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<section class="ftco-intro img" id="destination-section"
    style="background-image: url(<?php echo e(asset('assets/images/bg_3.jpg)')); ?>;">
    <div class="overlay"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 text-center">
                <h2>Choose the Perfect Destination</h2>
                <p>We can manage your dream building</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>