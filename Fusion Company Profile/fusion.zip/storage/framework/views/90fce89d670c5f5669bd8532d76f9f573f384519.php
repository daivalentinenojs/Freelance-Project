<?php $__env->startSection('title','Golden Badges'); ?>

<?php $__env->startSection('music'); ?>
<div class="gla_music_icon">
    <i class="ti ti-music"></i>
</div>
<div class="gla_music_icon_cont">
    <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/47701713&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true" allow="autoplay"></iframe>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_slider gla_image_bck  gla_wht_txt gla_fixed"  data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/01.JPEG')); ?>" data-stellar-background-ratio="0.2">
    <div class="gla_over" data-color="#000" data-opacity="0.7"></div>
    <div class="container">
        <div class="gla_slide_txt gla_slide_center_middle text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/ourwedding_gold.gif')); ?>" alt="" height="330"></p>
            <div class="gla_slide_midtitle" style="text-shadow: 0 0 3px black, 0 0 5px black;">Chris & Alexa <br><?php echo e($date['date']); ?></div>
        </div>
        <div class="gla_slide_txt gla_slide_center_middle text-center">
            
        </div>
    </div>
    <a class="gla_scroll_down gla_go" href="#gla_content">
        <b></b>
        Scroll
    </a>
</div>

<section id="gla_content" class="gla_content">
    <section class="gla_section gla_image_bck" data-color="#">
        <div class="container text-center">
            <h2>Our Story</h2>
            <h3 class="gla_subtitle">When a Man Loves a Woman</h3>
            <p>The first time Chris and Alexa met at PT Samudra Seafood. At that time, Chris was Alexa's boss, while Alexa was the secretary. 
            Chris confessed at that moment to Alexa. We took a few months off, but the heart cannot lie. Chris and Alexa love each other. 
            Until finally, Chris and Alexa decided to build a family together.</p>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_fixed" data-stellar-background-ratio="0.2" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/02.JPEG')); ?>">
        <div class="container">
            <div class="row gla_auto_height">
                <div class="col-md-6 gla_image_bck" data-color="#eee">
                    <div class="gla_simple_block">
                        <h2>Chris Kelly</h2>
                        <p style="text-align:justify">Experienced and self-motivated Manager bringing forth valuable industry experience and a passion for management. 
                        Results oriented with a proven track record of working collaboratively with team members to achieve goals. Experienced in both 
                        retail and culinary settings, and adept at effectively managing all operations.</p>
                    </div>

                </div>
                <div class="col-md-6 gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/16.jpg')); ?>">
                </div>
                <div class="col-md-6 col-md-push-6 gla_image_bck" data-color="#eee">
                    <div class="gla_simple_block">
                        <h2>Alexandra Stefani</h2>
                        <p style="text-align:justify">Systematic Financial Manager with 3 years of experience growing revenue through effective team and project management. 
                        Extensive knowledge of client-based team-building with training in diverse industry supervision. Delivered monthly performance 
                        packages to senior business leaders and prepared detailed budget analyses. Conducted extensive variance analysis to control costs 
                        and improve profitability.</p>
                    </div>
                </div>
                <div class="col-md-6 col-md-pull-6 gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/17.jpg')); ?>">
                </div>
            </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_fixed gla_wht_txt" data-stellar-background-ratio="0.2" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/14_1.JPG')); ?>">
        <div class="gla_over" data-color="#000" data-opacity="0.7"></div>
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/save_gold.gif')); ?>" height="280" alt=""></p>
            <h2><?php echo e($date['date']); ?></h2>
            <h3>The Westin Siray Bay Resort,<br>Phuket, Thailand.</h3>
            <div class="gla_countdown" data-year="<?php echo e($date['year']); ?>" data-month="<?php echo e($date['month']); ?>" data-day="<?php echo e($date['day']); ?>"></div>
        </div>
    </section>

    <section class="gla_section">
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/ourwedding_gold_wh.gif')); ?>" height="200" alt=""></p>
            <h3>Wedding Details</h3>
            <p>Our ceremony and reception will be held at the Liberty House. Located on the Hudson River, it has a beautiful, unobstructed view of the World Trade One building and a convenient ferry that runs between it and Manhattan.</p>
            <div class="row text-center">
                <div class="col-md-4 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/venues/02.JPG')); ?>"></div>
                    <h3>Holy Matrimony</h3>
                    <p>10:00 AM – 11:30 AM<br>
                    St. Aloysius Gonzaga's Church,<br>
                    Surabaya, Indonesia</p>
                    <a target="_blank" href="<?php echo e(url('https://goo.gl/maps/bbecyWWxtxnfSm4KA')); ?>" class="btn">View Map</a>
                </div>
                <div class="col-md-4 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/venues/01.JPG')); ?>"></div>
                    <h3>Wedding Reception</h3>
                    <p>07:00 PM – 11:00 PM<br>
                    The Westin Siray Bay Resort,<br>
                    Phuket, Thailand</p>
                    <a target="_blank" href="<?php echo e(url('https://goo.gl/maps/ryxb1987zhSvV1T6A')); ?>" class="btn">View Map</a>
                </div>
                <div class="col-md-4 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/dress/02.jpg')); ?>"></div>
                    <h3>Dress Code</h3>
                    <p>Man<br><strong>Tuxedo</strong><br>Woman<br><strong>Formal Gowns</strong></p>
                </div>
            </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_fixed gla_wht_txt" data-stellar-background-ratio="0.2" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/09_1.JPEG')); ?>">
        <div class="gla_over" data-color="#000" data-opacity="0.7"></div>
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/rsvp_gold.gif')); ?>" height="200" alt=""></p>
            <div class="row">
                <div class="col-md-8 col-md-push-2">
                    <form>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Your name*</label>
                                <input type="text" name="name" required class="form-control form-opacity">
                            </div>
                            <div class="col-md-6">
                                <label>Your e-mail*</label>
                                <input type="text" name="email" required class="form-control form-opacity">
                            </div>
                            <div class="col-md-6">
                                <label>Will you attend?</label>
                                <input type="radio" name="attend" value="Yes, I will be there">
                                <span>Yes, I will be there</span><br>
                                <input type="radio" name="attend" value="Sorry, I can't come">
                                <span>Sorry, I can't come</span>
                            </div>
                            <div class="col-md-6">
                                <label>Meal preference</label>
                                <select name="meal" class="form-control form-opacity">
                                    <option value="I eat anything">I eat anything</option>
                                    <option value="Beef">Beef</option>
                                    <option value="Chicken">Chicken</option>
                                    <option value="Vegetarian">Vegetarian</option>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label>Notes</label>
                                <textarea name="message" class="form-control form-opacity"></textarea>
                            </div>
                            <div class="col-md-12">
                            <button class="btn submit">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck">
        <div class="container text-center">
            <h2>The Day We Got Engaged</h2>
            <div class="button-group filter-button-group">
                <a data-filter="*">Show All</a>
                <a data-filter=".pre-wedding">Pre Wedding</a>
                <a data-filter=".ceremony">Ceremony</a>
            </div>
            <div class="gla_portfolio_no_padding grid">
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/04.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/04.JPEG')); ?>" alt="">
                        </a>

                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/02.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/02.JPEG')); ?>" alt="">
                        </a>

                    </div>
                </div>                
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/05.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/05.JPEG')); ?>" alt="">
                        </a>

                    </div>
                </div>  
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/03.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/03.JPEG')); ?>" alt="">
                        </a>
                    </div>
                </div>                
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/15.JPG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/15.JPG')); ?>" alt="">
                        </a>
                    </div>
                </div>  
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/06.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/06.JPEG')); ?>" alt="">
                        </a>
                    </div>
                </div> 
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/07.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/07.JPEG')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/08.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/08.JPEG')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/10.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/10.JPEG')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/09.JPEG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/09.JPEG')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/11.JPG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/11.JPG')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/13.JPG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/13.JPG')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/14.JPG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/14.JPG')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-4 gla_anim_box grid-item engagement">
                    <div class="gla_shop_item">
                        <a href="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/12_1.JPG')); ?>" class="lightbox">
                            <img src="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/12_1.JPG')); ?>" alt="">
                        </a>
                    </div>
                </div>
             </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.2" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/10_1.JPEG')); ?>">
        <div class="gla_over" data-color="#000" data-opacity="0.7"></div>
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/thanks_gold.gif')); ?>" height="140" alt=""></p>
            <h2>Registry</h2>
            <p>We’re lucky enough to have nearly everything we need for our home already. And since neither of us has ever been outside of Indonesia, we want our honeymoon to be extra special! If you want to help make it unforgettable, you can contribute using the link to the right. If you would like to give us something to update our home, we’ve compiled a short registry as well.</p>
        </div>
    </section>

    <section class="gla_section gla_image_bck" data-color="#fff">
        <div class="container text-center">
            <h2>Our Journey</h2>
            <div class="row text-center">                
                <div class="col-md-3 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/journeys/01.jpg')); ?>"></div>
                    <h4>Bali, Indonesia</h4>
                </div>
                <div class="col-md-3 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/journeys/02.jpg')); ?>"></div>
                    <h4>Engagement</h4>
                </div>
                <div class="col-md-3 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/journeys/03.jpg')); ?>"></div>
                    <h4>Le Meridien, Bali</h4>
                </div>
                <div class="col-md-3 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/journeys/04.jpg')); ?>"></div>
                    <h4>Monas, Jakarta</h4>
                </div>
                <div class="col-md-3 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/journeys/05.jpg')); ?>"></div>
                    <h4>Omnia, Bali</h4>
                </div>
                <div class="col-md-3 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/journeys/06.jpg')); ?>"></div>
                    <h4>Anniversary</h4>
                </div>
                <div class="col-md-3 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/journeys/07.jpg')); ?>"></div>
                    <h4>Chiang Rai, Thailand</h4>
                </div>
                <div class="col-md-3 gla_round_block">
                    <div class="gla_round_im gla_image_bck" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/journeys/08.jpg')); ?>"></div>
                    <h4>Fins Beach</h4>
                </div>
            </div>
        </div>
    </section>

    <section class="gla_section gla_image_bck gla_fixed gla_wht_txt" data-stellar-background-ratio="0.2" data-image="<?php echo e(asset('assets/images/events/2020/wedding/311001-chris-alexa/photos/12_1.JPG')); ?>">
        <div class="gla_over" data-color="#000" data-opacity="0.7"></div>
        <div class="container text-center">
            <p><img src="<?php echo e(asset('assets/images/animations/just_gold.gif')); ?>" height="143" alt=""></p>
        </div>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>