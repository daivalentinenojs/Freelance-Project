<meta charset="utf-8">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">
<link href="<?php echo e(asset('assets/css/glanz_library.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/fonts/themify-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/glanz_style.css')); ?>" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Dosis:300,400,600,700%7COpen+Sans:300,400,700%7CPlayfair+Display:400,400i,700,700i" rel="stylesheet">
<link href="<?php echo e(asset('assets/fonts/marsha/stylesheet.css')); ?>" rel="stylesheet">
