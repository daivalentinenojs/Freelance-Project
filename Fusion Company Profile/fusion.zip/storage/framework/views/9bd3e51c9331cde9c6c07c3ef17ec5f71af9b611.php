<!-- JQuery -->
<script src="<?php echo e(asset('assets/js/jquery-1.12.4.min.js')); ?>"></script> 

<!-- Library JS -->
<script src="<?php echo e(asset('assets/js/glanz_library.js')); ?>"></script> 

<!-- Theme JS -->
<script src="<?php echo e(asset('assets/js/glanz_script.js')); ?>"></script>
