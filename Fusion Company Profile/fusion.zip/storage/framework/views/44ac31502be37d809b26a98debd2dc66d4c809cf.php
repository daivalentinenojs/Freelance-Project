<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/open-iconic-bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/alertifyjs/alertify.css')); ?>"/>

<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/css/alertifyjs/alertify.js')); ?>"></script>

<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/icomoon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
