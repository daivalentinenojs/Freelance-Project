<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('includes.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent('css'); ?>
  </head>
  <body class="gla_middle_titles">
    <div class="gla_page" id="gla_page">
      <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>
      <?php echo $__env->yieldContent('music'); ?>
      <?php echo $__env->make('includes.header', ['nav' => (isset($nav) ? $nav : 'class="gla_light_nav gla_transp_nav"' )], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
      <?php if(Request::is('/') || Request::is('partner/weddingplanner') || Request::is('partner/weddingflower') || Request::is('partner/weddingcake') || Request::is('shop') || Request::is('aboutus')): ?>
        <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>
    </div>
    <?php echo $__env->make('includes.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent('script'); ?>
  </body>
</html>
