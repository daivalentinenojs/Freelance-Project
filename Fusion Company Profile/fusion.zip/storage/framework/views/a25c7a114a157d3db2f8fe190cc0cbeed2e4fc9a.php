<?php $__env->startSection('title','Destination'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <span class="subheading" style="font-size:25px">Let's plan your unforgettable holiday!</span>
                <h2 class="mb-4">Adjust your traveling preferences</h2>
            </div>
        </div>
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate" style="background-color:#fefaf8">
                <h2 class="mb-4">Recommended Flights</h2>
                <input style="margin-left:10px;" type="checkbox" value="0">&nbsp;&nbsp; <span style="font-color:black">I
                    want to order it by myself</span> <br><br>

            </div>
        </div>
        <br><br>
        <div class="col-md-12">
            <!-- START JUSTIFIED TABS -->
            <div class="panel panel-default tabs">
                <ul class="nav nav-tabs nav-justified">
                    <li class="active"><a href="#tab8" data-toggle="tab">Departure
                            Flight <br> Sat, 21 Dec 2019 <br> Taipei -> Tokyo</a></li>
                    <li><a href="#tab9" data-toggle="tab">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Return Flight
                            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fri, 27 Dec 2019 <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tokyo
                            -> Taipei</a></li>
                </ul>
                <div class="panel-body tab-content">
                    <div class="tab-pane active" id="tab8">
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="search-wrap-1 ftco-animate p-4">
                                        <form action="#" class="search-property-1">
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <img style="width:50px; height:50px"
                                                            src="<?php echo e(asset('assets/images/aeroplanes/1.png')); ?>" alt="">
                                                        <label for="#">Scoot</label>
                                                    </div>
                                                </div>
                                            </div><br>
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">06:40</label><br>
                                                        <label for="#">Taipei (TPE)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">10:45</label><br>
                                                        <label for="#">Tokyo (NRT)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">3h 5m</label><br>
                                                        <label for="#">Direct</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <span class="icon-wifi"></span>
                                                        <span class="icon-briefcase"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-self-end">
                                                    <div class="form-group">
                                                        <div class="form-field">
                                                            <label for="#">$2350 / pax</label><br>
                                                            <input type="button" id="btn_scoot" value="Choose"
                                                                class="form-control btn btn-primary">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><br>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="search-wrap-1 ftco-animate p-4">
                                        <form action="#" class="search-property-1">
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <img style="width:50px; height:25px"
                                                            src="<?php echo e(asset('assets/images/aeroplanes/2.png')); ?>" alt="">
                                                        <label for="#">Jetstar</label>
                                                    </div>
                                                </div>
                                            </div><br>
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">03:20</label><br>
                                                        <label for="#">Taipei (TPE)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">07:30</label><br>
                                                        <label for="#">Tokyo (NRT)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">3h 10m</label><br>
                                                        <label for="#">Direct</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <span class="icon-briefcase"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-self-end">
                                                    <div class="form-group">
                                                        <div class="form-field">
                                                            <label for="#">$3550 / pax</label><br>
                                                            <input type="button" id="btn_jetstar" value="Choose"
                                                                class="form-control btn btn-primary">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><br>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="search-wrap-1 ftco-animate p-4">
                                        <form action="#" class="search-property-1">
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <img style="width:35px; height:30px"
                                                            src="<?php echo e(asset('assets/images/aeroplanes/3.png')); ?>" alt="">
                                                        <label for="#">China Airlines</label>
                                                    </div>
                                                </div>
                                            </div><br>
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">14:40</label><br>
                                                        <label for="#">Taipei (TPE)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">18:45</label><br>
                                                        <label for="#">Tokyo (NRT)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">3h 5m</label><br>
                                                        <label for="#">Direct</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <span class="icon-wifi"></span>
                                                        <span class="icon-briefcase"></span>
                                                        <span class="icon-hamburger"></span>
                                                        <span class="icon-coffee"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-self-end">
                                                    <div class="form-group">
                                                        <div class="form-field">
                                                            <label for="#">$4150 / pax</label><br>
                                                            <input type="button" id="btn_china" value="Choose"
                                                                class="form-control btn btn-primary">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><br>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab9">
                        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="search-wrap-1 ftco-animate p-4">
                                        <form action="#" class="search-property-1">
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <img style="width:50px; height:50px"
                                                            src="<?php echo e(asset('assets/images/aeroplanes/1.png')); ?>" alt="">
                                                        <label for="#">Scoot</label>
                                                    </div>
                                                </div>
                                            </div><br>
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">11:45</label><br>
                                                        <label for="#">Tokyo (NRT)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">15:10</label><br>
                                                        <label for="#">Taipei (TPE)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">4h 25m</label><br>
                                                        <label for="#">Direct</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <span class="icon-wifi"></span>
                                                        <span class="icon-briefcase"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-self-end">
                                                    <div class="form-group">
                                                        <div class="form-field">
                                                            <label for="#">$2250 / pax</label><br>
                                                            <a href=""><input type="submit" value="Choose"
                                                                    class="form-control btn btn-primary"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><br>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="search-wrap-1 ftco-animate p-4">
                                        <form action="#" class="search-property-1">
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <img style="width:30px; height:30px"
                                                            src="<?php echo e(asset('assets/images/aeroplanes/5.png')); ?>" alt="">
                                                        <label for="#">Korean Air</label>
                                                    </div>
                                                </div>
                                            </div><br>
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">09:05</label><br>
                                                        <label for="#">Tokyo (NRT)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">18:15</label><br>
                                                        <label for="#">Taipei (TPE)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">10h 10m</label><br>
                                                        <label for="#">Direct</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <span class="icon-wifi"></span>
                                                        <span class="icon-briefcase"></span>
                                                        <span class="icon-hamburger"></span>
                                                        <span class="icon-coffee"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-self-end">
                                                    <div class="form-group">
                                                        <div class="form-field">
                                                            <label for="#">$3550 / pax</label><br>
                                                            <a href=""><input type="submit" value="Choose"
                                                                    class="form-control btn btn-primary"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><br>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="search-wrap-1 ftco-animate p-4">
                                        <form action="#" class="search-property-1">
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <img style="width:35px; height:30px"
                                                            src="<?php echo e(asset('assets/images/aeroplanes/6.png')); ?>" alt="">
                                                        <label for="#">China Eastern Airlines</label>
                                                    </div>
                                                </div>
                                            </div><br>
                                            <div class="row">
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">13:50</label><br>
                                                        <label for="#">Tokyo (NRT)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">22:00</label><br>
                                                        <label for="#">Taipei (TPE)</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <label for="#">9h 10m</label><br>
                                                        <label for="#">Direct</label>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-items-end">
                                                    <div class="form-group">
                                                        <span class="icon-wifi"></span>
                                                        <span class="icon-briefcase"></span>
                                                        <span class="icon-hamburger"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg align-self-end">
                                                    <div class="form-group">
                                                        <div class="form-field">
                                                            <label for="#">$1850 / pax</label><br>
                                                            <a href=""><input type="submit" value="Choose"
                                                                    class="form-control btn btn-primary"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><br>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END JUSTIFIED TABS -->
        </div>


        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate" style="background-color:#fefaf8">
                <h2 class="mb-4">Recommended Places</h2>
                <input style="margin-left:10px;" type="checkbox" value="0">&nbsp;&nbsp; <span style="font-color:black">I
                    want to order it by myself</span> <br><br>

            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/room/1.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$150</h4>
                            <span>Nouka</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_book" class="btn btn-primary">Book</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/room/1.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/room/2.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$225</h4>
                            <span>Doma</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_book" class="btn btn-primary">Book</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/room/2.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/room/3.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$110</h4>
                            <span>Minka</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_book" class="btn btn-primary">Book</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/room/3.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/room/4.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$170</h4>
                            <span>Shoin Zukuri</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_book" class="btn btn-primary">Book</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/room/4.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/room/5.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$85</h4>
                            <span>Machiya</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_book" class="btn btn-primary">Book</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/room/5.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/room/6.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$1100</h4>
                            <span>Shoin Zukuri</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_book" class="btn btn-primary">Book</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/room/6.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>


        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate" style="background-color:#fefaf8">
                <h2 class="mb-4">Recommended Foods</h2>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/foods/1.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$80</h4>
                            <span>Sushi</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_food" class="btn btn-primary">I eat this</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/foods/1.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/foods/2.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$105</h4>
                            <span>Minka</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_food" class="btn btn-primary">I eat this</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/foods/2.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/foods/3.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$220</h4>
                            <span>Italian Food</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_food" class="btn btn-primary">I eat this</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/foods/3.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
            <div class="row">
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/foods/4.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$120</h4>
                            <span>Pescatarian (Fish)</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_food" class="btn btn-primary">I eat this</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/foods/4.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/foods/5.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$200</h4>
                            <span>Vegetarian</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_food" class="btn btn-primary">I eat this</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/foods/5.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 ftco-animate">
                    <div class="project">
                        <div class="img">
                            <img style="height:200px; width=230px" src="<?php echo e(asset('assets/images/foods/6.jpg')); ?>"
                                class="img-fluid" alt="Colorlib Template">
                        </div>
                        <div class="text">
                            <h4 class="price">$125</h4>
                            <span>Halal Food</span>
                            <h3><a href="">Tokyo, Japan</a></h3>
                            <div class="star d-flex clearfix">
                                <div class="mr-auto float-left">
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                    <span class="ion-ios-star"></span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-4 meta">
                                <p class="mb-0">
                                    <a id="btn_food" class="btn btn-primary">I eat this</a>
                                </p>
                            </div>
                        </div>
                        <a href="<?php echo e(asset('assets/images/foods/6.jpg')); ?>"
                            class="icon image-popup d-flex justify-content-center align-items-center">
                            <span class="icon-expand"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate" style="background-color:#fefaf8">
                <h2 class="mb-4">Recommended Activities</h2>
            </div>
        </div>
        <div class="row d-flex">
            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/1.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Bridge Climb</span></h3>
                        <p>Step your sightseeing up a gear by taking on the Sydney Bridge Climb.</p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_activities" class="btn btn-primary">I want this</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/2.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>White Water River Rafting</span></h3>
                        <p>Practice your rafting skills before embarking on this rafting tour. </p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_activities" class="btn btn-primary">I want this</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry">
                    <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/3.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Tandem Parasail Flight</span>
                        </h3>
                        <p>Fly high above the Bay of Islands on a tandem parasailing tour. </p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_activities" class="btn btn-primary">I want this</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry">
                    <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/4.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Snorkel with Wild Dolphins</span></h3>
                        <p>14 guest max, no massive crowds! Snorkel with wild dolphins. </p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_activities" class="btn btn-primary">I want this</a>
                            </p>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry">
                    <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/5.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Private Customizable Sailing Tour</span></h3>
                        <p>Enjoy a private sailing tour for you and your party aboard a 44-feet sailboat Bavaria.</p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_activities" class="btn btn-primary">I want this</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry">
                    <span class="block-20" style="background-image: url('<?php echo e(asset('assets/images/blog/6.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Bali Boarders Surfschool</span></h3>
                        <p>Boarders Surfing is a local Surfing School located in Osaka. </p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_activities" class="btn btn-primary">I want this</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <form action="#" class="search-property-1">
            <div class="row">
                <div class="col-lg align-self-end">
                    <div class="form-group">
                        <div class="form-field">
                            <a href="<?php echo e(url('/destination/dream_place')); ?>"><input type="button" value="Next"
                                    class="form-control btn btn-primary"></a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<section class="ftco-intro img" id="destination-section"
    style="background-image: url(<?php echo e(asset('assets/images/bg_3.jpg)')); ?>;">
    <div class="overlay"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 text-center">
                <h2>Choose the Perfect Destination</h2>
                <p>We can manage your dream building</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
$(function() {
    $(document).on('click', '#btn_scoot', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to buy Scoot Ticket ?",
            function() {
                alertify.success('Scoot Ticket has been booked');
            },
            function() {
                alertify.error('Scoot Ticket has not been booked');
            });
    });
});

$(function() {
    $(document).on('click', '#btn_jetstar', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to buy Jetstar Ticket ?",
            function() {
                alertify.success('Jetstar Ticket has been booked');
            },
            function() {
                alertify.error('Jetstar Ticket has not been booked');
            });
    });
});

$(function() {
    $(document).on('click', '#btn_china', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to buy China Airlines Ticket ?",
            function() {
                alertify.success('China Airlines Ticket has been booked');
            },
            function() {
                alertify.error('China Airlines Ticket has not been booked');
            });
    });
});

$(function() {
    $(document).on('click', '#btn_book', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to book the hotel ?",
            function() {
                alertify.success('Hotel has been booked');
            },
            function() {
                alertify.error('Hotel has not been booked');
            });
    });
});

$(function() {
    $(document).on('click', '#btn_food', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to eat this kind of food ?",
            function() {
                alertify.success('This food has been chosen');
            },
            function() {
                alertify.error('This food has been canceled');
            });
    });
});

$(function() {
    $(document).on('click', '#btn_activities', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to do this kind of activities ?",
            function() {
                alertify.success('Activities has been chosen');
            },
            function() {
                alertify.error('Activities has been canceled');
            });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>