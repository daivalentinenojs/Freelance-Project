<div class="gla_default_menu">
    <ul>
        <li><a href="<?php echo e(url('/')); ?>">Time Line</a></li>

        <li class="gla_parent"><a href="">Template</a>
            <ul>
                <li><a href="<?php echo e(url('/animatedflowers')); ?>">Animated Flowers</a></li>
                <li><a href="<?php echo e(url('/pinkanimatedflowers')); ?>">Pink Animated Flowers</a></li>
                <li><a href="<?php echo e(url('/goldenbadges')); ?>">Golden Badges</a></li>
                <li><a href="<?php echo e(url('/greatflowers')); ?>">Great Flowers</a></li>
                <li><a href="<?php echo e(url('/simpleflowers')); ?>">Simple Flowers</a></li>
                <li><a href="<?php echo e(url('/abstractflowers')); ?>">Abstract Flowers</a></li>
                <li><a href="<?php echo e(url('/parallax')); ?>">Parallax</a></li>
                <li><a href="<?php echo e(url('/landing')); ?>">Landing</a></li>
            </ul>
        </li>

        <li class="gla_parent"><a href="">Invitation</a>
            <ul>
                <li><a href="<?php echo e(url('/pinkinvitation')); ?>">Pink Invitation</a></li>
                <li><a href="<?php echo e(url('/purpleinvitation')); ?>">Purple Invitation</a></li>
                <li><a href="<?php echo e(url('/redinvitation')); ?>">Red Invitation</a></li>
            </ul>
        </li>

        <li class="gla_parent"><a href="">Partner</a>
            <ul>
                <li><a href="<?php echo e(url('/weddingplanner')); ?>">Wedding Planner</a></li>
                <li><a href="<?php echo e(url('/weddingflowers')); ?>">Wedding Flowers</a></li>
                <li><a href="<?php echo e(url('/weddingcakes')); ?>">Wedding Cakes</a></li>
            </ul>
        </li>

        <li><a href="<?php echo e(url('/shop')); ?>">Shop</a></li>

        <li class="gla_parent"><a href="">Master Data</a>
            <ul>
                <li><a href="<?php echo e(url('/musers')); ?>">Users</a></li>
                <li><a href="<?php echo e(url('/mweddingplanners')); ?>">Wedding Planners</a></li>
                <li><a href="<?php echo e(url('/mweddingflowers')); ?>">Wedding Flowers</a></li>
                <li><a href="<?php echo e(url('/mweddingcakes')); ?>">Wedding Cakes</a></li>
                <li><a href="<?php echo e(url('/mitems')); ?>">Items</a></li>
            </ul>
        </li>

        <li><a href="<?php echo e(url('/aboutus')); ?>">About Us</a></li>

    </ul>
</div>
