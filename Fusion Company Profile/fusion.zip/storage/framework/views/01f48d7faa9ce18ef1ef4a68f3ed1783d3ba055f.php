<?php $__env->startSection('title','Destination'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section ftco-services-2" id="services-section">
    <div class="container">
        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate">
                <span class="subheading" style="font-size:25px">Let's plan your unforgettable holiday!</span>
            </div>
        </div>

        <div class="row justify-content-center pb-0 pb-mb-5 pt-5 pt-md-0">
            <div class="col-md-12 heading-section ftco-animate" style="background-color:#fefaf8">
                <h2 class="mb-4">Do you have any dream places?</h2>
                <p>For your 7 days itinerary, we suggest you to choose 14 dream places.</p>
            </div>
            <form action="#" class="col-md-12 search-property-1">
                <div class="col-md-12 row">
                    <div class="col-md-9">
                        <div class="form-group">
                            <label for="#"></label>
                            <div class="form-field">
                                <div class="icon"><span class="ion-ios-search"></span></div>
                                <input name="search_item" type="text" class="form-control" placeholder="Search">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 align-self-end">
                        <div class="form-group">
                            <div class="form-field">
                                <a href=""><input type="button" value="Search" class="form-control btn btn-primary"></a>
                            </div>
                        </div>
                    </div>
                </div><br>

            </form>
        </div>

        <div class="row d-flex">
            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/1.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Mountain Fuji</span></h3>
                        <p>This Lake Ashi and Mt. Fuji trip stands out thanks to included rides to and from Tokyo aboard
                            the bullet train.</p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_dp" class="btn btn-primary">My dream place</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry justify-content-end">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/2.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Golden Pavilion</span></h3>
                        <p>Kinkakuji (Golden Pavilion) is a Zen temple in northern Kyoto whose top two floors are
                            completely covered in gold leaf. </p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_dp" class="btn btn-primary">My dream place</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/3.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Fujiko F Fujio Museum</span>
                        </h3>
                        <p>The Fujiko F. Fujio Museum (Doraemon Museum) is a fanciful art museum found in the suburbs of
                            Kawasaki. </p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_dp" class="btn btn-primary">My dream place</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/4.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Tokyo Disney Land</span></h3>
                        <p>Disneyland Japan boasts some of the world's leading theme-park attractions, easily rivalling
                            the franchise's US operations with a charming retro-futuristic feel that's all its own. </p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_dp" class="btn btn-primary">My dream place</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/5.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Tokyo Disney Sea</span></h3>
                        <p>Tokyo’s DisneySea is a must-see attraction for many visitors to Japan. Here is our full
                            guide, with transport information, ticket information, and insider tips to skipping lines
                            and getting the most out of your visit.</p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_dp" class="btn btn-primary">My dream place</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex ftco-animate" style="height:600px">
                <div class="blog-entry">
                    <span class="block-20"
                        style="background-image: url('<?php echo e(asset('assets/images/recommended/japan/6.jpg')); ?>');">
                    </span>
                    <div class="text float-right d-block">
                        <h3 class="heading"><span>Himeji Castle</span></h3>
                        <p>Himeji Castle, also known as White Heron Castle due to its elegant, white appearance, is
                            widely considered as Japan's most spectacular castle for its imposing size and beauty.</p>
                        <div class="d-flex align-items-center mt-4 meta">
                            <p class="mb-0">
                                <a id="btn_dp" class="btn btn-primary">My dream place</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <form action="#" class="search-property-1">
            <div class="row">
                <div class="col-lg align-self-end">
                    <div class="form-group">
                        <div class="form-field">
                            <a href="<?php echo e(url('/destination/traveling_package')); ?>"><input type="button" value="Next"
                                    class="form-control btn btn-primary"></a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<section class="ftco-intro img" id="destination-section"
    style="background-image: url(<?php echo e(asset('assets/images/bg_3.jpg)')); ?>;">
    <div class="overlay"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 text-center">
                <h2>Choose the Perfect Destination</h2>
                <p>We can manage your dream building</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
$(function() {
    $(document).on('click', '#btn_dp', function(e) {
        e.preventDefault();
        alertify.confirm("Is this your dream place ?",
            function() {
                alertify.success('This place has been chosen');
            },
            function() {
                alertify.error('This place has been canceled');
            });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>