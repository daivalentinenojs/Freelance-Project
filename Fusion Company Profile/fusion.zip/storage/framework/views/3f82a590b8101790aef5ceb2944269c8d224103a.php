<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('include.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>

<!-- ======= Header ======= -->
<header id="header" class="fixed-top ">
    <?php echo $__env->make('include.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header><!-- End Header -->

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

<?php echo $__env->make('include.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>

</body>

</html>