<div class="container d-flex align-items-center justify-content-lg-between">

   <h1 class="logo me-auto me-lg-0"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/images/logo/logo.svg')); ?>" alt="logo"></a></h1>
   <!-- Uncomment below if you prefer to use an image logo -->
   <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

   <nav id="navbar" class="navbar order-last order-lg-0">
      <ul>
         <li><a class="nav-link scrollto <?php echo e((Request::is('/') ? 'class=active' : '')); ?>" href="<?php echo e(url('/')); ?>">Home</a></li>
         <li><a class="nav-link scrollto <?php echo e((Request::is('about') ? 'class=active' : '')); ?>" href="<?php echo e(url('about')); ?>">About</a></li>
         <li><a class="nav-link scrollto <?php echo e((Request::is('services') ? 'class=active' : '')); ?>" href="<?php echo e(url('services')); ?>">Services</a></li>
         <li><a class="nav-link scrollto <?php echo e((Request::is('portfolio') ? 'class=active' : '')); ?>" href="<?php echo e(url('portfolio')); ?>">Portfolio</a></li>
         <li><a class="nav-link scrollto <?php echo e((Request::is('team') ? 'class=active' : '')); ?>" href="<?php echo e(url('team')); ?>">Team</a></li>
         <li><a class="nav-link scrollto <?php echo e((Request::is('contact') ? 'class=active' : '')); ?>" href="<?php echo e(url('contact')); ?>">Contact</a></li>
      </ul>
      <i class="bi bi-list mobile-nav-toggle"></i>
   </nav><!-- .navbar -->

   <a href="<?php echo e(url('about')); ?>" class="get-started-btn scrollto">Get Started</a>

</div>
