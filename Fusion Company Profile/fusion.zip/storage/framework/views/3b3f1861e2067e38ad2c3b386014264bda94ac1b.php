<?php $__env->startSection('title','Ticket And Book'); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading" style="font-size:25px;">What is your dream place?</span>
                <h2 class="mb-4">Best Place to Travel</h2>
                <p>"To give real service you must add something which cannot be bought or measured with money, <br> and
                    that is sincerity and integrity." - Douglas Adams </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <div class="vr"><span>Sale</span></div>
                        <img src="<?php echo e(asset('assets/images/destination/1.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="old-price mr-2">$500</span>$400</h4>
                        <span>Shinjuku Gyoen</span>
                        <h3><a href="">Tokyo, Jepang</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/destination/1.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/destination/2.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price">$400</h4>
                        <span>Ginza Big Market</span>
                        <h3><a href="">Tokyo, Jepang</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/destination/2.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/destination/3.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price">$400</h4>
                        <span>Kull Sensoji</span>
                        <h3><a href="">Tokyo, Jepang</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/destination/3.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/destination/4.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price">$400</h4>
                        <span>Akibahara</span>
                        <h3><a href="">Tokyo, Jepang</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/destination/4.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/destination/5.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price">$400</h4>
                        <span>Ueno Park</span>
                        <h3><a href="">Tokyo, Jepang</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/destination/5.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/destination/6.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price">$400</h4>
                        <span>Roponggi</span>
                        <h3><a href="">Tokyo, Jepang</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/destination/6.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading" style="font-size:25px;">Do you like to stay in luxury place? These are our
                    recommendations</span>
                <h2 class="mb-4">Find Nearest Hotel</h2>
                <p>"All good hotels tend to lead people to do things they wouldn't necessarily do at home." - Andre
                    Balazs</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <div class="vr"><span>Sale</span></div>
                        <a href=""><img src="<?php echo e(asset('assets/images/hotel/1.jpg')); ?>" class="img-fluid"
                                alt="Colorlib Template"></a>
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="old-price mr-2">$800</span>$700</h4>
                        <span>3 nights</span>
                        <h3><a href="">Hotel Higashi Ikebukuro</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/hotel/1.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <a href=""><img src="<?php echo e(asset('assets/images/hotel/2.jpg')); ?>" class="img-fluid"
                                alt="Colorlib Template"></a>
                    </div>
                    <div class="text">
                        <h4 class="price">$300</h4>
                        <span>1 nights</span>
                        <h3><a href="">The Peninsula Tokyo</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/hotel/2.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <a href=""><img src="<?php echo e(asset('assets/images/hotel/3.jpg')); ?>" class="img-fluid"
                                alt="Colorlib Template"></a>
                    </div>
                    <div class="text">
                        <h4 class="price">$500</h4>
                        <span>2 nights</span>
                        <h3><a href="">InterContinental Tokyo Bay</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('assets/images/hotel/3.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
        </div>
        <div class="row justify-content-center pb-5 pt-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading" style="font-size:25px;">Do you need a cheap living place? These are for
                    you.</span>
                <h2 class="mb-4">Best Rooms Offer</h2>
                <p>"Smile. It instantly lifts the face, and it just lights up the room." - Christie Brinkley</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 room-wrap">
                <div class="row">
                    <div class="col-md-7 d-flex ftco-animate">
                        <div class="img align-self-stretch"
                            style="background-image: url(<?php echo e(asset('assets/images/room/1.jpg)')); ?>;"></div>
                    </div>
                    <div class="col-md-5 ftco-animate">
                        <div class="text py-5">
                            <h3><a href="">Hotel Alpin Spa Tuxerhof</a></h3>
                            <p class="pos">from <span class="price">$120.00</span> / night</p>
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div><br>
                            <p>Our Alpine Spa is a haven for individuals and especially for couples. We have several
                                offers for partner treatments. Enjoy a snow crystal peeling on the hot stone, a
                                melissa-lemon bath in the romantic tub or an anti-stress massage together with your
                                partner and rest in the soft waterbeds. Enjoy our convivial atmosphere, the spacious and
                                comfortable accommodation in our new suites and our excellent cuisine.</p>
                            <p><a class="btn btn-secondary">Details</a> <a id="btn_book" class="btn btn-primary">Book now</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 room-wrap room-wrap-thumb mt-4">
                <div class="row">
                    <div class="col-md-3 ftco-animate">
                        <a href="" class="d-flex thumb">
                            <div class="img align-self-stretch"
                                style="background-image: url(<?php echo e(asset('assets/images/room/2.jpg)')); ?>;"></div>
                            <div class="text pl-3 py-3">
                                <h3>Ikosien Oceania</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 ftco-animate">
                        <a href="" class="d-flex thumb">
                            <div class="img align-self-stretch"
                                style="background-image: url(<?php echo e(asset('assets/images/room/3.jpg)')); ?>;"></div>
                            <div class="text pl-3 py-3">
                                <h3>Standard Room</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 ftco-animate">
                        <a href="" class="d-flex thumb">
                            <div class="img align-self-stretch"
                                style="background-image: url(<?php echo e(asset('assets/images/room/4.jpg)')); ?>;"></div>
                            <div class="text pl-3 py-3">
                                <h3>Classic Suites Family Room</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 ftco-animate">
                        <a href="" class="d-flex thumb">
                            <div class="img align-self-stretch"
                                style="background-image: url(<?php echo e(asset('assets/images/room/5.jpg)')); ?>;"></div>
                            <div class="text pl-3 py-3">
                                <h3>Clifftop Resort</h3>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section" id="restaurant-section">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading" style="font-size:25px;">Are you hungry? Travier has some recommendation
                    restaurant for you.</span>
                <h2 class="mb-4">Nearest Resturant</h2>
                <p>"Life is like a restaurant; you can have anything you want as long as you are willing to pay the
                    price" - Moffat Machingura</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/restaurant/1.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="mr-2">menu start at</span>$45.00</h4>
                        <span>Tokyo, Jepang</span>
                        <h3><a href="project.html">Steak House</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                        <p><a class="btn btn-secondary">Details</a> <a id="btn_food" class="btn btn-primary">Book now</a></p>
                    </div>
                    <a href="<?php echo e(asset('assets/images/restaurant/1.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/restaurant/2.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="mr-2">menu start at</span>$20.00</h4>
                        <span>Tokyo, Jepang</span>
                        <h3><a href="project.html">Halal Indonesian Food</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                        <p><a class="btn btn-secondary">Details</a> <a id="btn_food" class="btn btn-primary">Book now</a></p>
                    </div>
                    <a href="<?php echo e(asset('assets/images/restaurant/2.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ftco-animate">
                <div class="project">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/restaurant/3.jpg')); ?>" class="img-fluid"
                            alt="Colorlib Template">
                    </div>
                    <div class="text">
                        <h4 class="price"><span class="mr-2">menu start at</span>$14.00</h4>
                        <span>Tokyo, Jepang</span>
                        <h3><a href="project.html">Cake and Bakery</a></h3>
                        <div class="star d-flex clearfix">
                            <div class="mr-auto float-left">
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                                <span class="ion-ios-star"></span>
                            </div>
                        </div>
                        <p><a class="btn btn-secondary">Details</a> <a id="btn_food" class="btn btn-primary">Book now</a></p>
                    </div>
                    <a href="<?php echo e(asset('assets/images/restaurant/3.jpg')); ?>"
                        class="icon image-popup d-flex justify-content-center align-items-center">
                        <span class="icon-expand"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
$(function() {
    $(document).on('click', '#btn_book', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to book this hotel ?",
            function() {
                alertify.success('This hotel has been booked');
            },
            function() {
                alertify.error('This hotel has been canceled');
            });
    });
});

$(function() {
    $(document).on('click', '#btn_food', function(e) {
        e.preventDefault();
        alertify.confirm("Do you want to book this restaurant ?",
            function() {
                alertify.success('This restaurant has been booked');
            },
            function() {
                alertify.error('This restaurant has been canceled');
            });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>