Hello, <br><br>
Thank you for registering your data to 3Vite. <br>
Your register form almost done, please verify your email by clicking link below : <br>
<a href="<?php echo e(url('verification/'.$eid)); ?>"><?php echo e(url('verification/'.$eid)); ?></a> <br><br>

Regards, <br>
3Vite Team
