<?php $__env->startSection('title','Parallax'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page" id="gla_page">



    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>

    <!-- Music -->
    <div class="gla_music_icon">
        <i class="ti ti-music"></i>
    </div>
    <div class="gla_music_icon_cont">
        <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/66757544&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>
    </div>

    <!-- Header -->
    <header>



        <nav class="gla_light_nav gla_transp_nav">

            <div class="container">

                <div class="gla_logo_container clearfix">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="gla_logo_rev">
                    <div class="gla_logo_txt">
                        <!-- Logo -->
                        <a href="http://glanz.starkethemes.com/" class="gla_logo">Mark & Liz</a>

                        <!-- Text Logo -->
                        <div class="gla_logo_und">August 10, 2017</div>
                    </div>
                </div>

                <!-- Menu -->
                <div class="gla_main_menu gla_main_menu_mobile">

                    <div class="gla_main_menu_icon">
                        <i></i><i></i><i></i><i></i>
                        <b>Menu</b>
                        <b class="gla_main_menu_icon_b">Back</b>
                    </div>
                </div>

                <!-- Menu Content -->
                <!-- <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
                <!-- menu content end -->

                <!-- Search Block -->
                <div class="gla_search_block">

                    <div class="gla_search_block_link gla_search_parent"><i class="ti ti-search"></i>
                        <ul>
                            <li>
                                <form>
                                    <input type="text" class="form-control" placeholder="Enter Your Keywords">
                                    <button type="submit" class="btn">
                                      <i class="ti ti-search"></i>
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Search Block End -->

                <!-- Top Menu -->
                <?php echo $__env->make('navigation.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- Top Menu End -->



            </div>
            <!-- container end -->
        </nav>

    </header>
    <!-- Header End -->


    <!-- Slider -->
    <div class="gla_slider gla_image_bck gla_wht_txt gla_fixed"  data-image="<?php echo e(asset('assets/images/wedding/mark_liz/10503327696_43f22603da_k.jpg')); ?>" data-stellar-background-ratio="0.8">

        <!-- Over -->
        <div class="gla_over" data-color="#9abab6" data-opacity="0.2"></div>


        <div class="container">


            <!-- Slider Texts -->
            <div class="gla_slide_txt gla_slide_center_bottom text-center">
                <div class="gla_slide_midtitle">We're Getting Married</div>
                <div class="gla_slide_subtitle">Mark & Liz</div>

            </div>
            <!-- Slider Texts End -->

        </div>
        <!-- container end -->

        <!-- Slide Down -->
        <a class="gla_scroll_down gla_go" href="#gla_content">
            <b></b>
            Scroll
        </a>


    </div>
    <!-- Slider End -->

    <!-- Content -->
    <section id="gla_content" class="gla_content">


        <!-- section -->
        <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.4" data-image="<?php echo e(asset('assets/images/wedding/mark_liz/10502734756_d295257d36_k.jpg')); ?>">

            <!-- Over -->
            <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>

            <div class="container text-left">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <h2>Our Story</h2>
                        <h3 class="gla_subtitle">The Fourth of July</h3>

                        <p>My fiancé proposed on the Fourth of July. My mother asked us to go to the backyard to get some chairs and he took me by the shed where we could see all of the fireworks. He kissed me, then he took the ring box out of his pocket and asked me to be his wife. He was shaking a little. The proposal was a little silly but perfect, just like him." — Jeska Cords</p>
                    </div>
                </div>


            </div>
            <!-- container end -->

        </section>
        <!-- section end -->


        <!-- section -->
        <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.4" data-image="<?php echo e(asset('assets/images/wedding/mark_liz/10503392955_fb46d6b158_k.jpg')); ?>">

            <!-- Over -->
            <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>


            <div class="container text-right">
                <p><img src="<?php echo e(asset('assets/images/animations/savethedate_wh.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/savethedate_wh.gif')); ?>" height="150" alt=""></p>
                <h2><?php echo e($date['date']); ?></h2>
                <h3 class="gla_subtitle">St. Thomas's Church,<br>Bristol, U.K.</h3>
                <div class="gla_countdown" data-year="<?php echo e($date['year']); ?>" data-month="<?php echo e($date['month']); ?>" data-day="<?php echo e($date['day']); ?>"></div>

            </div>
            <!-- container end -->

        </section>
        <!-- section end -->





        <!-- section -->
        <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.4" data-image="<?php echo e(asset('assets/images/wedding/mark_liz/10502663484_d6f61198b4_k.jpg')); ?>">

            <!-- Over -->
            <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>

            <div class="container text-left">

                <p><img src="<?php echo e(asset('assets/images/animations/just_wh.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/just_wh.gif')); ?>" height="150" alt=""></p>
                <h3>You’re wonderful. <br>Can you be wonderful <br>FOREVER?"</h3>
                <p class="gla_subtitle">— Brennan. A true master of words.</p>



            </div>
            <!-- container end -->

        </section>
        <!-- section end -->





        <!-- section -->
        <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.4" data-image="<?php echo e(asset('assets/images/wedding/mark_liz/10503022515_d96d642143_k.jpg')); ?>">

            <!-- Over -->
            <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>

            <div class="container text-right">


                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <br>
                    </div>
                    <div class="col-md-6 col-sm-12">

                        <p><img src="<?php echo e(asset('assets/images/animations/rsvp_wh.gif')); ?>" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/rsvp_wh.gif')); ?>" height="180" alt=""></p>
                        <form action="https://formspree.io/your@mail.com" method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <label>Your name*</label>
                                    <input type="text" name="name" class="form-control form-opacity">
                                </div>
                                <div class="col-md-6">
                                    <label>Your e-mail*</label>
                                    <input type="text" name="email" class="form-control form-opacity">
                                </div>

                                <div class="col-md-6">
                                    <label>Will you attend?</label>

                                    <input type="radio" name="attend" value="Yes, I will be there">
                                    <span>Yes, I will be there</span><br>
                                    <input type="radio" name="attend" value="Sorry, I can't come">
                                    <span>Sorry, I can't come</span>

                                </div>
                                <div class="col-md-6">
                                    <label>Meal preference</label>
                                    <select name="meal" class="form-control form-opacity">
                                        <option value="I eat anything">I eat anything</option>
                                        <option value="Beef">Beef</option>
                                        <option value="Chicken">Chicken</option>
                                        <option value="Vegetarian">Vegetarian</option>
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <label>Notes</label>
                                    <textarea name="message" class="form-control form-opacity"></textarea>
                                </div>
                                <div class="col-md-12">
                                    <input type="submit" class="btn submit" value="Send">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>



            </div>
            <!-- container end -->

        </section>
        <!-- section end -->




        <!-- section -->
        <section class="gla_section gla_image_bck gla_wht_txt gla_fixed" data-stellar-background-ratio="0.4" data-image="<?php echo e(asset('assets/images/wedding/mark_liz/10503209034_51e5fc8878_k.jpg')); ?>">

            <!-- Over -->
            <div class="gla_over" data-color="#282828" data-opacity="0.4"></div>

            <div class="container text-center">
                <p><img src="<?php echo e(asset('assets/images/animations/thnyou_wh.gif')); ?>" alt="" height="200" data-bottom-top="@src:<?php echo e(asset('assets/images/animations/thnyou_wh.gif')); ?>"></p>



            </div>
            <!-- container end -->

        </section>
        <!-- section end -->

    </section>
    <!-- Content End -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>