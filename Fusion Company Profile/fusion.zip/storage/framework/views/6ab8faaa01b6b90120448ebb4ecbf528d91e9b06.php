<?php $__env->startSection('title','Pink Invitation'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding_m/anne-edgar-119372.jpg')); ?>" id="gla_page" >

<!-- Over -->
<div class="gla_page gla_image_bck" data-image="<?php echo e(asset('assets/images/wedding_m/photo-nic-co-uk-nic-119470.jpg')); ?>" id="gla_page" >

<!-- Over -->
<div class="gla_over" data-color="#282828" data-opacity="0"></div>


    <!-- To Top -->
    <a href="#gla_page" class="gla_top ti ti-angle-up gla_go"></a>

    <!-- Music -->
    <div class="gla_music_icon">
        <i class="ti ti-music"></i>
    </div>
    <div class="gla_music_icon_cont">
        <iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/66757544&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>
    </div>

    <!-- Header -->
    <header>



        <nav class="gla_light_nav gla_transp_nav">

            <div class="container">

                <div class="gla_logo_container clearfix">
                    <img src="<?php echo e(asset('assets/images/glanz_logo.png')); ?>" alt="" class="gla_logo_rev">
                    <div class="gla_logo_txt">
                        <!-- Logo -->
                        <a href="http://glanz.starkethemes.com/" class="gla_logo">Clark & Ann</a>

                        <!-- Text Logo -->
                        <div class="gla_logo_und">10.08.2017</div>
                    </div>
                </div>

                <!-- Menu -->
                <div class="gla_main_menu gla_main_menu_mobile">

                    <div class="gla_main_menu_icon">
                        <i></i><i></i><i></i><i></i>
                        <b>Menu</b>
                        <b class="gla_main_menu_icon_b">Back</b>
                    </div>
                </div>

                <!-- Menu Content -->
                <div class="gla_main_menu_content gla_image_bck" data-color="rgba(0,0,0,0.9)" data-image="<?php echo e(asset('assets/images/wedding_m/green_b.jpg')); ?>">
                    <!-- Over -->
                    <div class="gla_over" data-color="#000" data-opacity="0.7"></div>
                </div>

                <div class="gla_main_menu_content_menu gla_wht_txt text-right">
                    <div class="container">
                        <ul>
                            <li class="gla_parent"><a href="#">Demos</a>
                                <ul>
                                    <li><a href="01_01_home_simple_flowers.html">Home 1 - Animated Flowers</a></li>
                                    <li><a href="01_02_home_pink_flowers.html">Home 2- Pink Animated Flowers</a></li>
                                    <li><a href="01_03_home_golden.html">Home 3 - Golden Badges</a></li>
                                    <li><a href="01_04_home_flbg.html">Home 4 - Great Flowers</a></li>
                                    <li><a href="01_05_home_flbg.html">Home 5 - Great Flowers</a></li>
                                    <li><a href="01_06_home_flbg.html">Home 6 - Great Flowers</a></li>
                                    <li><a href="01_10_home_parallax.html">Home 7 - Parallax</a></li>
                                    <li><a href="01_09_home_land.html">Home 8 - Landing</a></li>
                                </ul>
                            </li>

                            <li class="gla_parent"><a href="#">Business</a>
                                <ul>
                                    <li><a href="01_07_wedding_planner.html">Wedding Planner</a></li>
                                    <li><a href="01_08_wedding_flowers.html">Wedding Flowers</a></li>
                                    <li><a href="01_11_wedding_cakes.html">Wedding Cakes</a></li>
                                </ul>
                            </li>

                            <li class="gla_parent"><a href="#">Invitations</a>
                                <ul>
                                    <li><a href="02_01_invitation.html">Invitation 1</a></li>
                                    <li><a href="02_02_invitation.html">Invitation 2</a></li>
                                    <li><a href="02_03_invitation.html">Invitation 3</a></li>
                                    <li><a href="02_04_invitation.html">Invitation 4</a></li>
                                </ul>
                            </li>

                            <li class="gla_parent"><a href="#">Blog</a>
                                <ul>
                                    <li><a href="03_01_blog_sidebar.html">Blog with Sidebar</a></li>
                                    <li><a href="03_02_blog_1col.html">Blog Full Width</a></li>
                                    <li><a href="03_03_blog_single_sidebar.html">Single Post with Sidebar</a></li>
                                    <li><a href="03_04_blog_single_col1.html">Single Post Full Width</a></li>
                                </ul>
                            </li>
                            <li class="gla_parent"><a href="#">Shop</a>
                                <ul>
                                    <li><a href="04_01_shop_category_col1.html">Shop Category</a></li>
                                    <li><a href="04_02_shop_category_sidebar.html">Shop Category with Sidebar</a></li>
                                    <li><a href="04_03_shop_single_sidebar.html">Shop Item Page</a></li>
                                    <li><a href="04_04_shop_cart.html">Shop Cart</a></li>
                                    <li><a href="04_05_shop_checkout.html">Shop Checkout</a></li>
                                </ul>
                            </li>
                            <li class="gla_parent"><a href="#">Elements</a>
                                 <ul class="mega-menu">

                                    <li class="mega-menu-col">
                                        <ul>
                                            <li class="mega-menu-col-header">Shortcodes</li>
                                            <li><a href="05_01_shortcodes.html#accordions"><i class="ti ti-layout-accordion-separated"></i> Accordions</a></li>
                                            <li><a href="05_01_shortcodes.html#tabs"><i class="ti ti-layout-tab"></i> Tabs</a></li>
                                            <li><a href="05_01_shortcodes.html#buttons"><i class="ti ti-layout-grid2"></i> Buttons</a></li>
                                            <li><a href="05_01_shortcodes.html#labels"><i class="ti ti-comment"></i> Labels</a></li>
                                            <li><a href="05_01_shortcodes.html#alerts"><i class="ti ti-alert"></i> Alerts</a></li>
                                            <li><a href="05_01_shortcodes.html#lightbox"><i class="ti ti-plus"></i> Lightbox</a></li>
                                            <li><a href="05_01_shortcodes.html#progress_bars"><i class="ti ti-layout-list-post"></i> Progress Bars</a></li>
                                            <li><a href="05_01_shortcodes.html#counters"><i class="ti ti-timer"></i> Counters & Charts</a></li>
                                            <li><a href="05_01_shortcodes.html#twitter"><i class="ti ti-twitter"></i> Twitter Feeds</a></li>
                                        </ul>
                                    </li>
                                    <li class="mega-menu-col">
                                        <ul>
                                            <li class="mega-menu-col-header">Wedding Elements</li>
                                            <li><a href="05_14_when_where.html">When & Where Blocks</a></li>
                                            <li><a href="05_15_friends.html">Friends Blocks</a></li>
                                            <li><a href="05_16_about.html">About Us Blocks</a></li>
                                            <li><a href="05_17_save.html">Save the Date Blocks</a></li>
                                            <li><a href="05_18_rsvp.html">RSVP Blocks</a></li>
                                            <li><a href="05_19_badges.html">All Animated Badges</a></li>
                                        </ul>
                                    </li>
                                    <li class="mega-menu-col">
                                        <ul>
                                            <li class="mega-menu-col-header">Other</li>
                                            <li><a href="05_02_testimonials.html">Testimonials Page</a></li>
                                            <li><a href="05_03_passpartu.html">Passpartu Page</a></li>
                                            <li><a href="05_04_preloader.html">Preloader Page</a></li>
                                            <li><a href="05_05_videointro.html">Video Intro Page</a></li>
                                            <li><a href="05_06_video_slider.html">Video Slider Page</a></li>
                                            <li><a href="05_07_video_section.html">Video Section Page</a></li>
                                            <li><a href="05_08_slider.html">Slider Page</a></li>
                                        </ul>
                                    </li>
                                    <li class="mega-menu-col">
                                        <ul>
                                            <li class="mega-menu-col-header">Headers & Footers</li>
                                            <li><a href="05_09_header_transparent.html">Transparent Header</a></li>
                                            <li><a href="05_10_header_white.html">White Header</a></li>
                                            <li><a href="05_11_header_black.html">Black Header</a></li>
                                            <li><a href="05_12_header_image.html">Image Header</a></li>
                                            <li><a href="05_13_footers.html#grey">Grey Footer</a></li>
                                            <li><a href="05_13_footers.html#black">Black Footer</a></li>
                                            <li><a href="05_13_footers.html#white">White Footer</a></li>
                                            <li><a href="05_13_footers.html#simple">Simple Footer</a></li>
                                        </ul>
                                    </li>


                                </ul>
                            </li>


                        </ul>
                        <div class="gla_main_menu_content_menu_copy">
                            <form>
                                <input type="text" class="form-control" placeholder="Enter Your Keywords">
                                <button type="submit" class="btn">
                                  Search
                                </button>
                            </form>
                            <br>
                            <p>© GlanzThemes 2017</p>
                            <!-- Social Buttons -->
                            <div class="gla_footer_social">
                                <a href="#"><i class="ti ti-facebook gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-instagram gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-google gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-youtube gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-twitter gla_icon_box"></i></a>
                                <a href="#"><i class="ti ti-pinterest gla_icon_box"></i></a>
                            </div>

                        </div>
                    </div>
                    <!-- container end -->
                </div>
                <!-- menu content end -->

                <!-- Search Block -->
                <div class="gla_search_block">

                    <div class="gla_search_block_link gla_search_parent"><i class="ti ti-search"></i>
                        <ul>
                            <li>
                                <form>
                                    <input type="text" class="form-control" placeholder="Enter Your Keywords">
                                    <button type="submit" class="btn">
                                      <i class="ti ti-search"></i>
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Search Block End -->

                <!-- Top Menu -->
                <div class="gla_default_menu">
                    <ul>
                        <li class="gla_parent"><a href="#">Demos</a>
                            <ul>
                                <li><a href="01_01_home_simple_flowers.html">Home 1 - Animated Flowers</a></li>
                                <li><a href="01_02_home_pink_flowers.html">Home 2- Pink Animated Flowers</a></li>
                                <li><a href="01_03_home_golden.html">Home 3 - Golden Badges</a></li>
                                <li><a href="01_04_home_flbg.html">Home 4 - Great Flowers</a></li>
                                <li><a href="01_05_home_flbg.html">Home 5 - Great Flowers</a></li>
                                <li><a href="01_06_home_flbg.html">Home 6 - Great Flowers</a></li>
                                <li><a href="01_10_home_parallax.html">Home 7 - Parallax</a></li>
                                <li><a href="01_09_home_land.html">Home 8 - Landing</a></li>
                            </ul>
                        </li>

                        <li class="gla_parent"><a href="#">Business</a>
                            <ul>
                                <li><a href="01_07_wedding_planner.html">Wedding Planner</a></li>
                                <li><a href="01_08_wedding_flowers.html">Wedding Flowers</a></li>
                                <li><a href="01_11_wedding_cakes.html">Wedding Cakes</a></li>
                            </ul>
                        </li>

                        <li class="gla_parent"><a href="#">Invitations</a>
                            <ul>
                                <li><a href="02_01_invitation.html">Invitation 1</a></li>
                                <li><a href="02_02_invitation.html">Invitation 2</a></li>
                                <li><a href="02_03_invitation.html">Invitation 3</a></li>
                                <li><a href="02_04_invitation.html">Invitation 4</a></li>
                            </ul>
                        </li>

                        <li class="gla_parent"><a href="#">Blog</a>
                            <ul>
                                <li><a href="03_01_blog_sidebar.html">Blog with Sidebar</a></li>
                                <li><a href="03_02_blog_1col.html">Blog Full Width</a></li>
                                <li><a href="03_03_blog_single_sidebar.html">Single Post with Sidebar</a></li>
                                <li><a href="03_04_blog_single_col1.html">Single Post Full Width</a></li>
                            </ul>
                        </li>
                        <li class="gla_parent"><a href="#">Shop</a>
                            <ul>
                                <li><a href="04_01_shop_category_col1.html">Shop Category</a></li>
                                <li><a href="04_02_shop_category_sidebar.html">Shop Category with Sidebar</a></li>
                                <li><a href="04_03_shop_single_sidebar.html">Shop Item Page</a></li>
                                <li><a href="04_04_shop_cart.html">Shop Cart</a></li>
                                <li><a href="04_05_shop_checkout.html">Shop Checkout</a></li>
                            </ul>
                        </li>
                        <li class="gla_parent"><a href="#">Elements</a>
                             <ul class="mega-menu">

                                <li class="mega-menu-col">
                                    <ul>
                                        <li class="mega-menu-col-header">Wedding Elements</li>
                                        <li><a href="05_14_when_where.html">When & Where Blocks</a></li>
                                        <li><a href="05_15_friends.html">Friends Blocks</a></li>
                                        <li><a href="05_16_about.html">About Us Blocks</a></li>
                                        <li><a href="05_17_save.html">Save the Date Blocks</a></li>
                                        <li><a href="05_18_rsvp.html">RSVP Blocks</a></li>
                                        <li><a href="05_19_badges.html">All Animated Badges</a></li>
                                    </ul>
                                </li>

                                <li class="mega-menu-col">
                                    <ul>
                                        <li class="mega-menu-col-header">Shortcodes</li>
                                        <li><a href="05_01_shortcodes.html#accordions"><i class="ti ti-layout-accordion-separated"></i> Accordions</a></li>
                                        <li><a href="05_01_shortcodes.html#tabs"><i class="ti ti-layout-tab"></i> Tabs</a></li>
                                        <li><a href="05_01_shortcodes.html#buttons"><i class="ti ti-layout-grid2"></i> Buttons</a></li>
                                        <li><a href="05_01_shortcodes.html#labels"><i class="ti ti-comment"></i> Labels</a></li>
                                        <li><a href="05_01_shortcodes.html#alerts"><i class="ti ti-alert"></i> Alerts</a></li>
                                        <li><a href="05_01_shortcodes.html#lightbox"><i class="ti ti-plus"></i> Lightbox</a></li>
                                        <li><a href="05_01_shortcodes.html#progress_bars"><i class="ti ti-layout-list-post"></i> Progress Bars</a></li>
                                        <li><a href="05_01_shortcodes.html#counters"><i class="ti ti-timer"></i> Counters & Charts</a></li>
                                        <li><a href="05_01_shortcodes.html#twitter"><i class="ti ti-twitter"></i> Twitter Feeds</a></li>
                                    </ul>
                                </li>
                                <li class="mega-menu-col">
                                    <ul>
                                        <li class="mega-menu-col-header">Other</li>
                                        <li><a href="05_02_testimonials.html">Testimonials Page</a></li>
                                        <li><a href="05_04_preloader.html">Preloader Page</a></li>
                                        <li><a href="05_05_videointro.html">Video Intro Page</a></li>
                                        <li><a href="05_06_video_slider.html">Video Slider Page</a></li>
                                        <li><a href="05_07_video_section.html">Video Section Page</a></li>
                                        <li><a href="05_08_slider.html">Slider Page</a></li>
                                    </ul>
                                </li>
                                <li class="mega-menu-col">
                                    <ul>
                                        <li class="mega-menu-col-header">Headers & Footers</li>
                                        <li><a href="05_09_header_transparent.html">Transparent Header</a></li>
                                        <li><a href="05_10_header_white.html">White Header</a></li>
                                        <li><a href="05_11_header_black.html">Black Header</a></li>
                                        <li><a href="05_12_header_image.html">Image Header</a></li>
                                        <li><a href="05_13_footers.html#grey">Grey Footer</a></li>
                                        <li><a href="05_13_footers.html#black">Black Footer</a></li>
                                        <li><a href="05_13_footers.html#white">White Footer</a></li>
                                        <li><a href="05_13_footers.html#simple">Simple Footer</a></li>
                                    </ul>
                                </li>


                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- Top Menu End -->



            </div>
            <!-- container end -->
        </nav>

    </header>
    <!-- Header End -->


    <!-- Content -->
    <section id="gla_content" class="gla_content">

        <div class="gla_invitation_container">
            <div class="gla_invitation_i gla_invitation_ii gla_image_bck" data-image="<?php echo e(asset('assets/images/invitations/inv_i/back2.jpg')); ?>">

                <p><img src="<?php echo e(asset('assets/images/invitations/inv_i/save_the_date_bl.gif')); ?>" alt="" height="220"></p>
                <br><br>
                <h2>Kevin & Julie</h2>
                <h4>10 Aug</h4>
                <h4>St. Thomas's Church, Bristol</h4>
            </div>
        </div>

    </section>
    <!-- Content End -->


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>