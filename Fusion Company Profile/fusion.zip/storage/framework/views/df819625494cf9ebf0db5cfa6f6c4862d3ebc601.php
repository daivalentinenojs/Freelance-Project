<?php $__env->startSection('title','Master Data Template Detail'); ?>

<?php $__env->startSection('content'); ?>
<div class="gla_page_title gla_image_bck gla_wht_txt" data-color="#282828">
   <div class="container text-left">
      <div class="row">
         <div class="col-md-12">
            <h1 class="gla_h1_title">Create Data Template Detail</h1>
            <h3>This page allows you to create and update a template detail</h3>
         </div>
      </div>
   </div>
</div>
<section id="gla_content" class="gla_content">
  <section class="gla_section">
     <div class="container">
       <div class="row">
         <div class="col-md-12 gla_main_sidebar">
           <form id="form-validated" action="<?php echo e(url()->current()); ?>" method="POST" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <?php if($errors->any()): ?>
                  <div class="alert alert-danger">
                    <span aria-hidden="true" class="alert-icon icon_blocked"></span><strong>Error! </strong>There are some problems.
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
              <?php endif; ?>
              <?php if(isset($detail)): ?>
              <input type="hidden" name="eid" value="<?php echo e($detail->eid); ?>">
              <?php endif; ?>
               <div class="form-group row">
                   <div class="col-md-6">
                       <label>Unique Name* <small class="form-text text-muted"> Ex. parallax_name</small></label>
                       <input type="text" name="unique_name" class="form-control form-opacity" required data-parsley-maxlength="100" data-parsley-minlength="3" value="<?php echo e(old('unique_name',(isset($detail)? $detail->unique_name : ''))); ?>">
                   </div>
                   <div class="col-md-6">
                       <label>HTML*</label>
                       <input type="text" name="html" class="form-control form-opacity" required data-parsley-maxlength="100" data-parsley-minlength="3" value="<?php echo e(old('html',(isset($detail)? $detail->html : ''))); ?>">
                   </div>
               </div>
               <div class="form-group row">
                   <div class="col-md-6">
                       <label>Name* <small class="form-text text-muted"> Ex. Prince's Name</small></label>
                       <input type="text" name="name" class="form-control form-opacity" required data-parsley-maxlength="100" data-parsley-minlength="3" value="<?php echo e(old('name',(isset($detail)? $detail->name : ''))); ?>">
                   </div>
                   <div class="col-md-6">
                       <label>Example* <small class="form-text text-muted"> Ex. Daivalentineno Janitra Salim</small></label>
                       <input type="text" name="example" class="form-control form-opacity" required data-parsley-maxlength="100" data-parsley-minlength="3" value="<?php echo e(old('example',(isset($detail)? $detail->example : ''))); ?>">
                   </div>
               </div>
               <div class="form-group row">
                   <div class="col-md-6">
                       <label>Type* <small class="form-text text-muted"> Ex. text</small></label>
                       <input type="text" name="types" class="form-control form-opacity" required data-parsley-maxlength="100" data-parsley-minlength="3" value="<?php echo e(old('types',(isset($detail)? $detail->types : ''))); ?>">
                   </div>
               </div>
               <div class="form-group row">
                   <div class="col-md-6">
                       <label>Template* <small class="form-text text-muted"> Ex. Parallax</small></label>
                       <select name="template_design_id" class="form-control form-opacity" required>
                        <?php $__currentLoopData = $template; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($temp['id']); ?>" <?php echo e((old('template_design_id',(isset($detail)? $detail->template_design_id : '')) == $temp['id']) ? 'selected' : ''); ?>><?php echo e($temp['nama']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                   </div>
                   <div class="col-md-6">
                       <label>Parent*</label>
                       <select name="template_design_detail_id" class="form-control form-opacity" required>
                       <option value="0" <?php echo e((old('template_design_detail_id',(isset($detail)? $detail->template_design_detail_id : '')) == '0') ? 'selected' : ''); ?>>NULL</option>
                        <?php $__currentLoopData = $detailfk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($det['id']); ?>" <?php echo e((old('template_design_detail_id',(isset($detail)? $detail->template_design_detail_id : '')) == $det['id']) ? 'selected' : ''); ?>><?php echo e($det['unique_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                   </div>
               </div>
               <div class="form-group row">
                   <div class="col-md-12 text-center">
                       <input type="submit" class="btn submit" value="Save">
                   </div>
               </div>
           </form>
         </div>
       </div>
     </div>
  </section>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
  select.form-control {
    border-radius: 25px !important;
  }

  input.parsley-success,
  select.parsley-success,
  textarea.parsley-success {
    /* color: green; */
    background-color: #DFF0D8;
    border: 1px solid #D6E9C6;
  }

  input.parsley-error,
  select.parsley-error,
  textarea.parsley-error {
    /* color: red; */
    background-color: #F2DEDE;
    border: 1px solid #EED3D7;
  }

  .parsley-errors-list {
    /* margin: 0px 0 3px; */
    padding: 0;
    color: red;
    font-weight: bold;
    list-style-type: none;
    font-size: 0.9em;
    line-height: 0.9em;
    opacity: 0;

    transition: all .3s ease-in;
    -o-transition: all .3s ease-in;
    -moz-transition: all .3s ease-in;
    -webkit-transition: all .3s ease-in;
  }

  .parsley-errors-list.filled {
    opacity: 1;
  }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/js/jquery.inputmask.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/parsley.min.js')); ?>"></script>
<script>
$(function () {
  thisform.init();
}), thisform = {
  init : function () {
    $('#form-validated').parsley();
    $('.form-masked').inputmask( {'autoUnmask' : true});
  },
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>