<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
<section id="gla_content" class="gla_content">
  <section class="gla_section">
    <div class="container">
      <form id="form-filter" method="get" action="<?php echo e(url()->current()); ?>">
        <div class="row">
          <div class="col-md-12">
            <div class="breadcrumbs pull-left">
              <a href="<?php echo e(url('/')); ?>" style="color:rgb(233, 142, 21)"><b>Home</b></a>
              <a href="javascript:void(0);" style="color:rgb(233, 142, 21)"><b>Category</b></a>
              <span><b><?php echo e($event_category->nama); ?></b></span>
            </div>
          </div>
          <hr />
          <div class="col-md-12">
            <div class="gla_shop_header">
              <div class="row">
                <div class="col-md-6">
                  <p>Showing <?php echo e(number_format($template_designs->total())); ?> (<?php echo e(number_format($template_designs->firstItem())); ?> - <?php echo e(number_format($template_designs->lastItem())); ?> of <?php echo e(number_format($template_designs->total())); ?>)</p>
                </div>
                <div class="col-md-3 text-right pull-right">
                   <select class="form-control input-filter" id="sort_by" name="sb">
                     <option value="">Relevant</option>
                     <option value="price_asc" <?php echo e(Request::input('sb')=='price_asc' ? 'selected' : ''); ?>>Price Low</option>
                     <option value="price_desc" <?php echo e(Request::input('sb')=='price_desc' ? 'selected' : ''); ?>>Price High</option>
                   </select>
                </div>
              </div>
            </div>
            <div class="row">
              <?php $__currentLoopData = $template_designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $template_design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 gla_anim_box">
                <div class="gla_shop_item">
                  <!-- <span class="gla_shop_item_sale">Type Premium/No</span> -->
                  <span class="gla_shop_item_slider">
                    <img src="<?php echo e(Storage::disk('public')->url($template_design->imgpreview)); ?>" alt="<?php echo e($template_design->nama); ?>">
                  </span>
                  <a href="<?php echo e(url('p/'.$template_design->link_url)); ?>" class="gla_shop_item_title">
                    <?php echo e($template_design->nama); ?>

                    <!-- <b><s>$120.36</s> $12.96</b> -->
                  </a>
                  <!-- <div class="gla_shop_item_links">
                    <a href="#shop"><i class="ti ti-shopping-cart"></i></a>
                  </div> -->
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <nav class="gla_blog_pag">
              <?php echo e($template_designs->appends(Request::all())->links()); ?>

            </nav>
          </div>
        </div>
      </form>
    </div>
  </section>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
$(document).ready(function() {
  $('.input-filter').on('change',function(){
    $('#form-filter').submit();
  });
});
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', ['nav' => 'class="gla_light_nav gla_image_bck gla_wht_txt" data-color="#000"'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>