<nav class="gla_light_nav gla_transp_nav">
   <div class="container">
         
         <div class="gla_logo_container clearfix">
            <img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="" class="gla_logo_rev">
            <div class="gla_logo_txt">
               <!-- Logo -->
               <a href="<?php echo e(url('/')); ?>" class="gla_logo">3Vite</a>
               
               <!-- Text Logo -->
               <div class="gla_logo_und">The Best Digital Invitation Card</div>
            </div>
         </div>

         <!-- Menu -->
         <div class="gla_main_menu gla_main_menu_mobile">
            
            <div class="gla_main_menu_icon">
               <i></i><i></i><i></i><i></i>
               <b>Menu</b>
               <b class="gla_main_menu_icon_b">Back</b>
            </div>
         </div>
         
         <!-- Menu Content -->
         <div class="gla_main_menu_content gla_image_bck" data-color="rgba(0,0,0,0.9)" data-image="http://placehold.it/1400x800">
            <!-- Over -->
            <div class="gla_over" data-color="#000" data-opacity="0.7"></div>
         </div>

         <div class="gla_main_menu_content_menu gla_bck_txt text-right">
            <div class="container">
               <ul>
                     <li><a href="<?php echo e(url('/')); ?>">Home</a></li>

                     <li class="gla_parent"><a href="">Template</a>
                        <ul>
                           <li><a href="<?php echo e(url('template/abstractflower')); ?>">Abstract Flower</a></li>    
                           <li><a href="<?php echo e(url('template/animatedflower')); ?>">Animated Flowers</a></li>                        
                           <li><a href="<?php echo e(url('template/goldenbadge')); ?>">Golden Badge</a></li>
                           <li><a href="<?php echo e(url('template/greatflower')); ?>">Great Flower</a></li>
                           <li><a href="<?php echo e(url('template/landing')); ?>">Landing</a></li>
                           <li><a href="<?php echo e(url('template/parallax')); ?>">Parallax</a></li>
                           <li><a href="<?php echo e(url('template/pinkanimatedflower')); ?>">Pink Animated Flowers</a></li>
                           <li><a href="<?php echo e(url('template/simpleflower')); ?>">Simple Flower</a></li>
                        </ul>
                     </li>

                     <li class="gla_parent"><a href="">Invitation</a>
                        <ul>
                           <li><a href="<?php echo e(url('invitation/pink')); ?>">Invitation 1</a></li>
                           <li><a href="<?php echo e(url('invitation/purple')); ?>">Invitation 2</a></li>
                           <li><a href="<?php echo e(url('invitation/red')); ?>">Invitation 3</a></li>
                        </ul>
                     </li>  
                     
                     <li><a href="<?php echo e(url('about-us')); ?>">About Us</a></li>

                     <li><a href="<?php echo e(url('contact-us')); ?>">Contact Us</a></li>
               </ul>
               <div class="gla_main_menu_content_menu_copy">
                     <!-- <form>
                        <input type="text" class="form-control" placeholder="Enter Your Keywords">
                        <button type="submit" class="btn">
                           Search
                        </button>
                     </form> -->
                     <br>
                     <p>© 3Vite 2020</p>
                     <!-- Social Buttons -->
                     <!-- <div class="gla_footer_social">
                        <a href=""><i class="ti ti-facebook gla_icon_box"></i></a>
                        <a href=""><i class="ti ti-instagram gla_icon_box"></i></a>
                        <a href=""><i class="ti ti-google gla_icon_box"></i></a>
                        <a href=""><i class="ti ti-youtube gla_icon_box"></i></a>
                     </div> -->
                     <!-- End Social Buttons -->
                     
               </div>
            </div>
            <!-- container end -->
         </div>
         <!-- menu content end -->

         <!-- Search Block -->
         <!-- <div class="gla_search_block">
            
            <div class="gla_search_block_link gla_search_parent"><i class="ti ti-search"></i>
               <ul>
                     <li>
                        <form>
                           <input type="text" class="form-control" placeholder="Enter Your Keywords">
                           <button type="submit" class="btn">
                              <i class="ti ti-search"></i>
                           </button>
                        </form>
                     </li>
               </ul>
            </div>
         </div> -->
         <!-- Search Block End -->

         <!-- Top Menu -->
         <div class="gla_default_menu">
            <ul>
               <li><a href="<?php echo e(url('/')); ?>">Home</a></li>

               <li class="gla_parent"><a href="">Template</a>
                     <ul>
                        <li><a href="<?php echo e(url('template/abstractflower')); ?>">Abstract Flower</a></li>    
                        <li><a href="<?php echo e(url('template/animatedflower')); ?>">Animated Flowers</a></li>                        
                        <li><a href="<?php echo e(url('template/goldenbadge')); ?>">Golden Badge</a></li>
                        <li><a href="<?php echo e(url('template/greatflower')); ?>">Great Flower</a></li>
                        <li><a href="<?php echo e(url('template/landing')); ?>">Landing</a></li>
                        <li><a href="<?php echo e(url('template/parallax')); ?>">Parallax</a></li>
                        <li><a href="<?php echo e(url('template/pinkanimatedflower')); ?>">Pink Animated Flowers</a></li>
                        <li><a href="<?php echo e(url('template/simpleflower')); ?>">Simple Flower</a></li>                        
                     </ul>
               </li>
               
               <li class="gla_parent"><a href="">Invitation</a>
                     <ul>
                           <li><a href="<?php echo e(url('invitation/pink')); ?>">Invitation 1</a></li>
                           <li><a href="<?php echo e(url('invitation/purple')); ?>">Invitation 2</a></li>
                           <li><a href="<?php echo e(url('invitation/red')); ?>">Invitation 3</a></li>
                     </ul>
               </li>

               <li><a href="<?php echo e(url('about-us')); ?>">About Us</a></li>

               <li><a href="<?php echo e(url('contact-us')); ?>">Contact Us</a></li>

            </ul>
         </div>
         <!-- Top Menu End -->


      
   </div>
   <!-- container end -->
</nav>