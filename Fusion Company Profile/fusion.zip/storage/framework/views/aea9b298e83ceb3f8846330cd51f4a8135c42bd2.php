<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light site-navbar-target" id="ftco-navbar">
   <div class="container">
   <div class="vr">
      <span class="pl-3 py-4"><img src="<?php echo e(asset('assets/images/logo/logo_text.png')); ?>" width="150px" height="50px" alt=""></span>
   </div>
   <button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="oi oi-menu"></span> Menu
   </button>

   <div class="collapse navbar-collapse" id="ftco-nav">
      <ul class="navbar-nav nav ml-auto">
         <li class="nav-item"><a href="<?php echo e(url('/')); ?>" class="nav-link"><span>Home</span></a></li>
         <li class="nav-item"><a href="<?php echo e(url('/facilities')); ?>" class="nav-link"><span>Facilities</span></a></li>         
         <li class="nav-item"><a href="<?php echo e(url('/destination')); ?>" class="nav-link"><span>Destination</span></a></li>
         <li class="nav-item"><a href="<?php echo e(url('/ticket-and-book')); ?>" class="nav-link"><span>Ticket And Book</span></a></li>
         <li class="nav-item"><a href="<?php echo e(url('/blog')); ?>" class="nav-link"><span>Blog</span></a></li>
         <li class="nav-item"><a href="<?php echo e(url('/about-us')); ?>" class="nav-link"><span>About Us</span></a></li>
         <li class="nav-item"><a href="<?php echo e(url('/contact-us')); ?>" class="nav-link"><span>Contact Us</span></a></li>
      </ul>
   </div>
   </div>
</nav>